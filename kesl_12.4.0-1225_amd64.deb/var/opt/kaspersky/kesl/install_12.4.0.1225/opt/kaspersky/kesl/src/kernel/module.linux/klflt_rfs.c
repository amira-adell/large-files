#include "klflt.h"
#include "redirfs/redirfs.h"
#include "files.h"
#include "mount.h"
#include <linux/fs.h>
#include <linux/security.h>
#include <linux/sched.h>
#include <linux/mount.h>
#include <linux/utsname.h>
#include <linux/kthread.h>
#include <linux/seq_file.h>

#include <linux/delay.h>

static redirfs_filter klflt;

static struct redirfs_filter_info klflt_info = {
    .owner                                   = THIS_MODULE,
    .name                                    = "klflt",
    .priority                                = 500000000,
};

static enum redirfs_rv klflt_open(redirfs_context context,
                                  struct redirfs_args* args);
static enum redirfs_rv klflt_release(redirfs_context context,
                                     struct redirfs_args* args);

static atomic_t rfs_started = ATOMIC_INIT(0);

#define MNT_SKIP_KAVOAS 0x02000000

static DEFINE_MUTEX(registered_mutex);

enum
{
    SC_OPEN,
    SC_CLOSE,
    SC_RENAME,
    SC_UNLINK,
    SC_ACCESS,
    SC_ATTR
};

struct syscall_info
{
    char const* name;
    atomic_t counter;
};

static struct syscall_info syscall_info[] = {
    /* SC_OPEN */ {"open", ATOMIC_INIT(0)},
    /* SC_CLOSE */ {"close", ATOMIC_INIT(0)},
    /* SC_RENAME */ {"rename", ATOMIC_INIT(0)},
    /* SC_UNLINK */ {"unlink", ATOMIC_INIT(0)},
    /* SC_ACCESS */ {"access", ATOMIC_INIT(0)},
    /* SC_ATTR */ {"attrib", ATOMIC_INIT(0)},
};

static int inline dump_syscall(
    unsigned int scid, unsigned int state, struct dentry* dentry, int error)
{
    pr_debug("[%02i] %c%7s: task %16s(%6d) status %02i file %s\n",
                 atomic_read(&syscall_info[scid].counter), state ? '+' : '-',
                 syscall_info[scid].name, current->comm, current->pid, error,
                 dentry ? dentry->d_name.name : NULL);
    return 0;
}

static enum redirfs_rv klflt_open(
    redirfs_context context, struct redirfs_args* args)
{
    if (klflt_is_mnt_excluded(args->args.f_open.file->f_vfsmnt))
    {
        args->rv.rv_int = 0;
    }
    else
    {
        dump_syscall(SC_OPEN, 1, args->args.f_open.file->f_dentry, 0);
        args->rv.rv_int =
            klflt_check_before_open(args->args.f_open.inode, args->args.f_open.file);
        dump_syscall(SC_OPEN, 0, args->args.f_open.file->f_dentry, args->rv.rv_int);
    }

    return args->rv.rv_int ? REDIRFS_STOP : REDIRFS_CONTINUE;
}

static enum redirfs_rv klflt_release(redirfs_context context, struct redirfs_args* args)
{
    dump_syscall(SC_CLOSE, 1, args->args.f_release.file->f_dentry, 0);
    args->rv.rv_int =
        klflt_check_after_close(args->args.f_release.inode, args->args.f_release.file);
    dump_syscall(SC_CLOSE, 0, args->args.f_release.file->f_dentry, args->rv.rv_int);

    return args->rv.rv_int ? REDIRFS_STOP : REDIRFS_CONTINUE;
}

static enum redirfs_rv klflt_rename(redirfs_context context, struct redirfs_args* args)
{
    dump_syscall(SC_RENAME, 1, args->args.i_rename.old_dentry, 0);
    klflt_check_rename(args->args.i_rename.old_dir, args->args.i_rename.old_dentry,
                  args->args.i_rename.new_dir, args->args.i_rename.new_dentry);
    dump_syscall(SC_RENAME, 0, args->args.i_rename.old_dentry, 0);

    return REDIRFS_CONTINUE;
}

static enum redirfs_rv klflt_unlink(redirfs_context context, struct redirfs_args* args)
{
    dump_syscall(SC_UNLINK, 1, args->args.i_unlink.dentry, 0);
    klflt_check_unlink(args->args.i_unlink.dir, args->args.i_unlink.dentry);
    dump_syscall(SC_UNLINK, 0, args->args.i_unlink.dentry, 0);

    return REDIRFS_CONTINUE;
}

static enum redirfs_rv klflt_access(redirfs_context context, struct redirfs_args* args)
{
    struct inode* inode = args->args.i_permission.inode;
    if (klflt_check_trusted(current) && args->rv.rv_int &&
        is_acs_magic(inode->i_sb->s_magic))
        args->rv.rv_int = 0;
    return REDIRFS_CONTINUE;
}

static enum redirfs_rv klflt_getattr(redirfs_context context, struct redirfs_args* args)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,13,0)
    struct dentry* dentry = args->args.i_getattr.dentry;
#else
    struct dentry* dentry = args->args.i_getattr.mnt->dentry;
#endif


    if (klflt_check_trusted(current) && args->rv.rv_int &&
        is_acs_magic(dentry->d_sb->s_magic))
    {
        generic_fillattr(dentry->d_inode, args->args.i_getattr.stat);
        args->rv.rv_int = 0;
    }

    return REDIRFS_CONTINUE;
}

static struct redirfs_op_info klflt_op_info[] = {
    {REDIRFS_REG_FOP_OPEN, klflt_open, NULL},
    {REDIRFS_REG_FOP_RELEASE, NULL, klflt_release},
    {REDIRFS_DIR_IOP_RENAME, klflt_rename, NULL},
    {REDIRFS_DIR_IOP_UNLINK, klflt_unlink, NULL},
    {REDIRFS_REG_IOP_PERMISSION, NULL, klflt_access},
    {REDIRFS_DIR_IOP_PERMISSION, NULL, klflt_access},
    {REDIRFS_LNK_IOP_PERMISSION, NULL, klflt_access},
    {REDIRFS_REG_IOP_GETATTR, NULL, klflt_getattr},
    {REDIRFS_DIR_IOP_GETATTR, NULL, klflt_getattr},
    {REDIRFS_LNK_IOP_GETATTR, NULL, klflt_getattr},
    {REDIRFS_OP_END, NULL, NULL}};

static int klflt_rfs_mount(struct vfsmount* mnt)
{
    void* err = redirfs_add_path(klflt, mnt, mnt->mnt_root, REDIRFS_PATH_INCLUDE);

    pr_debug("%s: Add %p %s\n", __func__, mnt,
        real_mount(mnt)->mnt_mountpoint->d_name.name);
    if (IS_ERR(err))
        return PTR_ERR(err);

    return 0;
}

static int klflt_rfs_umount(struct vfsmount* mnt)
{
    int err;

    pr_debug("%s: Remove %p %s\n", __func__, mnt,
        real_mount(mnt)->mnt_mountpoint->d_name.name);

    err = redirfs_rem_path(klflt, mnt, mnt->mnt_root);
    if (err)
        pr_err("klflt: rem path failed: %i\n", err);

    return err;
}

int klflt_rfs_init(struct klflt_mounts_ops* ops)
{
    int rc;
    pr_debug("%s:", __func__);

    klflt = redirfs_register_filter(&klflt_info);
    if (IS_ERR(klflt))
    {
        rc = PTR_ERR(klflt);
        pr_err("klflt: register filter failed, err=%d\n", rc);
        goto exit;
    }

    rc = redirfs_set_operations(klflt, klflt_op_info);
    if (rc)
    {
        pr_err("klflt: set operations failed, err=%d\n", rc);
        goto exit_operations;
    }

    ops->add_mount = klflt_rfs_mount;
    ops->remove_mount = klflt_rfs_umount;

    atomic_xchg(&rfs_started, 1);

    goto exit;

exit_operations:
    redirfs_unregister_filter(klflt);
exit:
    return rc;
}

void klflt_rfs_destroy(void)
{
    pr_debug("%s\n", __func__);

    atomic_xchg(&rfs_started, 0);

    redirfs_unregister_filter(klflt);
}


