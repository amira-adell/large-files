/*
 * This source file is a part of a Kaspersky Antivirus Monitor.
 * Copyright (C) Kaspersky Lab, 1997-2010
 * See License.txt for details
 *
 */

#ifndef KERNEL__MODULE_LINUX__INTERCEPTOR_SMB_H
#define KERNEL__MODULE_LINUX__INTERCEPTOR_SMB_H

void cifs_calls_replace(struct dentry* d_root);
void cifs_calls_restore(void);

#endif