
/*  
 * This source file is a part of a Kaspersky Antivirus Monitor.
 * Copyright (C) Kaspersky Lab, 1997-2010
 * See License.txt for details
 *
 */


#ifndef KERNEL__UTIL_H
#define KERNEL__UTIL_H

#define UNUSED(x) (void)(x)

int __fnmatch(const char *text, const char *p);

#endif // KERNEL__UTIL_H
