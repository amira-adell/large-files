#include "klflt.h"
#include <linux/list.h>
#include <linux/mutex.h>

typedef struct
{
    struct klflt_file_info file;
    struct list_head list;
} file_entry;

typedef struct
{
    pid_t pid;
    struct klflt_file_info file;
    struct list_head list;
} process_entry;

static DEFINE_MUTEX(trusted_mutex);
static LIST_HEAD(trusted_files);
static LIST_HEAD(trusted_processes);

int klflt_trusted_init(void)
{
    pr_debug("%s", __func__);

    INIT_LIST_HEAD(&trusted_files);

    return 0;
}

void klflt_trusted_destroy(void)
{
    process_entry* process;
    process_entry* ptmp;
    file_entry* file;
    file_entry* ftmp;

    pr_debug("%s", __func__);

    mutex_lock(&trusted_mutex);
    list_for_each_entry_safe(process, ptmp, &trusted_processes, list)
    {
        pr_debug("\tUnregister process %d, ino=%d, dev=%d\n",
            (int)process->pid, (int)process->file.ino, (int)process->file.dev);
        list_del(&process->list);
        kfree(process);
    }
    list_for_each_entry_safe(file, ftmp, &trusted_files, list)
    {
        pr_debug("\tUnregister file ino=%d, dev=%d\n",
            (int)process->file.ino, (int)process->file.dev);
        list_del(&file->list);
        kfree(file);
    }
    mutex_unlock(&trusted_mutex);

}

int klflt_is_file_trusted(const struct klflt_file_info* file)
{
    file_entry* entry;
    int found = 0;

    //pr_debug("%s", __func__);

    mutex_lock(&trusted_mutex);
    list_for_each_entry(entry, &trusted_files, list)
    {
        if (klflt_file_info_equal(&entry->file, file))
        {
            found = 1;
            break;
        }
    }
    mutex_unlock(&trusted_mutex);

    return found;
}

int klflt_register_trusted_file(const struct klflt_file_info* file)
{
    file_entry* file_;

    pr_debug("%s", __func__);

    if (klflt_is_file_trusted(file))
        return 0; // file already registered

    if ((file_ = kmalloc(sizeof(*file_), GFP_KERNEL)) == NULL)
    {
        pr_debug("%s: No memory to allocate file_entry\n", __func__);
        return -ENOMEM;
    }

    pr_debug("\tRegister trusted file ino=%d dev=%d",
        (int)file->ino, (int)file->dev);

    memcpy(&file_->file, file, sizeof(struct klflt_file_info));

    mutex_lock(&trusted_mutex);
    list_add(&file_->list, &trusted_files);
    mutex_unlock(&trusted_mutex);

    return 0;
}

int klflt_is_process_trusted(
    pid_t pid, const struct klflt_file_info* file, int strong)
{
    process_entry* entry;
    int found = 0;

    //pr_debug("%s: pid %d\n", __func__, pid);

    mutex_lock(&trusted_mutex);
    list_for_each_entry(entry, &trusted_files, list)
    {
        if (strong)
            found = entry->pid == pid && klflt_file_info_equal(&entry->file, file);
        else
            found = entry->pid == pid || klflt_file_info_equal(&entry->file, file);

        if (found)
            break;
    }
    mutex_unlock(&trusted_mutex);

    return found;
}

void klflt_trusted_unregister_file(const struct klflt_file_info* finfo)
{
    file_entry* file;
    file_entry* ftmp;

    mutex_lock(&trusted_mutex);
    list_for_each_entry_safe(file, ftmp, &trusted_files, list)
    {
        if (!klflt_file_info_equal(&file->file, finfo))
            continue;
        pr_debug("\tUnregister file ino=%d, dev=%d\n",
            (int)file->file.ino, (int)file->file.dev);
        list_del(&file->list);
        kfree(file);
    }
    mutex_unlock(&trusted_mutex);
}

void klflt_trusted_unregister_proc(const pid_t pid)
{
    process_entry* process;
    process_entry* ptmp;

    mutex_lock(&trusted_mutex);
    list_for_each_entry_safe(process, ptmp, &trusted_processes, list)
    {
        if (process->pid != pid)
            continue;
        pr_debug("\tUnregister process %d, ino=%d, dev=%d\n",
            (int)process->pid, (int)process->file.ino, (int)process->file.dev);
        list_del(&process->list);
        kfree(process);
    }
    mutex_unlock(&trusted_mutex);
}

int klflt_register_trusted_process(pid_t pid, const struct klflt_file_info* file)
{
    process_entry* process;
    int strong = 1;

    pr_debug("%s", __func__);

    if (klflt_is_process_trusted(pid, file, strong))
        return 0; // file already registered

    if ((process = kmalloc(sizeof(*process), GFP_KERNEL)) == NULL)
    {
        pr_debug("%s: No memory to allocate process_entry\n", __func__);
        return -ENOMEM;
    }

    pr_debug("\tRegister trusted process pid=%d ino=%d dev=%d",
        (int)pid, (int)file->ino, (int)file->dev);

    memcpy(&process->file, file, sizeof(struct klflt_file_info));
    process->pid = pid;

    mutex_lock(&trusted_mutex);
    list_add(&process->list, &trusted_files);
    mutex_unlock(&trusted_mutex);

    return 0;
}