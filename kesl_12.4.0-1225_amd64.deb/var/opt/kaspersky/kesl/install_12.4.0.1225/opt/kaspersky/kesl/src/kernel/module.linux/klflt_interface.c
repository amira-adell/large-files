#include "klflt.h"
#include "klflt_protocol.h"
#include "files.h"

#include <asm/current.h>
#include <linux/fs.h>
#include <linux/module.h>
#include <linux/namei.h>
#include <linux/poll.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/types.h>
#include <linux/namei.h>
#include <linux/sched.h>

#define KLFLT_V2_INTERFACE_FILENAME "kav4fs_oas"
#define FS_PROTOCOL_VERSION 3

atomic_t klflt_device_busy = ATOMIC_INIT(0);
atomic_t klflt_started = ATOMIC_INIT(0);

extern klflt_module_config_t klflt_module_config;
static int monitor_major, compat_major;
static struct klflt_connection connection;
static struct klflt_interceptor_ops interceptor;

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 10, 0))
#ifndef HAVE_USERPATH
#define user_path(name, path) user_path_at_empty(AT_FDCWD, name, LOOKUP_FOLLOW, path, NULL)
#endif
#endif

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27))
static int user_path(const char __user *name, struct path *path)
{
    unsigned flags = LOOKUP_FOLLOW;
    struct nameidata nd;
    char *tmp = getname(name);
    int err = PTR_ERR(tmp);
    if (!IS_ERR(tmp)) 
    {
        BUG_ON(flags & LOOKUP_PARENT);
        err = path_lookup(tmp, flags, &nd);
        putname(tmp);

        if (!err)
        {
            path->mnt = GET_NAMEIDATA_PATH(nd).mnt; 
            path->dentry = GET_NAMEIDATA_PATH(nd).dentry;
        }
    }
    return err;
}
#endif 

void klflt_interface_v2_send_data(struct klflt_request_metadata* req)
{
    pr_debug("%s\n", __func__);

    check_req_queue_add(req);
    wake_up(&connection.request_waitq);
}

static int klflt_interface_v2_open(struct inode* inode, struct file* filp)
{
    int err   = 0;
    struct klflt_file_info file_info;

    pr_debug("Open monitor device  pid=%d\n", current->pid);

    if (atomic_read(&klflt_device_busy))
    {
        err = -EACCES;
        goto exit;
    }

    klflt_module_config.cache_enable = 0;

    pr_debug("Register monitor with pid=%d\n", current->pid);

    get_exec_info((struct task_struct __rcu *)current, &file_info);
    err = klflt_register_trusted_file(&file_info);
    if (err < 0)
    {
        pr_err("%s: Failed to register trusted file\n", __func__);
        goto exit;
    }
    err = connection_init(&connection);
    if (err < 0)
    {
        pr_err("%s: failed to initialize connection\n", __func__);
        goto exit_connection;
    }

    atomic_xchg(&klflt_device_busy, 1);

    goto exit;

exit_connection:
    klflt_trusted_unregister_file(&file_info);

exit:
    return err;
}

static int klflt_buffer_add_packet(
    struct klflt_proto_buffer* buf, struct klflt_packed_buffer* packet)
{
    u_int32_t net_len = htonl(packet->length);

    pr_debug("%s: length = %ld\n", __func__, packet->length);

    if (!klflt_proto_buffer_adjust_size(buf, sizeof(u_int32_t) + packet->length))
        return 0;

    memcpy(buf->start + buf->length, (char*)&net_len, sizeof(u_int32_t));
    buf->length += sizeof(u_int32_t);
    memcpy(buf->start + buf->length, (char*)packet->data, packet->length);
    buf->length += packet->length;

    return packet->length + sizeof(u_int32_t);
}

static int klflt_proto_buffer_add_request(
    struct klflt_proto_buffer* buf, struct klflt_request_metadata* req)
{
    int err = 0;
    int request = req->request;
    char *filename = NULL;
    char* fname_part = NULL;
    struct klflt_packed_buffer packet = {.data = NULL, .length = 0};
    struct dentry* dentry = NULL;

    pr_debug("%s: Adding request with queue_id=%d, filename=%s, vfs=%p\n",
        __func__, req->queue_id, req->name, req->vfsmnt);

    if (req->parent)
    {
        dentry = d_alloc_name(req->parent, req->name);
        if (dentry) {
            filename = get_path_by_dentry(dentry, req->vfsmnt, &err, &fname_part);
            dput(dentry);
        }
    }
    else
    {
        filename = kstrdup(req->name, GFP_KERNEL);
    }

    if (-ENAMETOOLONG == err)
    {
        req->request      = NOTIFY_FILE;
        req->file_op_type = FILE_NAME_TOO_LONG;
        filename          = fname_part ? fname_part : kstrdup(req->name, GFP_KERNEL);
    }
    else if (0 != err)
    {
        req->request = 0;
    }

    switch(req->request)
    {
        case CHECK_FILE:
            err = klflt_fill_check_event(
                &packet, klflt_module_config.version, req->euid, req->egid,
                req->pid, req->queue_id, filename, req->file_op_type,
                req->flags, req->dev, req->ino, req->mtime, req->size,
                req->owner_uid, req->file_mode, req->f_type, NULL);
            break;
        case CHECK_SIGN:
            err = -EINVAL;
            break;
        case NOTIFY_FILE:
            err = klflt_fill_notify_event(&packet, klflt_module_config.version,
                req->file_op_type, req->dev, req->ino, filename);
            break;
        case 0:
            pr_err("%s: detected request with id == 0\n", __func__);
            break;
        default:
            pr_err("%s: unexpected request %d\n", __func__, req->request);
            err = -EINVAL;
            break;
    }

    if (err > 0)
    {
        if (!klflt_buffer_add_packet(buf, &packet))
        {
            pr_err("%s: Failed to add packet\n", __func__);
            return -ENOMEM;
        }
        klflt_packed_buffer_destroy(&packet);
    }


    if (request == CHECK_FILE)
    {
        if (req->request == NOTIFY_FILE && req->file_op_type == FILE_NAME_TOO_LONG)
            err = -ENAMETOOLONG;

        if (err < 0)
        {
            if ((err == -ENAMETOOLONG) &&
                 req->file_op_type == klflt_module_config.deny_too_long_fname)
                err = 0;
            klflt_queue_set_answer(req->queue_id, err);
            klflt_queue_wakeup(req->queue_id);
        }
    }
    if (request == NOTIFY_FILE)
    {
        check_req_queue_put(req);
    }

    if (filename)
        kfree(filename);

    return 0;
}

static void klflt_fill_send_buffer(struct klflt_connection* conn, size_t count)
{
    struct klflt_proto_buffer* buf = &conn->send_buff;
    struct klflt_request_metadata* req = NULL;

    pr_debug("%s\n", __func__);

    while(buf->length < count)
    {
        req = check_req_queue_get();
        if (!req)
            return;

        klflt_proto_buffer_add_request(&conn->send_buff, req);
        check_req_queue_put(req);
    }
}

static ssize_t klflt_interface_v2_read(struct file* file, char __user *ubuf, size_t count,
                            loff_t* offset)
{
    int err = 0;
    int len = 0;

    pr_debug("%s\n", __func__);

    if (down_trylock(&connection.send_buff_mtx))
    {
        pr_debug("%s: send_buff_mtx is under lock\n", __func__);
        if ((file->f_flags & O_NONBLOCK) != 0)
            return -EAGAIN;
        if (down_interruptible(&connection.send_buff_mtx))
            return -ERESTARTSYS;
    }

    do
    {
        if ((file->f_flags & O_NONBLOCK) != 0)
        {
            if (!connection_is_data_ready(&connection))
            {
                err = -EAGAIN;
                goto out_no_read;
            }
        }
        else
        {
            if (wait_event_interruptible(connection.request_waitq,
                connection_is_data_ready(&connection)))
                err = -ERESTARTSYS;
                goto out_no_read;
        }
        if (!atomic_read(&klflt_started))
        {
            count = 0;
            break;
        }
        klflt_fill_send_buffer(&connection, count);
    } while (!connection.send_buff.length);

    len = MIN(count, connection.send_buff.length);

    if (copy_to_user(ubuf, (char *)(connection.send_buff.start), len))
    {
        pr_err("%s: copy data to userspace failed\n", __func__);
        err = -EFAULT;
        goto out_no_read;
    }

    connection.send_buff.start += len;
    connection.send_buff.length -= len;

out_no_read:
    up(&connection.send_buff_mtx);
    return err ? err : len;
}


static ssize_t klflt_interface_v2_write(
    struct file* file, const char __user *ubuf, size_t count, loff_t* offset)
{
    struct klflt_proto_buffer* buf = &connection.recv_buff;

    if (down_trylock(&connection.recv_buff_mtx))
    {
        if ((file->f_flags & O_NONBLOCK) != 0)
            return -EAGAIN;

        if (down_interruptible(&connection.recv_buff_mtx))
            return -ERESTARTSYS;
    }

    if (!klflt_proto_buffer_check_size(buf, count))
    {
        count = klflt_proto_buffer_get_free_size(buf);
        if (!count)
            return -ENOBUFS;
    }

    if (copy_from_user(buf->start + buf->length, ubuf, count))
    {
        up(&connection.recv_buff_mtx);
        return -EINVAL;
    }

    buf->length += (u_int32_t)count;

    {
        struct klflt_proto_buffer_entry packet;

        packet.begin = buf->start;
        packet.end = buf->start + buf->length;

        pr_debug("Receive buffer: buf:%p, start:%p, length:%d, capacity:%d, count:%ld\n",
            buf->data, buf->start, buf->length, buf->capacity, count);
        pr_debug("reponse size: %d", klflt_proto_buffer_get_length(buf));


        while(klflt_proto_get_next_packet(buf, &packet))
        {
            const struct klflt_response* response =
                (const struct klflt_response*)packet.begin;

            if (response->header.request == CHECK_FILE_RES)
            {
                klflt_queue_set_answer(response->queue_id, response->result);
                klflt_queue_wakeup(response->queue_id);
            }
        }
    }
    up(&connection.recv_buff_mtx);
    return count;
}

static int klflt_interface_v2_close(struct inode* inode, struct file* filp)
{
    UNUSED(inode);
    UNUSED(filp);

    pr_debug("%s\n", __func__);

    if (interceptor.stop)
        interceptor.stop();
    connection_destroy(&connection);

    atomic_xchg(&klflt_device_busy, 0);
    atomic_xchg(&klflt_started, 0);

    return 0;
}

static unsigned int klflt_interface_v2_poll(struct file* file, poll_table* wait)
{
    unsigned int ret = POLLOUT | POLLWRNORM;

    //pr_debug("%s\n", __func__);

    poll_wait(file, &connection.request_waitq, wait);

    if (down_interruptible(&connection.send_buff_mtx))
        return -ERESTARTSYS;

    if (connection_is_data_ready(&connection))
    {
        pr_debug("%s: data ready\n", __func__);
        ret = POLLIN | POLLRDNORM;
    }
    up(&connection.send_buff_mtx);

    return ret;
}

static long  klflt_interface_v2_compat_ioctl(
    struct file* file, unsigned cmd, unsigned long addr)
{
    UNUSED(file);
    UNUSED(cmd);
    UNUSED(addr);

    pr_debug("%s: cmd %d, addr %lx\n", __func__,
        cmd, addr);

    return 0;
}

static char* get_file_from_userspace(
    const char __user *u_filename, struct klflt_file_info* info, char** filename)
{

    struct path path;
    char* k_path = NULL;
    *filename    = NULL;

    /* Get kernel-space filename if user part is present */
    if (!u_filename)
        return NULL;

    if (user_path(u_filename, &path))
        return NULL;

    k_path    = get_path_by_dentry(path.dentry, path.mnt, NULL, NULL);
    *filename = k_path;

    klflt_fill_file_info(path.dentry, info);
    path_put(&path);

    return k_path;
}

typedef struct {
    int32_t  chache_size;
    int32_t  version;
    uint32_t max_fname_length;
    int8_t   deny_too_long_fname;
} interface_v2_config_ioctl;

typedef struct
{
    int pid;
    char* path;
} interface_v2_proc_ioctl;

#define KLFLT_REGISTER_CMD_OLD_COMPAT 0x10
#define KLFLT_GROUP_CMD_OLD_COMPAT 0x11
#define KLFLT_CONFIG_CMD_OLD_COMPAT 0x21

#define KLFLT_REGISTER_CMD_COMPAT _IO('K', 0x10)
#define KLFLT_GROUP_CMD_COMPAT _IO('K', 0x11)
#define KLFLT_CONFIG2_CMD _IOW('K', 0x22, interface_v2_config_ioctl)

#define KLFLT_REGISTER_FILE_CMD _IO('K', 0x50)
#define KLFLT_REGISTER_PROC_CMD _IO('K', 0x51)
#define KLFLT_PING_CMD _IO('K', 0x52)
#define KLFLT_CLEAR_CACHE_CMD _IO('K', 0x53)
#define KLFLT_START _IO('K', 0x54)


//------------------
typedef struct
{
    int cache_size;
} monitor_config_ioctl;

typedef struct
{
    int32_t cache_size;
    int32_t version;
    uint32_t max_fname_len;     /* maximum file name length, default is 16K */
    int8_t deny_too_long_fname; /* (bool) deny accsess if a file name length >
                                   max_fname_len */
} monitor_config2_ioctl;
#pragma pack(1)

#define MONITOR_REGISTER_CMD_OLD_COMPAT 0x10
#define MONITOR_GROUP_CMD_OLD_COMPAT 0x11
#define MONITOR_CONFIG_CMD_OLD_COMPAT 0x21

#define MONITOR_REGISTER_CMD_COMPAT _IO('K', 0x10)
#define MONITOR_GROUP_CMD_COMPAT _IO('K', 0x11)
#define MONITOR_CONFIG_CMD _IOW('K', 0x21, monitor_config_ioctl)
#define MONITOR_CONFIG2_CMD _IOW('K', 0x22, monitor_config2_ioctl)

#define MONITOR_REGISTER_FILE_CMD _IO('K', 0x50)
#define MONITOR_REGISTER_PROC_CMD _IO('K', 0x51)
#define MONITOR_PING_CMD _IO('K', 0x52)
#define MONITOR_CLEAR_CACHE_CMD _IO('K', 0x53)
#define MONITOR_START _IO('K', 0x54)

#pragma pack()
//------------------

long  klflt_interface_v2_unlocked_ioctl(
    struct file* filp, unsigned cmd, unsigned long addr)
{
    struct klflt_file_info f_info;
    interface_v2_config_ioctl config;
    interface_v2_proc_ioctl proc_param;
    pid_t pid;
    char* path;
    int err;

    pr_debug("%s: cmd %d, addr %lx\n", __func__,
        cmd, addr);

    pr_debug("config2_cmd=%ld, mconfig=%ld, mconfig2=%ld, size=%ld rf=%d, rp=%d, clear=%d, start=%d\n",
        KLFLT_CONFIG2_CMD,
        MONITOR_CONFIG_CMD,
        MONITOR_CONFIG2_CMD,
        sizeof(monitor_config2_ioctl),
        KLFLT_REGISTER_FILE_CMD,
        KLFLT_REGISTER_PROC_CMD,
        KLFLT_CLEAR_CACHE_CMD,
        KLFLT_START);

    switch (cmd)
    {
    case KLFLT_REGISTER_FILE_CMD:
        pr_debug("\tRegister file command pid=%d\n", current->pid);
        if (get_file_from_userspace((char __user *)addr, &f_info, &path))
            return -EINVAL;

        kfree(path);
        return klflt_register_trusted_file(&f_info);

    case KLFLT_REGISTER_PROC_CMD:
        pr_debug("\tRegister proc cmd pid=%d\n", current->pid);

        if (copy_from_user(&proc_param, (void __user *)addr,
            sizeof(proc_param)))
        {
            printk(KERN_ERR "%s: Failed to register trusted process\n", __func__);
            return -EFAULT;
        }

        if (!proc_param.pid)
        {
            printk(KERN_ERR "%s: Pid is not set\n", __func__);
            return -EFAULT;
        }
        pid = (pid_t)proc_param.pid;

        if (!get_file_from_userspace(proc_param.path, &f_info, &path))
        {
            printk(KERN_ERR "%s: Path not set\n", __func__);
            return -EFAULT;
        }
        return klflt_register_trusted_process(pid, &f_info);


    case KLFLT_CONFIG2_CMD:
        pr_debug("%s: klflt_config2\n", __func__);

        if (copy_from_user(&config, (void __user*)addr, sizeof(config)))
        {
            printk(KERN_ERR "%s: Incorrect config params\n", __func__);
            return -EINVAL;
        }

        if (config.version != FS_PROTOCOL_VERSION)
        {
            printk(KERN_ERR "%s: Protocol %d is not supported\n",
                __func__, config.version);
            return -EOPNOTSUPP;
        }

        klflt_module_config.version = config.version;
        klflt_module_config.cache_enable = config.chache_size ? 1 : 0;
        klflt_module_config.cache_size = config.chache_size;
        klflt_module_config.max_fname_len = config.max_fname_length;
        klflt_module_config.deny_too_long_fname = config.deny_too_long_fname;
        pr_debug("klflt_start: version=%d, start=%p, stop=%p\n",
            klflt_module_config.version, interceptor.start, interceptor.stop);

        return 0;

    case KLFLT_START:
        pr_debug("%s: klflt_start\n", __func__);

        if (klflt_module_config.version < 3 ||
                         !interceptor.start ||
                         !interceptor.stop)
        {
            pr_debug("klflt_start: version=%d, start=%p, stop=%p\n",
                klflt_module_config.version, interceptor.start, interceptor.stop);
            return -EOPNOTSUPP;
        }

        err = interceptor.start();
        if (err != 0)
        {
            pr_err("Failed to start kernel interceptor. err=%d\n", err);
            return -EFAULT;
        }

        atomic_xchg(&klflt_started, 1);

        return err;

    case KLFLT_PING_CMD:

        return 0;

    case KLFLT_CLEAR_CACHE_CMD:
        klflt_cache_clear();
        return 0;
    } /* switch */

    pr_debug("%s: unknown ioctl command\n", __func__);

    return -EINVAL;
}

struct file_operations klflt_interface_v2_fop = {
    .owner = THIS_MODULE,
    .open = klflt_interface_v2_open,
    .unlocked_ioctl = klflt_interface_v2_unlocked_ioctl,
    .compat_ioctl = klflt_interface_v2_compat_ioctl,
    .release = klflt_interface_v2_close,
    .poll = klflt_interface_v2_poll,
    .read = klflt_interface_v2_read,
    .write = klflt_interface_v2_write
};

struct user_command
{
    char const* prefix;
    int (*invoke)(char const* arg);
};

static struct user_command user_commands[] = {
    {"put ", klflt_cmd_put_path},  {"get ", klflt_cmd_get_path},
    {"itr ", klflt_cmd_in_trace},  {"dtr ", klflt_cmd_de_trace},
    {"rtr ", klflt_cmd_rs_trace},  {"exc ", klflt_cmd_add_excl},
    {"rst ", klflt_cmd_rst_excl},
};

#define PREFIX_LEN 4

static ssize_t klflt_interface_v2_proc_write(
    struct file* file, const char __user *ubuf, size_t len, loff_t* offset)
{
    int res = -EIO;
    char prefix[PREFIX_LEN];
    char* mpath;
    int i, action = -1;

    if (*offset || len < PREFIX_LEN)
        return -EIO;

    if (copy_from_user(prefix, ubuf, PREFIX_LEN))
        return -EIO;

    for (i = 0; i < ARRAY_SIZE(user_commands); i++)
        if (!strncmp(prefix, user_commands[i].prefix, PREFIX_LEN))
        {
            action = i;
            break;
        }
    if (-1 == action)
        return -ENOSYS;

    mpath = (len - PREFIX_LEN) ? kmalloc(len - PREFIX_LEN, GFP_KERNEL) : NULL;
    if (!mpath)
        return -ENOMEM;

    if (copy_from_user(mpath, ubuf + PREFIX_LEN, len - PREFIX_LEN))
        goto pwout;

    if (mpath[len - PREFIX_LEN - 1] != '\n')
        goto pwout;

    mpath[len - PREFIX_LEN - 1] = '\0';

    res = user_commands[action].invoke(mpath);
pwout:
    kfree(mpath);
    return res ? res : (*offset = len);
}

static int klflt_interface_v2_proc_print(struct seq_file* m, void* v)
{
    seq_printf(m, "%d \n%d %d %d\n%d %d\n", FS_PROTOCOL_VERSION,
            monitor_major, 0, atomic_read(&klflt_started), compat_major, 0);
    return 0;
}

static int klflt_interface_v2_proc_open(struct inode* inode, struct file* file)
{
    return single_open(file, klflt_interface_v2_proc_print, NULL);
}

static const struct file_operations klflt_interface_v2_proc_fops = {
    .owner    = THIS_MODULE,
    .open     = klflt_interface_v2_proc_open,
    .read     = seq_read,
    .write    = klflt_interface_v2_proc_write,
    .llseek   = seq_lseek,
    .release  = single_release,
};


int klflt_interface_v2_init(struct klflt_interceptor_ops* interceptor_ops)
{
//    TODO: move into klflt_module_init
//    Monitor_queue_init();
//    check_req_queue_init();

    pr_debug("klflt_interface_v2_init\n");

    interceptor.start = interceptor_ops->start;
    interceptor.stop  = interceptor_ops->stop;

    /* register the avir monitor device */
    monitor_major = register_chrdev(0, KLFLT_V2_INTERFACE_FILENAME,
        &klflt_interface_v2_fop);
    register_chrdev(monitor_major, KLFLT_V2_INTERFACE_FILENAME,
        &klflt_interface_v2_fop);

    compat_major = 0;

    if (!proc_create(KLFLT_V2_INTERFACE_FILENAME, 0, NULL,
        &klflt_interface_v2_proc_fops))
    {
        printk(KERN_ERR "klflt: Warning! Failed to create proc %s\n",
               KLFLT_V2_INTERFACE_FILENAME);
        return -1;
    }

    return 0;
};

void klflt_interface_v2_destroy(void)
{
    pr_debug("klflt_interface_v2_destroy\n");

    remove_proc_entry(KLFLT_V2_INTERFACE_FILENAME, NULL);

    unregister_chrdev(monitor_major, "kav4fs_oas");
}

