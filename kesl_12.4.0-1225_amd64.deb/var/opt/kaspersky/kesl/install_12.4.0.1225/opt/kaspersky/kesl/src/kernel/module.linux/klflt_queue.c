/*
 * This source file is a part of a Kaspersky Antivirus Monitor.
 * Copyright (C) Kaspersky Lab, 1997-2010
 * See License.txt for details
 *
 */
#include "klflt.h"
#include "klflt_protocol.h"

#include <asm/current.h>
#include <linux/delay.h>
#include <linux/fs.h>
#include <linux/list.h>
#include <linux/module.h>
#include <linux/spinlock_types.h>
#include <linux/sched.h>

struct mqueue_entry
{
    struct kref refcnt;
    rwlock_t lock;
    u_short queue_id;
    int flags;
    short blocked;
    int answer;
    wait_queue_head_t waitq;
    struct list_head list;
};
typedef struct mqueue_entry mqueue_entry_t;

#define O_MQUEUE_READY 0x02
#define O_MQUEUE_TESTING 0x04

static atomic_t queue_started = ATOMIC_INIT(0);

static DEFINE_MUTEX(monitor_queue_lock);
static LIST_HEAD(monitor_queue);
atomic_t last_queue_id = ATOMIC_INIT(0);

static LIST_HEAD(check_req_queue);
static DEFINE_MUTEX(check_req_queue_lock);

extern void klflt_interface_v2_send_data(struct klflt_request_metadata* req);

static void klflt_mqueue_entry_release(struct kref *ref)
{
    mqueue_entry_t *entry = container_of(ref, mqueue_entry_t, refcnt);

    pr_debug("%s: queue_id:%d\n", __func__, entry->queue_id);

    list_del(&entry->list);
    kfree(entry);
}

static struct mqueue_entry* get_mqueue_entry_by_queue_id(u_short queue_id)
{
    struct mqueue_entry* entry;

    pr_debug("%s: queue_id = %d\n", __func__, queue_id);

    mutex_lock(&monitor_queue_lock);
    list_for_each_entry(entry, &monitor_queue, list)
    {
        if (entry->queue_id == queue_id)
        {
            kref_get(&entry->refcnt);
            mutex_unlock(&monitor_queue_lock);
            return entry;
        }
    }
    entry = NULL;
    mutex_unlock(&monitor_queue_lock);

    return entry;
}

static void mqueue_entry_put(struct mqueue_entry* entry)
{
    pr_debug("%s, queuq_id=%d, ref=%d\n", __func__,
        entry->queue_id, atomic_read(&entry->refcnt.refcount));
    mutex_lock(&monitor_queue_lock);
    kref_put(&entry->refcnt, klflt_mqueue_entry_release);
    mutex_unlock(&monitor_queue_lock);
}

int klflt_queue_get_id(void)
{
    u_short queue_id;
    mqueue_entry_t* entry;

    pr_debug("%s\n", __func__);

again:
    queue_id = (u_short)atomic_inc_return(&last_queue_id);

    mutex_lock(&monitor_queue_lock);
    list_for_each_entry(entry, &monitor_queue, list)
    {
        if (entry->queue_id == queue_id) {
            mutex_unlock(&monitor_queue_lock);
            goto again;
        }
    }
    mutex_unlock(&monitor_queue_lock);

    return queue_id;
}

void klflt_queue_set_answer(u_short queue_id, int answer)
{
    mqueue_entry_t* entry;

    pr_debug("%s: queue_id=%d, answer=%d\n", __func__, queue_id, answer);

    entry = get_mqueue_entry_by_queue_id(queue_id);
    if (entry) {
        entry->answer = answer;
        mqueue_entry_put(entry);
    }
}

void klflt_queue_wakeup(u_short queue_id)
{
    mqueue_entry_t* entry = get_mqueue_entry_by_queue_id(queue_id);

    pr_debug("%s: queue_id = %d, entry=%p\n", __func__, queue_id, entry);

    if (entry) {
        if (!entry->blocked)
            wake_up_interruptible(&entry->waitq);
        else
            wake_up(&entry->waitq);
        mqueue_entry_put(entry);
    }
}

int klflt_queue_add(
    u_short queue_id, int block, struct klflt_request_metadata* reqd,
    enum KlFileAccessType* answer, unsigned long int timeout)
{
    mqueue_entry_t* entry;
    int res, remaining;
    wait_queue_t wait;

    pr_debug("%s: %s, id: %d, pid: %d\n",
        __func__, reqd->name, queue_id, reqd->pid);

    if (!atomic_read(&queue_started))
    {
        *answer = FILE_ACCESS_ACCEPT;
        return 0;
    }

    entry = kmalloc(sizeof(mqueue_entry_t), GFP_KERNEL);
    if (!entry)
    {
        pr_err("%s: Queue memory allocation error\n", __func__);
        return -ENOMEM;
    }

    entry->queue_id = queue_id;
    entry->answer = *answer;
    entry->flags   = O_MQUEUE_READY;
    entry->blocked = block;
    kref_init(&entry->refcnt);

    mutex_lock(&monitor_queue_lock);
    list_add(&entry->list, &monitor_queue);
    init_waitqueue_head(&entry->waitq);
    init_waitqueue_entry(&wait, current);
    add_wait_queue(&entry->waitq, &wait);
    set_current_state(block ? TASK_UNINTERRUPTIBLE : TASK_INTERRUPTIBLE);
    reqd->queue_id = queue_id;
    klflt_interface_v2_send_data(reqd);
    mutex_unlock(&monitor_queue_lock);

    if (timeout != MAX_SCHEDULE_TIMEOUT) {
        remaining = schedule_timeout(msecs_to_jiffies(timeout));
    } else {
        remaining = 0;
        schedule();
    }

    pr_debug("%s finished: %s, id: %d, pid: %d, remaining:%d, answer:%d\n",
        __func__, reqd->name, reqd->queue_id, reqd->pid, remaining, entry->answer);

    remove_wait_queue(&entry->waitq, &wait);
    entry->flags &= ~O_MQUEUE_TESTING;
    res = entry->answer;
    mqueue_entry_put(entry);

    if (remaining)
        return 1;

    if (res < 0)
        return res;

    *answer = res;

    return 0;
}

static void check_req_entry_release(struct kref *ref)
{
    struct klflt_request_metadata* reqd =
        container_of(ref, struct klflt_request_metadata, refcnt);

    pr_debug("%s: req:%p\n", __func__, reqd);

    mutex_lock(&check_req_queue_lock);
    if (!list_empty(&reqd->list))
        list_del_init(&reqd->list);
    mutex_unlock(&check_req_queue_lock);

    if (reqd->name)
        kfree(reqd->name);
    if (reqd->parent)
        dput(reqd->parent);
    if (reqd->vfsmnt)
        mntput(reqd->vfsmnt);
    kfree(reqd);
}

void check_req_queue_add(struct klflt_request_metadata* reqd)
{
    pr_debug("%s\n", __func__);

    mutex_lock(&check_req_queue_lock);
    list_add_tail(&reqd->list, &check_req_queue);
    kref_get(&reqd->refcnt);
    mutex_unlock(&check_req_queue_lock);
}

struct klflt_request_metadata* check_req_queue_get(void)
{
    struct klflt_request_metadata* res;

    pr_debug("%s\n", __func__);

    mutex_lock(&check_req_queue_lock);
    if (list_empty(&check_req_queue))
        res = NULL;
    else
    {
        res = list_entry(check_req_queue.next, struct klflt_request_metadata, list);
        list_del_init(&res->list);
    }
    mutex_unlock(&check_req_queue_lock);

    return res;
}

int check_req_queue_put(struct klflt_request_metadata* reqd)
{
    pr_debug("%s: req: %p\n", __func__, reqd);

    //mutex_lock(&check_req_queue_lock);
    kref_put(&reqd->refcnt, check_req_entry_release);
    //mutex_unlock(&check_req_queue_lock);
    return 1;
}

int check_req_queue_empty(void)
{
    int res;

    //pr_debug("%s\n", __func__);

    mutex_lock(&check_req_queue_lock);
    res = list_empty(&check_req_queue);
    mutex_unlock(&check_req_queue_lock);

    return res;
}

int klflt_queue_init(void)
{
    pr_debug("%s\n", __func__);

    INIT_LIST_HEAD(&monitor_queue);
    atomic_set(&last_queue_id, 0);
    INIT_LIST_HEAD(&check_req_queue);
    atomic_set(&queue_started, 1);

    return 0;
}

void klflt_queue_clear(void)
{
    mqueue_entry_t* entry;
    int timeout = 20000;
    int count = 0;

    pr_debug("%s\n", __func__);

    /* Wake up all processes in the queue */

    mutex_lock(&monitor_queue_lock);
    list_for_each_entry(entry, &monitor_queue, list)
    {
	    ++count;
        if (entry->flags)
        {
            if (!entry->blocked)
                wake_up_interruptible(&entry->waitq);
            else
                wake_up(&entry->waitq);
        }
    }
    mutex_unlock(&monitor_queue_lock);

    pr_debug("%s: start cleaning queue. Waiting for %d tasks\n", __func__, count);

    mutex_lock(&monitor_queue_lock);
    while (!list_empty(&monitor_queue))
    {
        if (--timeout < 1)
        {
            pr_err("%s: klflt queue is not empty on destruction.\n", __func__);
            break;
        }
        mutex_unlock(&monitor_queue_lock);
        msleep(1);
        mutex_lock(&monitor_queue_lock);
    }
    mutex_unlock(&monitor_queue_lock);
    pr_debug(KERN_INFO "Queue clean. Iterations: %d\n", 20000 - timeout);
}

void klflt_queue_destroy(void)
{
    pr_debug("%s\n", __func__);
    atomic_xchg(&queue_started, 0);

    klflt_queue_clear();
}
