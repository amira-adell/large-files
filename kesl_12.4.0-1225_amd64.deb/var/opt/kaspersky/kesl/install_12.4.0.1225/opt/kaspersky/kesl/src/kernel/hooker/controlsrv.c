#include <linux/kernel.h>
#include <linux/net.h>
#include <linux/version.h>
#include <linux/delay.h>
#include <net/sock.h>
#include <linux/reboot.h>
#include <linux/smp_lock.h>
#include <net/tcp.h>

extern int dump_message(char const* fmt, ...);
// extern void dump_syscalls(char const *args);
// extern void turn_syscalls(char const *args);
extern void drop_client(char const* args);

extern void raise_panic(char const* args)
{
    dump_message("going panic!\n");
    panic("pwned for lulz");
}
extern void drop_machine(char const* args)
{
    kernel_restart(NULL);
}
extern void dump_inform(char const* args)
{
    dump_message("module use count %i\n", module_refcount(THIS_MODULE));
}

extern void task_inform(char const* args)
{
    struct task_struct* p;
    for_each_process(p)
    {
        dump_message("%4s: %16s state %2li cpu %2u pid %6i\n",
                     (p == current) ? "----" : "task", p->comm, p->state, 0, p->pid);
    }
}

struct dbg_command
{
    char const* text;
    void (*proc)(char const*);
};
static struct dbg_command dbg_commands[] = {
    //	{ "sc", dump_syscalls },
    {"panic", raise_panic}, {"drop", drop_machine}, {"quit", drop_client},
    {"exit", drop_client},  {"info", dump_inform},  {"task", task_inform},
    //	{ "dump", turn_syscalls },
};

static atomic_t dumped = ATOMIC_INIT(0);
static atomic_t repeat = ATOMIC_INIT(0);
static atomic_t atimer = ATOMIC_INIT(0);

void dump_periodic(void)
{
    if (!atomic_read(&dumped))
        atomic_inc(&repeat);

    if (atomic_read(&dumped) || (atomic_read(&repeat) > 300))
    {
        //		dump_syscalls(NULL);

        atomic_set(&repeat, 0);
        atomic_set(&dumped, 0);
    }

    atomic_dec(&atimer);
}

void timer_func(unsigned long __data);

static DEFINE_TIMER(_timer, timer_func, 0, 0);

void timer_func(unsigned long __data)
{
    atomic_inc(&atimer);
    mod_timer(&_timer, jiffies + HZ);
}

static int server_thread(void* arg);

static struct socket* _server = NULL;
static atomic_t srv_running   = ATOMIC_INIT(0);
static atomic_t srv_closing   = ATOMIC_INIT(1);

#define MSG_BUF_SIZE PAGE_SIZE

#ifndef DEFINE_SEMAPHORE
static DECLARE_MUTEX(output_lock);
#else
static DEFINE_SEMAPHORE(output_lock);
#endif

static struct socket* output_sock = NULL;
static atomic_t output_drop       = ATOMIC_INIT(0);

void drop_client(char const* args)
{
    atomic_set(&output_drop, -EBUSY);
}

int dump_message(char const* fmt, ...)
{
    char buf[256];
    size_t len;
    va_list args;

    down(&output_lock);
    if (!output_sock || atomic_read(&output_drop))
    {
        up(&output_lock);
        return 0;
    }

    va_start(args, fmt);
    len = vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);

    len      = (len < 256) ? len : 256;
    buf[255] = '\n';

    {
        int error         = 0;
        struct kvec iov[] = {{.iov_base = buf, .iov_len = len}};
        struct msghdr msg = {.msg_flags = MSG_DONTWAIT};

        error = kernel_sendmsg(output_sock, &msg, iov, ARRAY_SIZE(iov), len);

        if (error < 0)
        {
            printk("drop output with %i\n", error);
            atomic_set(&output_drop, 0);
        }
    }

    up(&output_lock);

    atomic_inc(&dumped);

    return len;
}

int init_server(unsigned short port)
{
    struct socket* sock;
    struct sockaddr_in sin;
    int error = sock_create_kern(PF_INET, SOCK_STREAM, IPPROTO_TCP, &sock);

    if (error < 0)
        return error;

    sin.sin_family      = AF_INET;
    sin.sin_addr.s_addr = INADDR_ANY;
    sin.sin_port        = htons((unsigned short)port);

    error = kernel_bind(sock, (struct sockaddr*)&sin, sizeof(sin));
    if (error < 0)
    {
        sock_release(sock);
        return error;
    }

    sock->sk->sk_reuse = 1;

    error = kernel_listen(sock, 3);
    if (error < 0)
    {
        sock_release(sock);
        return error;
    }

    _server = sock;

    atomic_set(&srv_running, 1);
    kernel_thread(&server_thread, NULL, 0);

    return 0;
}

void exit_server(void)
{
    struct socket* sock;

    if (_server == NULL)
        return;

    atomic_set(&srv_running, 0);

    while (atomic_read(&srv_closing))
        ssleep(1);

    sock    = _server;
    _server = NULL;
    sock_release(sock);
}

#define SRV_MAJOR 0
#define SRV_MINOR 3

static int server_thread(void* arg)
{
    int error = 0;

    if (!(_server))
        return -EINVAL;

    while (atomic_read(&srv_running))
    {
        struct socket* _client;

        error = kernel_accept(_server, &_client, O_NONBLOCK);
        if (error < 0)
        {
            yield();
            continue;
        }

        down(&output_lock);
        output_sock = _client;
        atomic_set(&output_drop, 0);
        up(&output_lock);

        yield();

        dump_message("welcome: kav4fs debug server %u.%u!\n", SRV_MAJOR, SRV_MINOR);

        mod_timer(&_timer, jiffies + HZ);

        yield();

        while (!atomic_read(&output_drop) && atomic_read(&srv_running))
        {
            size_t len = 256;
            char buf[256];
            struct kvec iov[] = {{.iov_base = buf, .iov_len = len}};
            struct msghdr msg = {.msg_flags = MSG_DONTWAIT};
            down(&output_lock);

            error = kernel_recvmsg(output_sock, &msg, iov, ARRAY_SIZE(iov), len,
                                   MSG_DONTWAIT);

            len = 0;
            if (error <= 0 && error != -EAGAIN)
                atomic_set(&output_drop, error ? error : -EAGAIN);
            else if (error > 0)
            {
                len = (error < 256) ? error : 256;
                while (buf[len - 1] == '\r' || buf[len - 1] == '\n')
                    buf[--len] = '\0';
            }

            up(&output_lock);

            yield();

            if (len)
            {
                int i;
                for (i = 0; i < ARRAY_SIZE(dbg_commands); i++)
                    if (!strncmp(dbg_commands[i].text, buf,
                                 strlen(dbg_commands[i].text)))
                    {
                        dbg_commands[i].proc(buf + strlen(dbg_commands[i].text));
                        break;
                    }
            }

            yield();

            if (atomic_read(&atimer))
                dump_periodic();
        }

        if (!atomic_read(&output_drop))
            dump_message("get out: kav4fs debug server %u.%u!\n", SRV_MAJOR,
                         SRV_MINOR);

        yield();

        down(&output_lock);
        output_sock = NULL;
        sock_release(_client);
        up(&output_lock);
    }

    atomic_set(&srv_closing, 0);

    return atomic_read(&output_drop);
}

EXPORT_SYMBOL(init_server);
EXPORT_SYMBOL(exit_server);
EXPORT_SYMBOL(dump_message);
