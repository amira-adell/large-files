#include "klflt.h"
#include "files.h"
#include "mount.h"

#include <asm/current.h>
#include <linux/delay.h>
#include <linux/kthread.h>
#include <linux/list.h>
#include <linux/mount.h>
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 10, 0))
#include <linux/mnt_namespace.h>
#endif
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 19))
#include <linux/nsproxy.h>
#endif
#include <linux/namei.h>
#include <linux/sched.h>
#include <linux/seq_file.h>
#include <linux/spinlock.h>

struct klflt_mnt
{
    struct vfsmount* mnt;
    struct list_head list;
};

static LIST_HEAD(klflt_mnt_list);
static DEFINE_RWLOCK(klflt_mnt_rwlock);
struct file* mounts                = NULL;
static struct mnt_namespace* nsp;
const struct seq_operations* nsops = NULL;
struct klflt_mounts_ops mounts_ops;
static atomic_t mounts_handler_started = ATOMIC_INIT(0);
static atomic_t proc_mounts_started = ATOMIC_INIT(0);
static struct task_struct* mountsd = NULL;
static int event = 0;

int klflt_get_path_unsafe(char const* mntfile);
int klflt_put_path_unsafe(char const* mntfile);

static int open_proc_mounts(void)
{
    mounts = filp_open(MOUNTS_FILENAME, O_RDONLY, 0);

    if (!IS_ERR(mounts))
    {
        struct seq_file* p              = mounts ? mounts->private_data : NULL;
        const struct seq_operations* op = nsops = p ? p->op : NULL;

        mounts =
            (op && op->start && op->next && op->stop) ? mounts : ERR_PTR(-ENOSYS);
    }

    if (IS_ERR(mounts))
        return PTR_ERR(mounts);

    atomic_xchg(&proc_mounts_started, 1);

    return 0;
}

static void close_proc_mounts(void)
{
    nsops = NULL;

    atomic_xchg(&proc_mounts_started, 1);

    filp_close(mounts, NULL);
    mounts = NULL;
}

static struct klflt_mnt* is_mnt_marked(struct vfsmount* vfs,
                                        struct list_head* kmntlist)
{
    struct klflt_mnt* kmnt;

    list_for_each_entry(kmnt, kmntlist, list) {
        if (vfs == kmnt->mnt)
            return kmnt;
    }

    return NULL;
}

static int make_kmnt(struct vfsmount* mnt)
{
    //void* err = redirfs_add_path(klflt, mnt, mnt->mnt_root, REDIRFS_PATH_INCLUDE);
    int rc = -1;
    struct klflt_mnt* kmnt;

    if (mounts_ops.add_mount) {
        rc = mounts_ops.add_mount(mnt);
    }

    if (rc < 0) {
        pr_err("%s: failed to add %p %s\n",
            __func__, mnt, real_mount(mnt)->mnt_mountpoint->d_name.name);
        return rc;
    }

    pr_debug("Add %p %s\n", mnt, real_mount(mnt)->mnt_mountpoint->d_name.name);

    kmnt = kmalloc(sizeof(struct klflt_mnt), GFP_KERNEL);
    kmnt->mnt = mntget(mnt);
    list_add_tail(&kmnt->list, &klflt_mnt_list);

    return 0;
}

static void free_kmnt(struct klflt_mnt* kmnt, int noflt)
{
    int rc = -EFAULT;

    pr_debug("Remove %p %s\n",
        kmnt->mnt, real_mount(kmnt->mnt)->mnt_mountpoint->d_name.name);

    if (!noflt)
    {
        //int err = redirfs_rem_path(klflt, kmnt->mnt, kmnt->mnt->mnt_root);
        if (mounts_ops.remove_mount) {
            rc = mounts_ops.remove_mount(kmnt->mnt);
        }
        if (rc < 0)
            printk("klflt: rem path failed: %i\n", rc);
    }

    list_del_init(&kmnt->list);
    mntput(kmnt->mnt);
    kfree(kmnt);
}

/*
 *	kavoas_mnt_rwlock should be locked by caller!
 */
static int interceptor_get_path_helper(struct vfsmount* vfs, int force)
{
    pr_debug("%s: vfs = %p, force = %d\n", __func__, vfs, force);

    if (is_smb_magic(vfs->mnt_root->d_inode->i_sb->s_magic))
    {
        pr_debug("%s: Adding SMB filesystem %p\n", __func__, vfs);
        if (mounts_ops.cifs_calls_replace)
            mounts_ops.cifs_calls_replace(vfs->mnt_root);
        return 0;
    }
    else if (is_exclude_magic(vfs->mnt_root->d_inode->i_sb->s_magic))
    {
        pr_debug("%s: %p excluded by magic\n", __func__, vfs);
        return 0;
    }
    else if (is_mnt_marked(vfs, &klflt_mnt_list))
    {
        pr_debug("%s: force: %d, %p is marked, excluding\n", __func__, force, vfs);
        return 0;
    }
    else if (vfs->mnt_flags & KLFLT_MNT_SKIP)
    {
        pr_debug("%s: skip vfs %p as excluded\n", __func__, vfs);
    }

    return make_kmnt(vfs);
}

/*
 *	klflt_mnt_rwlock should be locked by caller!
 */
static int interceptor_put_path_helper(struct vfsmount* vfs, int force)
{
    struct klflt_mnt* kmnt;
    int found = 0;
    while ((kmnt = is_mnt_marked(vfs, &klflt_mnt_list)))
        free_kmnt(kmnt, found++);

    return 0;
}

static int klflt_update_all_mounts(void)
{
    struct klflt_mnt *kmnt, *tmp;
    struct seq_file* m = mounts->private_data;
    loff_t pos         = 0;
    void* p            = NULL;

    p = nsops->start(m, &pos);

    pr_debug("%s: p = %p\n", __func__, p);

    if (nsp->event == event)
    {
        nsops->stop(m, p);
        return 0;
    }
    else
    {
        event = nsp->event;
    }

    write_lock(&klflt_mnt_rwlock);
    list_for_each_entry_safe(kmnt, tmp, &klflt_mnt_list, list)
    {
        if (list_empty(&real_mount(kmnt->mnt)->mnt_list))
        {
            free_kmnt(kmnt, 0);
        }
    }

    while (p && !IS_ERR(p))
    {
        struct vfsmount* vfs = GET_VFSMNT(p);
        interceptor_get_path_helper(vfs, 0);
        p = nsops->next(m, p, &pos);
    }
    write_unlock(&klflt_mnt_rwlock);

    nsops->stop(m, p);

    return 0;
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(3,19,0)

static int check_mnt_ns(void)
{
    int ret            = 0;
    struct seq_file* m = mounts->private_data;
    loff_t pos         = 0;

    if (kthread_should_stop())
        return 1;
    nsops->start(m, &pos);
    ret = !(nsp->event == event);
    nsops->stop(m, NULL);

    return ret;
}

static int mounts_poll(void* arg)
{
    while (!kthread_should_stop())
    {
        if (klflt_update_all_mounts())
            msleep(1000);
        wait_event_interruptible(nsp->poll, check_mnt_ns());
    }
    return 0;
}

#else

static int mounts_poll(void *arg)
{
        DEFINE_WAIT_FUNC(wait, woken_wake_function);

        add_wait_queue(&nsp->poll, &wait);
        while (!kthread_should_stop()) {
                if (nsp->event != event) {
                        klflt_update_all_mounts();
                }
                wait_woken(&wait, TASK_INTERRUPTIBLE, MAX_SCHEDULE_TIMEOUT);
        }
        remove_wait_queue(&nsp->poll, &wait);

        return 0;
}

#endif

static struct vfsmount* find_mnt_by_dev(char const* name, int action)
{
    struct vfsmount* res = ERR_PTR(-ENOENT);
    struct seq_file* m   = mounts->private_data;
    loff_t pos           = 0;
    void* p              = NULL;

    if (!name)
        return ERR_PTR(-ENOMEM);

    p = nsops->start(m, &pos);

    while (p && !IS_ERR(p))
    {
        struct vfsmount* vfs         = GET_VFSMNT(p);
        struct klflt_mnt* in_kavoas = is_mnt_marked(vfs, &klflt_mnt_list);

        if (real_mount(vfs)->mnt_devname &&
            !strcmp(real_mount(vfs)->mnt_devname, name))
        {
            if (action)
            {
                if (!in_kavoas)
                {
                    res = vfs;
                    break;
                }
                else if (IS_ERR(res))
                {
                    res = ERR_PTR(-EBUSY);
                }
            }
            else
            {
                if (in_kavoas)
                {
                    res = vfs;
                }
                else if (IS_ERR(res))
                {
                    res = ERR_PTR(-EBUSY);
                }
            }
        }

        p = nsops->next(m, p, &pos);
    }

    nsops->stop(m, p);

    return res;
}

static struct vfsmount* find_mnt_by_mnt(struct vfsmount* vfs, int action)
{
    struct vfsmount* res = ERR_PTR(-EBUSY);

    do
    {
        struct klflt_mnt* in_kavoas = is_mnt_marked(vfs, &klflt_mnt_list);

        if (action)
        {
            if (!in_kavoas)
                res = vfs;
        }
        else
        {
            if (in_kavoas)
            {
                res = vfs;
                break;
            }
        }

        if (IS_ROOT(real_mount(vfs)->mnt_mountpoint))
            vfs = base_mount(real_mount(vfs)->mnt_parent);
        else
            break;
    } while (!same_as_current_fs_root(vfs, vfs->mnt_root) &&
             !(real_mount(vfs) == real_mount(vfs)->mnt_parent));

    return res;
}

static struct vfsmount* interceptor_find_mnt(char const* mntfile, int action)
{
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 25))
    struct path nd;
    int badpath = kern_path(mntfile, LOOKUP_FOLLOW, &nd);
#elif (LINUX_VERSION_CODE < KERNEL_VERSION(3, 19, 0))
    struct nameidata nd;
    int badpath = kern_path(mntfile, LOOKUP_FOLLOW, &nd.path);
#else
    struct path nd;
    int badpath = kern_path(mntfile, LOOKUP_FOLLOW, &nd);
#endif


    char const* name =
        badpath ? kstrdup(mntfile, GFP_KERNEL)
                : get_path_by_dentry(GET_NAMEIDATA_PATH(nd).dentry,
                                     GET_NAMEIDATA_PATH(nd).mnt, NULL, NULL);

    int isdevname = (badpath || (GET_NAMEIDATA_PATH(nd).dentry !=
                                 GET_NAMEIDATA_PATH(nd).mnt->mnt_root));

    struct vfsmount* vfs = isdevname
                               ? find_mnt_by_dev(mntfile, action)
                               : find_mnt_by_mnt(GET_NAMEIDATA_PATH(nd).mnt, action);

    if (IS_ERR(vfs) && isdevname && strcmp(mntfile, name))
        vfs = find_mnt_by_dev(name, action);

    pr_debug("find mnt %s: badpath = %d, isdevice = %d, name=%s, action = %d, vfs = %p\n",
        mntfile, badpath, isdevname, name, action, vfs);

    if (name)
        kfree(name);
    if (!badpath)
        path_release(&GET_NAMEIDATA_PATH(nd));

    return vfs;
}

typedef int(mnt_walk_helper_t)(struct vfsmount* vfs, int force);

static int interceptor_mnt_walk(struct vfsmount* parent,
                                mnt_walk_helper_t helperfunc)
{
    int submounts = 0;
#ifdef MNT_SHRINKABLE
    vfsmount_t* this_parent = real_mount(parent);
    struct list_head* next;

repeat:
    next = this_parent->mnt_mounts.next;
resume:
    while (next != &this_parent->mnt_mounts)
    {
        struct list_head* tmp = next;
        vfsmount_t* mnt       = list_entry(tmp, vfsmount_t, mnt_child);

        next = tmp->next;
        if (!(base_mount(mnt)->mnt_flags & MNT_SHRINKABLE))
            continue;

        if (!list_empty(&mnt->mnt_mounts))
        {
            this_parent = mnt;
            goto repeat;
        }

        helperfunc(base_mount(mnt), 1);
        submounts++;
    }

    if (this_parent != real_mount(parent))
    {
        next        = this_parent->mnt_child.next;
        this_parent = this_parent->mnt_parent;
        goto resume;
    }
#endif

    helperfunc(parent, 1);

    return submounts;
}


int klflt_cmd_get_path(char const* mntfile)
{
    if (!atomic_read(&mounts_handler_started))
        return -EBUSY;

    return klflt_get_path_unsafe(mntfile);
}

int klflt_get_path_unsafe(char const* mntfile)
{
    struct vfsmount* vfs;
    int ret = 0;

    write_lock(&klflt_mnt_rwlock);
    vfs = interceptor_find_mnt(mntfile, 1);
    if (!IS_ERR(vfs))
    {
        interceptor_mnt_walk(vfs, interceptor_get_path_helper);
    }
    else
    {
        ret = PTR_ERR(vfs);
    }
    write_unlock(&klflt_mnt_rwlock);

    return ret;
}

int klflt_cmd_put_path(char const* mntfile)
{
    if (!atomic_read(&mounts_handler_started))
        return -EBUSY;

    return klflt_put_path_unsafe(mntfile);
}

int klflt_put_path_unsafe(char const* mntfile)
{
    struct vfsmount* vfs;
    int ret = 0;

    write_lock(&klflt_mnt_rwlock);
    vfs = interceptor_find_mnt(mntfile, 0);
    if (!IS_ERR(vfs))
    {
         interceptor_mnt_walk(vfs, interceptor_put_path_helper);
    }
    else
    {
        ret = PTR_ERR(vfs);
    }
    write_unlock(&klflt_mnt_rwlock);

    return ret;
}

static void clear_mnt_list(void)
{
    struct klflt_mnt *kmnt, *tmp;

    write_lock(&klflt_mnt_rwlock);
    list_for_each_entry_safe(kmnt, tmp, &klflt_mnt_list, list)
    {
        if (kmnt->mnt)
            kmnt->mnt->mnt_flags &= ~KLFLT_MNT_SKIP;
        free_kmnt(kmnt, 0);
    }
    //klflt_excluded_clean();
    write_unlock(&klflt_mnt_rwlock);
}

static struct klflt_trace_ops trace_ops =
{
    .get = klflt_get_path_unsafe,
    .put = klflt_put_path_unsafe
};

int klflt_mounts_handler_init(struct klflt_mounts_ops* ops) {
    int rc = -EALREADY;
    pr_debug("%s\n", __func__);

    if (atomic_read(&mounts_handler_started)) {
        pr_err("%s: already started.", __func__);
        goto exit;
    }

    mounts_ops = *ops;

    rc = open_proc_mounts();
    if (rc < 0) {
        pr_err("%s: failed to open %s\n", __func__, MOUNTS_FILENAME);
        goto exit;
    }

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 19))
    nsp = current->namespace;
#else
    nsp = current->nsproxy->mnt_ns;
#endif

    mountsd = kthread_run(mounts_poll, NULL, "mountsd");
    if (IS_ERR(mountsd))
    {
        rc = PTR_ERR(mountsd);
        pr_err("%s: init mounts thread failed, err=%d", __func__, rc);
        goto exit_mountsd;
    }

    rc = klflt_binary_tracer_init(&trace_ops);
    if (rc < 0) {
        pr_err("%s: failed to initialize umount handler, err = %d", __func__, rc);
        goto exit_trace;
    }

    atomic_xchg(&mounts_handler_started, 1);

    goto exit;

exit_trace:
    kthread_stop(mountsd);
    mountsd = NULL;
    nsp     = NULL;
exit_mountsd:
    clear_mnt_list();
    close_proc_mounts();
    event = 0;
exit:
    return rc;
}

void klflt_mounts_handler_destroy(void) {

    if (atomic_read(&mounts_handler_started))
    {
        atomic_xchg(&mounts_handler_started, 0);

        klflt_binary_tracer_destroy();

        if (mountsd)
            kthread_stop(mountsd);
        mountsd = NULL;
        nsp     = NULL;

        clear_mnt_list();
        close_proc_mounts();
        event = 0;
    }
}
