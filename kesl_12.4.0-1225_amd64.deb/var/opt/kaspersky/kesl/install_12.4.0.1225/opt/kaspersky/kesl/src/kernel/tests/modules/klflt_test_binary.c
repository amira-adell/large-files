#include <klflt.h>
#include <files.h>

#include <linux/module.h>
#include <linux/init.h>
#include <linux/sched.h>
#include <linux/namei.h>
#include <linux/list.h>

#ifdef LINUX_KERNEL26
MODULE_INFO(supported, "external");
#endif

struct klflt_binary_fmt_ops binary_ops;
klflt_module_config_t klflt_module_config;

int print_exec(struct task_struct* tsk)
{
    pr_debug("Task: %s[%d]\n", tsk->comm, tsk->pid);

    return 0;
}

static int __init klflt_test_binary_init(void)
{
    int rv = 0;

    binary_ops.exec_trace = print_exec;
    rv = klflt_binfmt_handler_init(&binary_ops);
    if (rv)
        goto exit;
    rv = klflt_cmd_in_trace("*mount*");

exit:
    return rv;
}

static void __exit klflt_test_binary_exit(void)
{
    klflt_binfmt_handler_destroy();
}

MODULE_AUTHOR("Kaspersky Lab");
MODULE_DESCRIPTION("Kaspersky Anti-Malware Monitor Module Test for Linux.");
MODULE_LICENSE("GPL");

module_init(klflt_test_binary_init);
module_exit(klflt_test_binary_exit);