#! /usr/bin/env python3
import json
import argparse

parser = argparse.ArgumentParser(description = u'Generates description for "redirfs"')
parser.add_argument(u'--toolchain', dest = u'toolchain', required = True)
parser.add_argument(u'--result', dest = u'result', required = True)

args = parser.parse_args()

description = dict()
makeself_lib = description[u'redirfs'] = dict()
makeself_lib[u'version'] = u'0.10'
makeself_lib[u'type'] = u'lib'
makeself_lib[u'site'] = u'https://github.com/fhrbata/redirfs/archive/refs/tags/redirfs-0.10.tar.gz'
makeself_lib[u'toolchain'] = args.toolchain
makeself_lib[u'cert_attack_surface'] = u'no'
makeself_lib[u'cert_security_function'] = u'indirect'
makeself_lib[u'description'] = u'Used in legacy kernel module for old Linux versions only'
makeself_lib[u'children'] = []

with open(args.result, u'w') as result:
    json.dump(description, result, indent=4)
