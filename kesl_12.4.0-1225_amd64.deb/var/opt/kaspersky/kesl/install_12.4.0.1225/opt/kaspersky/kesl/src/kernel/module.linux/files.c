
/*
 * This source file is a part of a Kaspersky Antivirus Monitor.
 * Copyright (C) Kaspersky Lab, 1997-2010
 * See License.txt for details
 *
 */

#include "klflt.h"
#include "files.h"
#include "compat.h"
#include <asm/current.h>
#include <linux/dcache.h>
#include <linux/fs.h>
#include <linux/fs_struct.h>
#include <linux/mount.h>
#include <linux/mm.h>

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,12,0)
#include <linux/sched/mm.h>
#endif

extern klflt_module_config_t klflt_module_config;

char* d_path_wrap(struct dentry* dentry, struct vfsmount* vfsmnt, char* buf,
                  int buflen)
{
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25))
    struct path f_path = {.dentry = dentry, .mnt = vfsmnt};
    return d_path(&f_path, buf, buflen);
#else
    return d_path(dentry, vfsmnt, buf, buflen);
#endif
}
static inline struct vfsmount* get_cur_fs_rootmnt(void)
{
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25))
    return current->fs->root.mnt;
#else
    return current->fs->rootmnt;
#endif
}
static inline struct dentry* get_cur_fs_root(void)
{
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 25))
    return current->fs->root.dentry;
#else
    return current->fs->root;
#endif
}

static char* get_fname_part(char* buf, char* bufend)
{
    char *part, *res;
    int len;

    for (part = bufend - 50; part > buf && *part != '/'; --part)
        ;
    if (part != buf)
    {
        ++part;
        goto l_exit;
    }
    for (part = bufend - 50; part < bufend && *part != '/'; ++part)
        ;
    if (part != bufend)
    {
        return ++part;
        goto l_exit;
    }
    part = bufend - 50;

l_exit:
    len = bufend - part;
    res = kmalloc(len, GFP_KERNEL);
    if (res)
    {
        memcpy(res, part, len);
        res[len - 1] = 0;
    }

    return res;
}

char* get_path_by_dentry(struct dentry* dentry, struct vfsmount* mnt, int* err,
                         char** fname_part)
{
    char *path, *buf;
    int pathlen, bufsz = PAGE_SIZE;

    while (1)
    {
        buf = kmalloc(bufsz, GFP_KERNEL);
        if (!buf)
        {
            if (err)
                *err = -ENOMEM;
            return NULL;
        }

        path = d_path_wrap(dentry, mnt, buf, bufsz);

        if (IS_ERR(path))
        {
            if (-ENAMETOOLONG == PTR_ERR(path))
            {
                bufsz *= 2;
                if (bufsz > klflt_module_config.max_fname_len)
                {
                    if (fname_part)
                        *fname_part = get_fname_part(buf, buf + bufsz / 2);
                    if (err)
                        *err = -ENAMETOOLONG;
                    kfree(buf);
                    return NULL;
                }
                kfree(buf);
                continue;
            }
            if (err)
                *err = PTR_ERR(path);
            kfree(buf);
            return NULL;
        }

        break;
    }

    pathlen = strlen(path);
    if (file_unlinked(dentry) && !strcmp(path + (pathlen - 10), " (deleted)"))
    {
        path[pathlen - 10] = 0;
        pathlen -= 10;
    }

    if (PAGE_SIZE == bufsz)
    {
        char* tmp = kmalloc(pathlen + 1, GFP_KERNEL);
        if (tmp)
        {
            memcpy(tmp, path, pathlen + 1);
            kfree(buf);
            buf = tmp;
        }
        else
            memmove(buf, path, pathlen + 1);
    }
    else
        memmove(buf, path, pathlen + 1);

    return buf;
}

static struct file __rcu *get_exec_file(struct mm_struct* mm)
{
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3, 7, 0))
    struct vm_area_struct* vma;
    vma = mm->mmap;
    while (vma)
    {
        if ((vma->vm_flags & VM_EXECUTABLE) && vma->vm_file)
            return vma->vm_file;
        vma = vma->vm_next;
    }
#else
    return mm->exe_file;
#endif
    return NULL;
}

int get_exec_path(struct task_struct* task, struct vfsmount** vfsmnt,
                  struct dentry** dentry)
{
    struct mm_struct* mm;
    struct file __rcu *exe_file;

    mm = get_task_mm(task);
    if (!mm)
        return -EINVAL;

    down_read(&mm->mmap_sem);
    exe_file = get_exec_file(mm);
    if (exe_file)
    {
        *dentry = exe_file->f_dentry;
        *vfsmnt = exe_file->f_vfsmnt;
    }
    up_read(&mm->mmap_sem);
    mmput(mm);

    return 0;
}

int get_exec_info(struct task_struct __rcu *task, struct klflt_file_info* file)
{
    struct mm_struct* mm;
    struct file __rcu *exe_file;
    int locked = 0;

    mm = get_task_mm(task);
    if (!mm)
        return -1;

    locked = down_read_trylock(&mm->mmap_sem);

    exe_file = get_exec_file(mm);
    if (exe_file)
        klflt_fill_file_info(exe_file->f_dentry, file);

    if (locked)
        up_read(&mm->mmap_sem);
    mmput(mm);

    return exe_file ? 0 : -1;
}


int get_current_fs_root(struct vfsmount** rootmnt, struct dentry** root)
{
   if (current == NULL)
    {
        printk("kavmon: panic (current == NULL)\n");
        return -1;
    }

    task_lock(current);

    if (current->fs == NULL)
    {
        printk("kavmon: panic (current->fs == NULL)\n");
        task_unlock(current);

        return -1;
    }

    if (get_cur_fs_root() == NULL)
    {
        printk("kavmon: panic (current->fs->root == NULL)\n");
        task_unlock(current);
        return -1;
    }

    if (get_cur_fs_rootmnt() == NULL)
    {
        printk("kavmon: panic (current->fs->rootmnt == NULL)\n");
        task_unlock(current);
        return -1;
    }

    task_unlock(current);

    FS_LOCK(&current->fs->lock);
    *rootmnt = mntget(get_cur_fs_rootmnt());
    *root = dget(get_cur_fs_root());
    FS_UNLOCK(&current->fs->lock);

    return 0;
}

int same_as_current_fs_root(struct vfsmount* rootmnt, struct dentry* root)
{
    int res;
    FS_LOCK(&current->fs->lock);
    res = (rootmnt == get_cur_fs_rootmnt()) && (root == get_cur_fs_root());
    FS_UNLOCK(&current->fs->lock);
    return res;
}

void klflt_fill_file_info(struct dentry* dentry, struct klflt_file_info* info)
{
    info->dev     = kdev_t_to_nr(dentry->d_inode->i_sb->s_dev);
    info->ino     = dentry->d_inode->i_ino;
    info->p_ino   = dentry->d_parent->d_inode->i_ino;
    info->size    = dentry->d_inode->i_size;
    info->n_links = dentry->d_inode->i_nlink;
    info->m_time  = dentry->d_inode->i_mtime;
    info->c_time  = dentry->d_inode->i_ctime;
}
