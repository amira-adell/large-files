if(NOT DESCRIPTION_FILE)
  message(FATAL_ERROR "'DESCRIPTION_FILE' variable must be supplied for subproject description.")
endif()

add_custom_command(
  OUTPUT ${DESCRIPTION_FILE}
  DEPENDS CMakeLists.txt ${CMAKE_CURRENT_SOURCE_DIR}/generate_redirfs_description.py
  COMMAND rm -f ${DESCRIPTION_FILE}
  COMMAND  ${CMAKE_CURRENT_SOURCE_DIR}/generate_redirfs_description.py --toolchain=${KL_CM_TOOLCHAIN_ID} --result=${DESCRIPTION_FILE}
  VERBATIM
)
