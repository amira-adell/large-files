#include "klflt.h"
#include "klflt_protocol.h"
#include "files.h"
#include "mount.h"
#include <linux/fs.h>
#include <linux/kdev_t.h>
#include <linux/sched.h>
#include <linux/seq_file.h>
#include <linux/types.h>

#define MOUNTS_FILENAME "/proc/mounts"

static atomic_t check_started = ATOMIC_INIT(0);

extern const struct seq_operations* nsops;
extern struct file* mounts;
extern klflt_module_config_t klflt_module_config;

int klflt_queue_add(
    u_short queue_id, int block, struct klflt_request_metadata* reqd,
    enum KlFileAccessType* answer, unsigned long int timeout);

#ifndef LINUX_KERNEL26
#define real_parent p_pptr
#elif defined(CONFIG_UTRACE) && defined(remove_parent) && defined(add_parent)
#define real_parent parent
#endif

#define KAVMON_IS_WRITTEN(flags)                                                    \
    (flags & (O_WRONLY | O_RDWR | O_APPEND | O_CREAT | O_TRUNC))

int klflt_check_trusted(struct task_struct *tsk)
{
    struct klflt_file_info f_info;

    if (0 != get_exec_info((struct task_struct __rcu*)tsk, &f_info))
    {
        if (NULL == tsk->real_parent)
            return 0;
        if (0 != get_current_euid())
            return 0;
        if (0 != get_exec_info(tsk->real_parent, &f_info))
            return 0;
    }

    return klflt_is_process_trusted(current->pid, &f_info, 0);
}

static struct klflt_request_metadata* klflt_new_request(
    u_int8_t request, u_int32_t euid, u_int32_t egid,
    struct vfsmount* vfsmnt, struct dentry* parent, char const* name)
{
    struct klflt_request_metadata* reqd = NULL;

    reqd = kmalloc(sizeof(*reqd), GFP_KERNEL);
    if (!reqd)
        return ERR_PTR(-ENOMEM);

    INIT_LIST_HEAD(&reqd->list);
    kref_init(&reqd->refcnt);

    reqd->request = request;
    reqd->euid   = euid;
    reqd->egid   = egid;
    reqd->vfsmnt = mntget(vfsmnt);
    reqd->parent = parent;
    reqd->name   = kstrdup(name, GFP_KERNEL);

    return reqd;
}

static void klflt_fill_request(
    struct klflt_request_metadata* reqd, u_int32_t pid,
    u_int8_t file_op_type, int32_t flags, struct inode* inode)
{
    reqd->pid          = pid;
    reqd->file_op_type = file_op_type;
    reqd->flags        = flags;
    reqd->dev          = new_encode_dev(inode->i_sb->s_dev);
    reqd->ino          = inode->i_ino;
#ifndef LINUX_KERNEL26
    reqd->mtime = inode->i_mtime;
#else
    reqd->mtime = inode->i_mtime.tv_sec;
#endif
    reqd->size      = inode->i_size;
    reqd->owner_uid = i_uid_read(inode);
    reqd->file_mode = inode->i_mode;
    reqd->f_type    = inode->i_sb->s_magic;
}

static int req_queue_add_notification_vfsmnt(
    enum KlFileNotifyType file_type, struct inode* dir,
    struct dentry* dentry, struct vfsmount* vfsmnt)
{
    struct klflt_request_metadata* reqd;

    pr_debug("%s: T:%d, I:%p, D:%p, VFS:%p\n",
        __func__, file_type, dir, dentry, vfsmnt);

    reqd = klflt_new_request(NOTIFY_FILE,
                             get_current_euid(), get_current_egid(), vfsmnt,
                             dget_parent(dentry), dentry->d_name.name);

    if (IS_ERR(reqd))
        return PTR_ERR(reqd);

    reqd->file_op_type = file_type;
    reqd->dev = kdev_t_to_nr(dir->i_sb->s_dev);
    reqd->ino = dir->i_ino;
    reqd->queue_id = klflt_queue_get_id();

    check_req_queue_add(reqd);

    return 0;
}

static void req_queue_add_notification(
    enum KlFileNotifyType file_type, struct inode* dir, struct dentry* dentry)
{
    struct seq_file* m = mounts->private_data;
    loff_t pos         = 0;
    void* p            = NULL;

    pr_debug("%s: F:%d, I:%p, D:%p\n", __func__, file_type, dir, dentry);

    BUG_ON(nsops == NULL);

    p = nsops->start(m, &pos);

    while (p && !IS_ERR(p))
    {
        struct vfsmount* vfs    = GET_VFSMNT(p);
        struct dentry* mnt_root = dentry;

        do
        {
            mnt_root = mnt_root->d_parent;
            if (mnt_root == vfs->mnt_root)
            {
                req_queue_add_notification_vfsmnt(file_type, dir, dentry, vfs);
                break;
            }
        } while (!IS_ROOT(mnt_root));

        p = nsops->next(m, p, &pos);
    }

    nsops->stop(m, p);
}

int klflt_check_file(const struct klflt_file_info* info,
                     struct klflt_request_metadata* reqd,
                     int* err)
{
    u_short queue_id = 0;
    enum KlFileAccessType answer = FILE_ACCESS_ACCEPT;
    int block = (reqd->file_op_type == FILE_OPEN_OPER) ? 0 : 1;

    *err = 0;

    if (klflt_module_config.cache_enable && !is_cache_disabled_for(reqd->vfsmnt))
    {

        if ((reqd->file_op_type == FILE_CLOSE_OPER))
        {
            klflt_cache_del(info->dev, info->ino);
        }
        else
        {
            const struct klflt_file_info* cache_info =
                klflt_cached(info->dev, info->ino);
            if (cache_info)
            {

                if (cache_info->size != info->size || info->n_links > 1 ||
                    !klflt_timespec_equal(&cache_info->m_time, &info->m_time) ||
                    !klflt_timespec_equal(&cache_info->c_time, &info->c_time))
                {

                    klflt_cache_del(info->dev, info->ino);
                }
                else
                {
                    pr_debug("%s: pid=%d queue_id=%d, filename=%s. Cache hit!\n",
                        __func__, reqd->pid, queue_id, reqd->name);
                    return 0;
                }
            }
        }
    }

    queue_id = klflt_queue_get_id();

    pr_debug("%s: pid=%d queue_id=%d Scanning of filename=%s has been started",
             __func__, reqd->pid,queue_id,reqd->name);

    *err = klflt_queue_add(queue_id, block, reqd, &answer, MAX_SCHEDULE_TIMEOUT);

    pr_debug("%s: answer=%d\n", __func__, answer);

    if (*err)
        return *err;

    if (answer == FILE_ACCESS_ACCEPT &&
        klflt_module_config.cache_enable && info->n_links == 1)
    {
        klflt_cache_add(info);
    }
    return (answer == FILE_ACCESS_ACCEPT || answer == FILE_ACCESS_NO_CHECK)
               ? 0
               : -EACCES;
}

int klflt_check_before_open(struct inode* inode, struct file* file)
{
    struct klflt_file_info f_info;
    int err = 0;
    struct klflt_request_metadata* reqd;

    if (!atomic_read(&check_started) || klflt_check_trusted(current) ||
        !file_need_check(file->f_dentry))
        return 0;

    if (file_unlinked(file->f_dentry))
        return -ENOENT;

    reqd = klflt_new_request(CHECK_FILE,
        get_current_euid(), get_current_egid(), file->f_vfsmnt,
        dget_parent(file->f_dentry), file->f_dentry->d_name.name);

    if (IS_ERR(reqd))
        return PTR_ERR(reqd);

    klflt_fill_file_info(file->f_dentry, &f_info);
    klflt_fill_request(reqd, current->pid, FILE_OPEN_OPER, 0,
                               file->f_dentry->d_inode);

    err = klflt_check_file(&f_info, reqd, &err);
    check_req_queue_put(reqd);

    return err;
}

int klflt_check_after_close(struct inode* inode, struct file* file)
{
    struct klflt_file_info f_info;
    int err = 0;
    struct klflt_request_metadata* reqd;

    if (!(file->f_mode & FMODE_WRITE))
        return 0;

    if (!atomic_read(&check_started) || klflt_check_trusted(current) ||
        !file_need_check(file->f_dentry))
        return 0;

    /* cifs file systems leaves dentry unhashed for newly created files during file
     * close */
    if (file_unlinked(file->f_dentry) && strcmp(inode->i_sb->s_type->name, "cifs"))
        return 0;

    reqd = klflt_new_request(CHECK_FILE,
        get_current_euid(), get_current_egid(), file->f_vfsmnt,
        dget_parent(file->f_dentry), file->f_dentry->d_name.name);


    klflt_fill_file_info(file->f_dentry, &f_info);

    klflt_fill_request(reqd, current->pid, FILE_CLOSE_OPER, 0,
                               file->f_dentry->d_inode);

    err = klflt_check_file(&f_info, reqd, &err);
    check_req_queue_put(reqd);

    return err;
}

void klflt_check_unlink(struct inode* dir, struct dentry* dentry)
{
    struct inode* inode;

    if (!atomic_read(&check_started) || klflt_check_trusted(current))
        return;

    inode = (dentry->d_inode) ? dentry->d_inode : dir;
    if (inode_need_notify(inode))
    {
        req_queue_add_notification(FILE_UNLINK_OPER, inode, dentry);
        klflt_cache_del(kdev_t_to_nr(inode->i_sb->s_dev), inode->i_ino);
    }
}

void klflt_check_rename(struct inode* old_dir, struct dentry* old_dentry,
                   struct inode* new_dir, struct dentry* new_dentry)
{
    struct inode *i_old, *i_new;

    if (!atomic_read(&check_started) || klflt_check_trusted(current))
        return;

    i_old = (old_dentry->d_inode) ? old_dentry->d_inode : old_dir;
    if (inode_need_notify(i_old))
    {
        req_queue_add_notification(FILE_UNLINK_OPER, i_old, old_dentry);
        klflt_cache_del(kdev_t_to_nr(i_old->i_sb->s_dev), i_old->i_ino);
    }

    i_new = (new_dentry->d_inode) ? new_dentry->d_inode : new_dir;
    if (inode_need_notify(i_new))
    {
        req_queue_add_notification(FILE_RENAME_OPER, i_new, new_dentry);
        klflt_cache_del(kdev_t_to_nr(i_new->i_sb->s_dev), i_new->i_ino);
    }
}

int klflt_send_mtab_event(void)
{
    struct klflt_request_metadata* reqd;
    int err                    = 0;
    u_short queue_id           = klflt_queue_get_id();
    enum KlFileAccessType answer = FILE_ACCESS_ACCEPT;

    if (!atomic_read(&check_started))
        return false;

    reqd = klflt_new_request(CHECK_FILE, 0, 0, NULL, NULL, "/etc/mtab");

    reqd->file_op_type = FILE_CLOSE_OPER;
    err                = klflt_queue_add(queue_id, 0, reqd, &answer, MAX_SCHEDULE_TIMEOUT);
    check_req_queue_put(reqd);

    return err;
}

int klflt_check_init(void)
{
    pr_debug("%s\n", __func__);

    atomic_xchg(&check_started, 1);

    return 0;
}

void klflt_check_destroy(void)
{
    pr_debug("%s\n", __func__);
    atomic_xchg(&check_started, 0);
    klflt_queue_clear();
}