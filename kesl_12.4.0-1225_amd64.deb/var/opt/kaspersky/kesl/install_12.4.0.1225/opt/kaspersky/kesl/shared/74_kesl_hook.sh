#!/bin/sh -u

export LC_ALL=C

stop_oas()
{
    current_oas_state=$(/opt/kaspersky/kesl/bin/kesl-control --get-task-state 1)

    oas_stopped=0
    case "$current_oas_state" in
         *Stopped*) oas_stopped=1;;
    esac

    echo $oas_stopped > /var/run/kesl.oas

    if [ "$oas_stopped" = "0" ]; then
        /opt/kaspersky/kesl/bin/kesl-control --stop-task 1 -W > /dev/null 2>&1
    fi
}

start_oas()
{
    oas_stopped=0
    read -r oas_stopped < /var/run/kesl.oas

    if [ "$oas_stopped" = "0" ]; then
        /opt/kaspersky/kesl/bin/kesl-control --start-task 1 > /dev/null 2>&1
    fi

    rm -f /var/run/kesl.oas
}

case "$1" in
    suspend|hibernate)
        stop_oas
    ;;
    thaw|resume)
        start_oas
    ;;
esac
