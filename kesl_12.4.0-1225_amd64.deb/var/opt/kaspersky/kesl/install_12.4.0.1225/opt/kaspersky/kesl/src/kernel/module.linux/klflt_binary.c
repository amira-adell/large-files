#include "klflt.h"
#include "files.h"

#include <linux/fs.h>
#include <linux/list.h>
#include <linux/module.h>
#include <asm/ptrace.h>
#include <asm/current.h>
#include <linux/types.h>
#include <linux/binfmts.h>
#include <linux/sched.h>

struct umount_bin
{
    struct list_head list;
    char wildcard[0];
};

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 30))
int use_binfmt = 0;
static inline int insert_binfmt(struct linux_binfmt *fmt)
{
	return -EPERM;
}
#else
int use_binfmt = 1;
#endif

static atomic_t binfmt_handler_started = ATOMIC_INIT(0);
static LIST_HEAD(umount_bin_list);
static DEFINE_MUTEX(umount_bin_mutex);
static DEFINE_MUTEX(binary_handler_mutex);

static struct klflt_binary_fmt_ops binfmt_handler_ops;

static int match_wildcard(const char* text, const char* wildcard)
{
    const char* afterLastStar = NULL;
    const char* firstMatched = NULL;
    if (!text || !wildcard)
        return 0;
    while (*text)
    {
        if ((*wildcard == *text) || (*wildcard == '?'))
        {
            ++text;
            ++wildcard;
        }
        else if (*wildcard == '*')
        {
            afterLastStar = ++wildcard;
            firstMatched = text;
            if (*wildcard == '\0')
                return 1;
        }
        else if (afterLastStar)
        {
            wildcard = afterLastStar;
            text     = ++firstMatched;
        }
        else
        {
            return 0;
        }
    }
    while (*wildcard == '*')
        ++wildcard;
    return *wildcard == '\0';
}

static struct umount_bin* match_any_wildcard(const char* text)
{
    struct umount_bin* ubin = NULL;
    list_for_each_entry(ubin, &umount_bin_list, list) {
        if (match_wildcard(text, ubin->wildcard))
            return ubin;
    }

    return NULL;
}

static struct umount_bin* find_umount_bin(char const* wildcard)
{
    struct umount_bin* ubin = NULL;
    list_for_each_entry(ubin, &umount_bin_list, list) {
        if (!strcmp(wildcard, ubin->wildcard))
            return ubin;
    }

    return NULL;
}

int klflt_cmd_in_trace(char const* wildcard)
{
    int ret = 0;

    pr_debug("%s: arg = %s\n", __func__, wildcard);
    mutex_lock(&umount_bin_mutex);
    {
        struct umount_bin* ubin = find_umount_bin(wildcard);
        if (ubin)
            goto itr_unlock;
        else
            ubin = kmalloc(sizeof(struct umount_bin) + strlen(wildcard) + 1, GFP_KERNEL);

        if (ubin)
        {
            strcpy(ubin->wildcard, wildcard);
            list_add_tail(&ubin->list, &umount_bin_list);
        }
        else
            ret = -ENOMEM;
    }
itr_unlock:
    mutex_unlock(&umount_bin_mutex);

    return ret;
}

int klflt_cmd_de_trace(char const* wildcard)
{
    int ret = 0;

    pr_debug("%s: arg = %s\n", __func__, wildcard);
    mutex_lock(&umount_bin_mutex);
    {
        struct umount_bin* ubin = find_umount_bin(wildcard);
        if (ubin)
        {
            list_del_init(&ubin->list);
            kfree(ubin);
        }
        else
            ret = -ENOENT;
    }
    mutex_unlock(&umount_bin_mutex);

    return ret;
}

int klflt_cmd_rs_trace(char const* wildcard)
{

    pr_debug("%s: arg = %s\n", __func__, wildcard);
    mutex_lock(&umount_bin_mutex);
    {
        struct umount_bin *ubin, *tmp;
        size_t umount_len = wildcard ? strlen(wildcard) : 0;

        list_for_each_entry_safe(ubin, tmp, &umount_bin_list, list)
        {
            list_del_init(&ubin->list);
            kfree(ubin);
        }

        if (umount_len &&
            (ubin = kmalloc(sizeof(struct umount_bin) + umount_len + 1, GFP_KERNEL)))
        {
            strcpy(ubin->wildcard, wildcard);
            list_add_tail(&ubin->list, &umount_bin_list);
        }
    }
    mutex_unlock(&umount_bin_mutex);

    return 0;
}

static int klflt_cmd_fn_trace(char const* text)
{
    int ret = 0;

    pr_debug("%s: arg = %s\n", __func__, text);
    mutex_lock(&umount_bin_mutex);
    {
        struct umount_bin* ubin = match_any_wildcard(text);
        if (ubin)
            ret = 1;
    }
    mutex_unlock(&umount_bin_mutex);
    return ret;
}

#if (LINUX_VERSION_CODE < KERNEL_VERSION(3, 8, 0))
static int binary_handler_exec(struct linux_binprm* bprm, struct pt_regs* regs)
#else
static int binary_handler_exec(struct linux_binprm* bprm)
#endif
{
    int retval = -ENOEXEC;
    char* exe_name = NULL;

    pr_debug("%s: file = %s", __func__, bprm->file->f_dentry->d_name.name);

    mutex_lock(&binary_handler_mutex);
    if (!atomic_read(&binfmt_handler_started)) {
        pr_debug("%s: trace handler is not active\n", __func__);
        goto exit_unlock;
    }

    exe_name = current->mm ?
        get_path_by_dentry(bprm->file->f_dentry, bprm->file->f_vfsmnt, NULL, NULL)
      : NULL;

    if (!exe_name) {
        pr_debug("%s: Failed to get full path by name\n", __func__);
        goto exit_unlock;
    }

    if (binfmt_handler_ops.exec_trace && klflt_cmd_fn_trace(exe_name))
    {
        binfmt_handler_ops.exec_trace(current);
    }

    kfree(exe_name);

exit_unlock:
    mutex_unlock(&binary_handler_mutex);
    return retval;
}

static int binary_handler_ulib(struct file* file)
{
    int retval = -ENOEXEC;

    pr_debug("%s: file = %s", __func__, file->f_dentry->d_name.name);

    return retval;
}

static struct linux_binfmt klflt_binfmt_setup = {
    .module                              = THIS_MODULE,
    .load_binary                         = binary_handler_exec,
    .load_shlib                          = binary_handler_ulib,
};

int klflt_binfmt_handler_init(struct klflt_binary_fmt_ops* ops) {
    int rc = -EALREADY;
    pr_debug("%s", __func__);

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 30))
    return 0;
#else
    mutex_lock(&binary_handler_mutex);
    if (use_binfmt && !atomic_read(&binfmt_handler_started)) {
        binfmt_handler_ops.exec_trace = ops->exec_trace;

        atomic_xchg(&binfmt_handler_started, 1);
        insert_binfmt(&klflt_binfmt_setup);
        rc = 0;
    }
    mutex_unlock(&binary_handler_mutex);

    return rc;
#endif
}

void klflt_binfmt_handler_destroy(void) {
    pr_debug("%s", __func__);

    mutex_lock(&binary_handler_mutex);
    if (use_binfmt && atomic_read(&binfmt_handler_started)) {
        atomic_xchg(&binfmt_handler_started, 0);
        unregister_binfmt(&klflt_binfmt_setup);
    }
    mutex_unlock(&binary_handler_mutex);
}
