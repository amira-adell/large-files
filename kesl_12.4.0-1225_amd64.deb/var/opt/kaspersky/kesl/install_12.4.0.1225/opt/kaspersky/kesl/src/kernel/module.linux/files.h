
/*
 * This source file is a part of a Kaspersky Antivirus Monitor.
 * Copyright (C) Kaspersky Lab, 1997-2010
 * See License.txt for details
 *
 */

#ifndef KERNEL__MODULE_LINUX__FILES_H
#define KERNEL__MODULE_LINUX__FILES_H

#include "klflt.h"
#include <linux/fs.h>
#include <linux/mount.h>
//#include "compat.h"


#define DEFAULT_MAX_FNAME_LEN 0x4000
#define DEFAULT_DENY_TOO_LONG_FNAME 1

typedef struct
{
    dev_t dev;
    unsigned long ino;
    unsigned long p_ino;
    loff_t size;
    unsigned int n_links;
    timespec_t m_time;
    timespec_t c_time;
} file_info;

static __inline__ int FILE_EQUAL(const file_info* file1, const file_info* file2)
{
    return (file1->dev == file2->dev && file1->ino == file2->ino);
}

extern struct vfsmount* orig_rootmnt;
extern struct dentry* orig_root;

char* d_path_wrap(struct dentry* dentry, struct vfsmount* vfsmnt, char* buf,
                  int buflen);
char* get_path_by_dentry(struct dentry* dentry, struct vfsmount* mnt, int* err,
                         char** fname_part);

int get_exec_path(struct task_struct* task, struct vfsmount** vfsmnt,
                  struct dentry** dentry);

int get_current_fs_root(struct vfsmount** rootmnt, struct dentry** root);
int same_as_current_fs_root(struct vfsmount* rootmnt, struct dentry* root);

#ifndef AUFS_SUPER_MAGIC
#define AUFS_SUPER_MAGIC ('a' << 24 | 'u' << 16 | 'f' << 8 | 's')
#endif

#ifndef AUTOFS_SUPER_MAGIC
#define AUTOFS_SUPER_MAGIC      0x0187
#endif

#ifndef BINFMTFS_MAGIC
#define BINFMTFS_MAGIC          0x42494e4d
#endif

#ifndef CGROUP_SUPER_MAGIC
#define CGROUP_SUPER_MAGIC 0x27e0eb
#endif

#ifndef CIFS_MAGIC_NUMBER
#define CIFS_MAGIC_NUMBER 0xFF534D42
#endif

#ifndef CONFIGFS_MAGIC
#define CONFIGFS_MAGIC 0x62656570
#endif

#ifndef DEBUGFS_MAGIC
#define DEBUGFS_MAGIC 0x64626720
#endif

#ifndef DEVFS_SUPER_MAGIC
#define DEVFS_SUPER_MAGIC 0x1373
#endif

#ifndef DEVPTS_SUPER_MAGIC
#define DEVPTS_SUPER_MAGIC 0x1cd1
#endif

#ifndef HUGETLBFS_MAGIC
#define HUGETLBFS_MAGIC 0x958458f6
#endif


#ifndef FUSE_CTL_SUPER_MAGIC
#define FUSE_CTL_SUPER_MAGIC 0x65735543
#endif

#ifndef FUSE_SUPER_MAGIC
#define FUSE_SUPER_MAGIC 0x65735546
#endif

#ifndef MQUEUE_MAGIC
#define MQUEUE_MAGIC    0x19800202
#endif

#ifndef NFSD_MAGIC
#define NFSD_MAGIC 0x6E667364
#endif

#ifndef NFS_SUPER_MAGIC
#define NFS_SUPER_MAGIC 0x6969
#endif

#ifndef PIPEFS_MAGIC
#define PIPEFS_MAGIC 0x50495045
#endif

#ifndef PROC_SUPER_MAGIC
#define PROC_SUPER_MAGIC 0x9fa0
#endif

#ifndef PSTOREFS_MAGIC
#define PSTOREFS_MAGIC 0x6165676C
#endif

#ifndef RPCAUTH_GSSMAGIC
#define RPCAUTH_GSSMAGIC 0x67596969
#endif

#ifndef RPC_PIPEFS_MAGIC
#define RPC_PIPEFS_MAGIC 0x67596969
#endif

#ifndef SECURITYFS_MAGIC
#define SECURITYFS_MAGIC 0x73636673
#endif

#ifndef SELINUX_MAGIC
#define SELINUX_MAGIC 0xf97cff8c
#endif

#ifndef SMB_SUPER_MAGIC
#define SMB_SUPER_MAGIC 0x517B
#endif

#ifndef SYSFS_MAGIC
#define SYSFS_MAGIC 0x62656572
#endif

#ifndef USBDEVICE_SUPER_MAGIC
#define USBDEVICE_SUPER_MAGIC   0x9fa2
#endif

#ifndef GPFS_SUPER_MAGIC
#define GPFS_SUPER_MAGIC 0x47504653
#endif

#define is_fuse_magic(magic) ((magic) == FUSE_SUPER_MAGIC)

static inline int is_acs_magic(int magic)
{
    return (magic == FUSE_SUPER_MAGIC);
}

static inline int is_smb_magic(int magic)
{
    return (magic == SMB_SUPER_MAGIC || magic == CIFS_MAGIC_NUMBER);
}

static inline int is_nfs_magic(int magic)
{
    return (magic == NFS_SUPER_MAGIC);
}

static inline int is_cache_disabled_for(struct vfsmount* mnt)
{
    int magic;
    if (!mnt)
        return 1;
    magic = mnt->mnt_root->d_inode->i_sb->s_magic;
    return is_smb_magic(magic) || is_nfs_magic(magic);
}

static inline int is_exclude_magic(int magic)
{
    return (magic == AUTOFS_SUPER_MAGIC    || magic == AUFS_SUPER_MAGIC      ||
            magic == BINFMTFS_MAGIC        || magic == CGROUP_SUPER_MAGIC    ||
            magic == CONFIGFS_MAGIC        || magic == DEBUGFS_MAGIC         ||
            magic == DEVFS_SUPER_MAGIC     || magic == DEVPTS_SUPER_MAGIC    ||
            magic == FUSE_CTL_SUPER_MAGIC  || magic == HUGETLBFS_MAGIC       ||
            magic == MQUEUE_MAGIC          || magic == NFSD_MAGIC            ||
            magic == PROC_SUPER_MAGIC      || magic == PSTOREFS_MAGIC        ||
            magic == RPC_PIPEFS_MAGIC      || magic == PIPEFS_MAGIC          ||
            magic == USBDEVICE_SUPER_MAGIC || magic == RPCAUTH_GSSMAGIC      ||
            magic == SECURITYFS_MAGIC      || magic == SELINUX_MAGIC         ||
            magic == SYSFS_MAGIC           || magic == GPFS_SUPER_MAGIC);
}

static inline int inode_need_notify(struct inode* inode)
{
    if (!inode->i_sb)
        return 0;

    if (is_exclude_magic(inode->i_sb->s_magic))
        return 0;

    if (S_ISREG(inode->i_mode))
    {
        if (!inode->i_size)
            return 0;
    }
    else if (!S_ISDIR(inode->i_mode))
        return 0;

    return 1;
}

static inline int file_need_check(struct dentry* dentry)
{
    return (!is_exclude_magic(dentry->d_inode->i_sb->s_magic) &&
            S_ISREG(dentry->d_inode->i_mode));
}

static inline int file_unlinked(struct dentry* dentry)
{
    return d_unhashed(dentry);
}

#endif // KERNEL__MODULE_LINUX__FILES_H
