#ifndef MONITOR_WATCHDOG_FILENAME
#define MONITOR_WATCHDOG_FILENAME "/proc/kav4fs-watchdog"
#define MONITOR_WATCHDOG_NAME "kav4fs-watchdog"
#endif // MONITOR_WATCHDOG_FILENAME
#ifndef LFS_PRODUCT_VERSION
#define LFS_PRODUCT_VERSION "12.4.0.1225"
#define REDIRFS_VERSION_NAME "redirfs.version"
#define KAV4FS_VERSION_NAME "kav4fs_oas.version"
#endif // LFS_PRODUCT_VERSION
