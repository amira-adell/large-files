#include <klflt.h>
#include <files.h>
#include <klflt_protocol.h>

#include <linux/module.h>
#include <linux/init.h>
#include <linux/seq_file.h>
#include <linux/namei.h>
#include <linux/list.h>

klflt_module_config_t klflt_module_config;
static struct klflt_connection conn;

struct klflt_dev
{

};

static void klflt_dump_request(struct klflt_request_metadata* req)
{
    pr_debug("Request type:%d, queue_id:%d, uid: %d, gid:%d, pid: %d"
             ", kref: %d, name: %s\n",
        req->request, req->queue_id, req->euid, req->egid, req->pid,
        atomic_read(&req->refcnt.refcount), req->name);
}

static struct klflt_request_metadata* klflt_new_request(
    u_int8_t request, u_int32_t euid, u_int32_t egid,
    struct vfsmount* vfsmnt, struct dentry* parent, char const* name)
{
    struct klflt_request_metadata* reqd = NULL;

    reqd = kmalloc(sizeof(*reqd), GFP_KERNEL);
    if (!reqd)
        return ERR_PTR(-ENOMEM);

    INIT_LIST_HEAD(&reqd->list);
    kref_init(&reqd->refcnt);

    reqd->request = request;
    reqd->euid   = euid;
    reqd->egid   = egid;
    reqd->vfsmnt = mntget(vfsmnt);
    reqd->parent = parent;
    reqd->name   = kstrdup(name, GFP_KERNEL);

    return reqd;
}

static void klflt_fill_request(
    struct klflt_request_metadata* reqd, u_int32_t pid,
    u_int8_t file_op_type, int32_t flags, struct inode* inode)
{
    reqd->pid          = pid;
    reqd->file_op_type = file_op_type;
    reqd->flags        = flags;
    reqd->dev          = new_encode_dev(inode->i_sb->s_dev);
    reqd->ino          = inode->i_ino;
#ifndef LINUX_KERNEL26
    reqd->mtime = inode->i_mtime;
#else
    reqd->mtime = inode->i_mtime.tv_sec;
#endif
    reqd->size      = inode->i_size;
    reqd->owner_uid = i_uid_read(inode);
    reqd->file_mode = inode->i_mode;
    reqd->f_type    = inode->i_sb->s_magic;
}

static int klflt_buffer_add_packet(
    struct klflt_proto_buffer* buf, struct klflt_packed_buffer* packet)
{
    u_int32_t net_len = htonl(packet->length);

    if (!klflt_proto_buffer_adjust_size(buf, sizeof(u_int32_t) + packet->length))
        return 0;

    memcpy(buf->start + buf->length, (char*)&net_len, sizeof(u_int32_t));
    buf->length += sizeof(u_int32_t);
    memcpy(buf->start + buf->length, (char*)packet->data, packet->length);
    buf->length += packet->length;

    return packet->length + sizeof(u_int32_t);
}

static int klflt_proto_buffer_add_request(
    struct klflt_proto_buffer* buf, struct klflt_request_metadata* req)
{
    int err = 0;
    char *filename = NULL;
    char* fname_part = NULL;
    struct klflt_packed_buffer packet = {.data = NULL, .length = 0};
    struct dentry* dentry = NULL;

    pr_debug("%s: %p <- %p\n", __func__, buf, req);

    if (req->parent)
    {
        dentry = d_alloc_name(req->parent, req->name);
        if (dentry) {
            filename = get_path_by_dentry(dentry, req->vfsmnt, &err, &fname_part);
            dput(dentry);
        }
    }
    else
    {
        filename = kstrdup(req->name, GFP_KERNEL);
    }

    if (-ENAMETOOLONG == err)
    {
        req->request      = NOTIFY_FILE;
        req->file_op_type = FILE_NAME_TOO_LONG;
        filename          = fname_part ? fname_part : kstrdup(req->name, GFP_KERNEL);
    }
    else if (0 != err)
    {
        req->request = 0;
    }

    switch(req->request)
    {
        case CHECK_FILE:
            err = klflt_fill_check_event(
                &packet, klflt_module_config.version, req->euid, req->egid,
                req->pid, req->queue_id, filename, req->file_op_type,
                req->flags, req->dev, req->ino, req->mtime, req->size,
                req->owner_uid, req->file_mode, req->f_type, NULL) ? 0 : -ENOMEM;
            break;
        case CHECK_SIGN:
            err = -EINVAL; // Not supported
            break;
        case NOTIFY_FILE:
            err = -EINVAL;
            break;
        case 0:
            pr_err("%s: detected request with id == 0\n", __func__);
            break;
        default:
            pr_err("%s: unexpected request %d\n", __func__, req->request);
            err = -EINVAL;
            break;
    }

    if (!err)
    {
        if (!klflt_buffer_add_packet(buf, &packet))
        {
            pr_err("Failed to add packet into buffer");
            return -ENOMEM;
        }
        klflt_packed_buffer_destroy(&packet);
    }

    if (filename)
        kfree(filename);

    return 0;
}

static int klflt_test_check_queue(void)
{
    struct klflt_request_metadata* reqd;
    struct klflt_proto_buffer* buf = &conn.send_buff;
    struct klflt_request_metadata* req = NULL;
    size_t count = 4096;

    reqd = klflt_new_request(CHECK_FILE, 0, 0, NULL, NULL, "/tmp/test");
    check_req_queue_add(reqd);
    check_req_queue_put(reqd);
    klflt_dump_request(reqd);

    while(buf->length < count)
    {
        req = check_req_queue_get();
        if (!req) {
            pr_err("%s: request not ready", __func__);
            return -EFAULT;
        }

        klflt_proto_buffer_add_request(&conn.send_buff, req);
        check_req_queue_put(req);
    }

    return 0;
}

void klflt_interface_v2_send_data(struct klflt_request_metadata* req)
{
    pr_debug("stub %s: req=%p\n", __func__, req);
}



static int __init klflt_test_queue_init(void)
{
    int rv = 0;

    rv = connection_init(&conn);
    if (rv < 0)
    {
        pr_err("%s: failed to initialize connection\n", __func__);
        goto exit;
    }

    rv = klflt_queue_init();
    if (rv < 0)
    {
        pr_err("%s: failed to initialize queue\n", __func__);
        goto exit_queue;
    }

    klflt_test_check_queue();


    pr_debug("%s: send_buf: %p, cap: %d, len: %d, start: %p\n", __func__,
        conn.send_buff.data, conn.send_buff.capacity,
        conn.send_buff.length, conn.send_buff.start);
    pr_debug("%s: recv_buf: %p, cap: %d, len: %d, start: %p\n", __func__,
        conn.recv_buff.data, conn.recv_buff.capacity,
        conn.recv_buff.length, conn.recv_buff.start);

    goto exit;

exit_queue:
    connection_destroy(&conn);
exit:
    return rv;
}

static void __exit klflt_test_queue_exit(void)
{
    connection_destroy(&conn);
}

MODULE_AUTHOR("Kaspersky Lab");
MODULE_DESCRIPTION("Kaspersky Anti-Virus Monitor Module Test for Linux.");
MODULE_LICENSE("GPL");

module_init(klflt_test_queue_init);
module_exit(klflt_test_queue_exit);