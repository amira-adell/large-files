
/*
 * This source file is a part of a Kaspersky Antivirus Monitor.
 * Copyright (C) Kaspersky Lab, 1997-2010
 * See License.txt for details
 *
 */

#ifndef KLFLT__KERNEL_H
#define KLFLT__KERNEL_H


#endif // KERNEL__KERNEL_H
