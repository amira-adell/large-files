#ifndef KERNEL_MODULE_COMPAT_H
#define KERNEL_MODULE_COMPAT_H

#include <linux/version.h>

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18))
#include <linux/config.h>
#endif

#if (LINUX_VERSION_CODE > KERNEL_VERSION(2, 3, 48) &&                               \
     LINUX_VERSION_CODE < KERNEL_VERSION(2, 5, 0) && defined(CONFIG_MODVERSIONS))
#define MODVERSIONS
#include <linux/modversions.h>
#endif

#if (defined(UNDEF_SMP) && LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0))
#undef __SMP__
#undef CONFIG_SMP
#else
#if defined(CONFIG_SMP)
#define __SMP__
#endif
#endif

#if (LINUX_VERSION_CODE > KERNEL_VERSION(2, 3, 48))
#include <linux/module.h>
#endif
#include <asm/page.h>
#include <linux/vmalloc.h>
#include <linux/fs.h>
#if (LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 27))
#include <linux/fs_struct.h>
#endif
#include <linux/poll.h>
#include <linux/mm.h>
#include <linux/errno.h>
#include <linux/file.h>
#include <linux/proc_fs.h>
#include <asm/unistd.h>
#include <asm/uaccess.h>
#include <linux/list.h>
#include <linux/types.h>
#include <linux/slab.h>

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 18))
#include <linux/devfs_fs_kernel.h>
#else
#define DEVFS_SUPER_MAGIC 0x1373
#endif


#ifdef LINUX_KERNEL26
#include <linux/mount.h>
#include <linux/namei.h>
#include <linux/ptrace.h>
#ifdef SYS_CALL_TABLE_READONLY
#include <asm/cacheflush.h>
#endif
#include <linux/time.h>




#ifdef HAVE_SYSCALLS_H
#include <linux/syscalls.h>
#endif
#endif

#if defined(SYS_CALL_TABLE_READONLY) || defined(SYS_CALL_TABLE32_READONLY) ||       \
    defined(SYS_CALL_TABLE64_READONLY)
#include <linux/highmem.h>
#endif

#if defined(CONFIG_X86_64) && (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 11))
#include <linux/ioctl32.h>
#endif

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 3, 0))
#include "mount.h"
#endif

/* Linux 2.2 compatibility  */

#ifndef BUG
#define BUG()                                                                       \
    do                                                                              \
    {                                                                               \
        printk("kernel BUG at %s:%d!\n", __FILE__, __LINE__);                       \
        *((char*)0) = 0;                                                            \
    } while (0)
#endif /* BUG */

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 2, 20))
typedef struct wait_queue* wait_queue_head_t;
#define init_waitqueue_head(wait) init_waitqueue(wait)
#endif

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 3, 48))
#define down_read(sem) down(sem)
#define up_read(sem) up(sem)
#define KSTK_EIP(tsk) (((unsigned long*)(4096 + (unsigned long)(tsk)))[1019])
#endif

/* End of compat */

#ifndef __GFP_NOWARN
#define __GFP_NOWARN 0
#endif

#define MEM_ALLOC(size) kmalloc(size, GFP_KERNEL | __GFP_NOWARN)
#define MEM_FREE(ptr) kfree(ptr)

#if !KSTRDUP_ADDR
static inline char* kstrdup(const char* s, int gfp)
{
    size_t len = s ? strlen(s) + 1 : 0;
    char* buf  = len ? kmalloc(len, gfp) : NULL;

    if (buf)
        memcpy(buf, s, len);
    return buf;
}
#endif

#define MEM_STRDUP(str) kstrdup(str, GFP_KERNEL)

#ifndef for_each_process
#define for_each_process(p) for_each_task(p)
#endif

#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

#define PRN(format, args...) printk(format "\n", ##args)
#define PRN_ERR(format, args...) printk(KERN_ERR format, ##args)

#define lock_declare(lock) rwlock_t lock

#define strlen_user_(str) strnlen_user(str, ~0UL >> 1)

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 3, 48))
#define lock_init(lock, name)                                                       \
    do                                                                              \
    {                                                                               \
    } while (0)
#define lock_finit(lock)                                                            \
    do                                                                              \
    {                                                                               \
    } while (0)
#else
#define lock_init(lock, name) rwlock_init(lock)
#define lock_finit(lock)                                                            \
    do                                                                              \
    {                                                                               \
    } while (0)
#endif


#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 25))
#define GET_NAMEIDATA_PATH(nameidata_struct) (nameidata_struct)
#elif(LINUX_VERSION_CODE < KERNEL_VERSION(3, 19, 0))
#define GET_NAMEIDATA_PATH(nameidata_struct) ((&nameidata_struct)->path)
#define path_release(path_struct) path_put(path_struct)
#else
#define GET_NAMEIDATA_PATH(path) (path)
#define path_release(path_struct) path_put(path_struct)
#endif

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36))
#define FS_LOCK(lock) read_lock(lock)
#define FS_UNLOCK(lock) read_unlock(lock)
#else
#define FS_LOCK(lock) spin_lock(lock)
#define FS_UNLOCK(lock) spin_unlock(lock)
#endif

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 23))
#define GET_VFSMNT(p) (p)
#define vfsmount_t struct vfsmount
#define real_mount(p) (p)
#define base_mount(p) (p)
#elif(LINUX_VERSION_CODE < KERNEL_VERSION(3, 3, 0))
#define GET_VFSMNT(p) (list_entry(p, struct vfsmount, mnt_list))
#define vfsmount_t struct vfsmount
#define real_mount(p) (p)
#define base_mount(p) (p)
#else
#define GET_VFSMNT(p) (&list_entry(p, struct mount, mnt_list)->mnt)
#define vfsmount_t struct mount
#define base_mount(p) (&p->mnt)
#endif

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 9, 0))
#define f_vfsmnt f_path.mnt
#endif

#ifndef DECLARE_MUTEX
#define DECLARE_MUTEX DEFINE_SEMAPHORE
#endif

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 14, 0)) ||                             \
    (defined(CONFIG_UIDGID_STRICT_TYPE_CHECKS) && CONFIG_UIDGID_STRICT_TYPE_CHECKS)
#define get_current_euid() from_kuid_munged(&init_user_ns, current_euid())
#define get_current_egid() from_kgid_munged(&init_user_ns, current_egid())
#else
#define i_uid_read(inode) ((inode)->i_uid)
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29))
#define get_current_euid() current_euid()
#define get_current_egid() current_egid()
#else
#define get_current_euid() current->euid
#define get_current_egid() current->egid
#endif
#endif

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 30))
#define insert_binfmt_(fmt) register_binfmt(fmt)
#elif(LINUX_VERSION_CODE < KERNEL_VERSION(3, 4, 0))
#define insert_binfmt_(fmt) insert_binfmt(fmt)
#else
#define insert_binfmt_(fmt) (insert_binfmt(fmt), 0)
#endif

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 22))
#define remove_binfmt(fmt) (unregister_binfmt(fmt), (fmt)->next = NULL)
#else
#define remove_binfmt(fmt) unregister_binfmt(fmt)
#endif

#ifndef list_for_each_entry_safe_reverse
#define list_for_each_entry_safe_reverse list_for_each_entry_safe
#endif

#endif /* KERNEL_MODULE_COMPAT_H */