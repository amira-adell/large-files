#include "klflt.h"
#include <linux/namei.h>
#include <linux/list.h>
#include <linux/version.h>

struct klflt_excluded
{
    struct vfsmount* mnt;
    char* mntpath;
    struct list_head list;
};

static LIST_HEAD(klflt_excluded_list);
static DEFINE_MUTEX(klflt_excluded_mutex);

static int klflt_is_mnt_excluded_unsafe(struct vfsmount* vfs)
{
    struct klflt_excluded* mnt;

    list_for_each_entry(mnt, &klflt_excluded_list, list)
    {
        if (vfs == mnt->mnt)
        {
            return 1;
        }
    }

    return 0;
}

static void klflt_excluded_remove(struct klflt_excluded* excl)
{
    pr_debug("%s\n", __func__);

    list_del_init(&excl->list);
    kfree(excl->mntpath);
    kfree(excl);
}

int klflt_cmd_add_excl(char const* mntfile)
{
    struct vfsmount* vfs = NULL;
    int ret = 0;
    int added = 0;
    struct path mntpath;

    int badpath = kern_path(mntfile, LOOKUP_FOLLOW, &mntpath);

    pr_debug("%s: excluding %s\n", __func__, mntfile);

    if (!badpath && mntpath.mnt)
    {
        vfs = mntget(mntpath.mnt);
    }
    else
    {
        pr_err("Failed to exclude path %s\n", mntfile);
        ret = -1;
        goto release_path;
    }

    mutex_lock(&klflt_excluded_mutex);
    if (!klflt_is_mnt_excluded_unsafe(vfs))
    {
        struct klflt_excluded* emnt;
        emnt = kmalloc(sizeof(*emnt), GFP_KERNEL);
        if (!emnt)
            goto nomem;

        emnt->mnt = vfs;
        emnt->mntpath = kstrdup(mntfile, GFP_KERNEL);

        if (!emnt->mntpath)
        {
            kfree(emnt);
            goto nomem;
        }
        list_add_tail(&emnt->list, &klflt_excluded_list);
        added = 1;
    }
    mutex_unlock(&klflt_excluded_mutex);

    if (vfs)
        vfs->mnt_flags |= KLFLT_MNT_SKIP;

    if (added)
    {
        pr_debug("Adding to exclude path %s\n", mntfile);
        klflt_cmd_put_path(mntfile);
    }

    goto exit;

nomem:
    mutex_unlock(&klflt_excluded_mutex);
    pr_err("%s: Failed to allocate mem (%s)\n", __func__, mntfile);
exit:
    mntput(vfs);
release_path:
    if (!badpath)
        path_release(&mntpath);

    return ret;
}

int klflt_is_mnt_excluded(struct vfsmount* vfs)
{
    int found;

    //pr_debug("%s: vfs = %p\n", __func__, vfs);

    mutex_lock(&klflt_excluded_mutex);
    found = klflt_is_mnt_excluded_unsafe(vfs);
    mutex_unlock(&klflt_excluded_mutex);

    return found;
}

static void inline klflt_excluded_clean(void)
{
    pr_debug("%s\n", __func__);

    if (klflt_cmd_rst_excl("all"))
    {
        pr_err("%s: Failed to clean klflt mountpoint exclude list\n", __func__);
    }
}

static int klflt_rst_mountpoint(const char* mntpath)
{
    struct vfsmount* vfs = NULL;
    struct path kernelpath;
    int badpath = kern_path(mntpath, LOOKUP_FOLLOW, &kernelpath);

    pr_debug("%s: path %s\n", __func__, mntpath);
    if (badpath || !kernelpath.mnt)
    {
        pr_err("%s: Failed to find %s\n", __func__, mntpath);
        return -1;
    }

    vfs = mntget(kernelpath.mnt);
    vfs->mnt_flags &= ~KLFLT_MNT_SKIP;
    mntput(vfs);

    if (!badpath)
        path_release(&kernelpath);

    return 0;
}

int klflt_cmd_rst_excl(char const* mntpath)
{
    struct klflt_excluded *entry, *etmp;
    int all = 0;

    pr_debug("%s: %s\n", __func__, mntpath);

    if (strcmp(mntpath, "all") == 0)
    {
        all = 1;
    }

    mutex_lock(&klflt_excluded_mutex);
    list_for_each_entry_safe(entry, etmp, &klflt_excluded_list, list)
    {
        if (all || strcmp(entry->mntpath, mntpath) == 0)
        {
            klflt_rst_mountpoint(entry->mntpath);
            klflt_excluded_remove(entry);
        }
    }
    mutex_unlock(&klflt_excluded_mutex);

    return 0;
}

int klflt_excluded_init(void)
{
    pr_debug("%s\n", __func__);

    return 0;
}

void klflt_excluded_destroy(void)
{
    pr_debug("%s\n", __func__);
    klflt_excluded_clean();
}
