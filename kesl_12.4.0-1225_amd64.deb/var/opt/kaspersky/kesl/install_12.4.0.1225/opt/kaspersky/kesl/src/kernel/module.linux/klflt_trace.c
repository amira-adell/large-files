#include "klflt.h"
#include "files.h"

#include <asm/current.h>
#include <linux/fs_struct.h>
#include <linux/kthread.h>
#include <linux/list.h>
#include <linux/mutex.h>
#include <linux/ptrace.h>
#include <linux/sched.h>
#include <linux/types.h>
#include <linux/unistd.h>
#include <linux/wait.h>
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 10, 0))
#include <linux/sched/task_stack.h>
#endif

#ifdef CONFIG_UTRACE
#include <linux/utrace.h>
#endif

#ifdef PTRACE_USES_CRED
#include <linux/cred.h>
#include <linux/ptrace.h>
#endif

// ---- mount binaries wildcard list management ----


static struct klflt_trace_ops trace_ops;
static atomic_t umount_bin_active = ATOMIC_INIT(0);

// ---- umountd ----

int (*copy_process_vm)(struct task_struct* tsk, unsigned long addr, void* buf,
                       int len, int write) = (void*)ACCESS_VM_ADDR;

#ifndef __NR_umount
#define __NR_umount __NR_umount2
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 25))
#define path_arg rdi
#define sysc_num orig_rax
#define sysc_ret rax
#else
#define path_arg di
#define sysc_num orig_ax
#define sysc_ret ax
#endif
#else
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 25))
#define path_arg ebx
#define sysc_num orig_eax
#define sysc_ret eax
#else
#define path_arg bx
#define sysc_num orig_ax
#define sysc_ret ax
#endif
#endif

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 25))
#define SAVE_PATH(p)                                                                \
    struct dentry* p        = current->fs->pwd;                                     \
    struct vfsmount* p##mnt = current->fs->pwdmnt;
#define LOAD_PATH(p)                                                                \
    current->fs->pwd    = pwd;                                                      \
    current->fs->pwdmnt = p##mnt;
#define SWAP_PATH(t)                                                                \
    current->fs->pwd    = t->fs->pwd;                                               \
    current->fs->pwdmnt = t->fs->pwdmnt;
#else
#define SAVE_PATH(p) struct path p = current->fs->pwd;
#define LOAD_PATH(p) current->fs->pwd = p;
#define SWAP_PATH(t) current->fs->pwd = t->fs->pwd;
#endif

static void check_umount_call(struct task_struct* tsk, struct pt_regs* regs)
{
    unsigned long origax = regs->sysc_num;

    if ((origax == __NR_umount) || (origax == __NR_umount2))
    {
        char* buf = kmalloc(PAGE_SIZE, GFP_KERNEL);
        int done = buf ? copy_process_vm(tsk, regs->path_arg, buf, PAGE_SIZE, 0) : 0;
        SAVE_PATH(pwd);

        if (!done)
        {
            if (buf)
                kfree(buf);
            return;
        }

        SWAP_PATH(tsk);
        if (regs->sysc_ret == -ENOSYS)
        {
            if (trace_ops.put)
                trace_ops.put(buf);
        }
        else if (regs->sysc_ret)
        {
            if (trace_ops.get)
                trace_ops.get(buf);
        }
        LOAD_PATH(pwd);

        kfree(buf);
    }

    return;
}

// ---- utrace ----

#ifdef CONFIG_UTRACE

#ifdef UTRACE_API_VERSION
#define UTRACE_ENGINE struct utrace_engine
#else
#define UTRACE_ENGINE struct utrace_attached_engine
#define UTRACE_API_VERSION 0
#endif

#ifdef UTRACE_RESUME_MASK
#define RESUME_ACTION UTRACE_RESUME
#else
#define RESUME_ACTION UTRACE_ACTION_RESUME
#endif

static u32 umount_report_syscall(
#ifdef UTRACE_RESUME_MASK
    enum utrace_resume_action action,
#endif
    UTRACE_ENGINE* engine,
#if UTRACE_API_VERSION < 20091216
    struct task_struct* tsk,
#endif
    struct pt_regs* regs)
{
    check_umount_call(current, regs);
    return RESUME_ACTION;
}

#ifdef UTRACE_RESUME_MASK
#define umount_report_signal NULL
#else
static u32 umount_report_signal(UTRACE_ENGINE* engine, struct task_struct* tsk,
                                struct pt_regs* regs, u32 action, siginfo_t* info,
                                const struct k_sigaction* orig_ka,
                                struct k_sigaction* return_ka)
{
    return RESUME_ACTION;
}
#endif

struct utrace_engine_ops umount_engine_ops = {
    .report_syscall_entry                  = umount_report_syscall,
    .report_syscall_exit                   = umount_report_syscall,
    .report_signal                         = umount_report_signal,
};

#define UMOUNT_UTRACE_FLAGS                                                         \
    (UTRACE_ATTACH_CREATE | UTRACE_ATTACH_MATCH_OPS | UTRACE_ATTACH_EXCLUSIVE)

#ifdef UTRACE_RESUME_MASK
#define UMOUNT_UTRACE_EVENTS                                                        \
    (UTRACE_EVENT(SYSCALL_ENTRY) | UTRACE_EVENT(SYSCALL_EXIT))
#define UTRACE_ATTACH(tsk)                                                          \
    utrace_attach_task(tsk, UMOUNT_UTRACE_FLAGS, &umount_engine_ops, NULL)
#define UTRACE_REPORT(tsk, engine)                                                  \
    utrace_set_events(tsk, engine, UMOUNT_UTRACE_EVENTS)
#define UTRACE_FINISH(engine) utrace_engine_put(engine)
#else
#define UMOUNT_UTRACE_EVENTS                                                        \
    (UTRACE_EVENT(SYSCALL_ENTRY) | UTRACE_EVENT(SYSCALL_EXIT) |                     \
     UTRACE_EVENT(SIGNAL_CORE) | UTRACE_EVENT(SIGNAL_TERM))
#define UTRACE_ATTACH(tsk)                                                          \
    utrace_attach(tsk, UMOUNT_UTRACE_FLAGS, &umount_engine_ops, NULL)
#if defined(utrace_lock) && defined(utrace_unlock)
#define UTRACE_REPORT(tsk, engine)                                                  \
    (utrace_set_flags(tsk, engine, UMOUNT_UTRACE_EVENTS), 0)
#else
#define UTRACE_REPORT(tsk, engine)                                                  \
    utrace_set_flags(tsk, engine, UMOUNT_UTRACE_EVENTS)
#endif
#define UTRACE_FINISH(engine)
#endif

static int klflt_exec_traced(struct task_struct* tsk)
{
    int ret = 0;

    UTRACE_ENGINE* engine = UTRACE_ATTACH(tsk);
    if (!IS_ERR(engine))
    {
        ret = UTRACE_REPORT(tsk, engine);
        UTRACE_FINISH(engine);
    }

    return ret;
}

// ---- ptrace ----

#elif PTRACE_DOLINK_ADDR && PTRACE_UNLINK_ADDR
static struct task_struct* umountd = NULL;

int (*ptrace_command)(struct task_struct* child, long request, long addr,
                      long data) = (void*)PTRACE_COMMAND_ADDR;
void (*ptrace_collect)(struct task_struct* child,
                       struct task_struct* parent
#ifdef PTRACE_USES_CRED
                       , const struct cred* task_cred
#endif
                      ) = (void*)PTRACE_DOLINK_ADDR;
void (*ptrace_release)(struct task_struct* child) = (void*)PTRACE_UNLINK_ADDR;

#ifndef PT_PTRACE_CAP
#define PT_PTRACE_CAP 0
#endif

#define UMOUNT_PTRACE_FLAGS                                                         \
    (PT_PTRACED | PT_TRACE_FORK | PT_TRACE_VFORK | PT_TRACE_CLONE | PT_PTRACE_CAP)

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 32))
#define wake_up_parent(parent, child)                                               \
    (wake_up_interruptible_sync(&parent->signal->wait_chldexit))
#elif (defined(WAKEUPSSYNC_HAS_THREE_ARGUMENTS))
#define wake_up_parent(parent, child)                                               \
    (__wake_up_sync_key(&parent->signal->wait_chldexit, TASK_INTERRUPTIBLE,         \
                        (child)))
#else
#define wake_up_parent(parent, child)                                               \
    (__wake_up_sync_key(&parent->signal->wait_chldexit, TASK_INTERRUPTIBLE, 1,      \
                        (child)))
#endif

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27))
#define for_each_ptraced(p, n)                                                      \
    list_for_each_entry_safe(p, n, &current->children, sibling)
#else
#define for_each_ptraced(p, n)                                                      \
    list_for_each_entry_safe(p, n, &current->ptraced, ptrace_entry)
#endif

#ifndef task_is_stopped
#define task_is_stopped(tsk) ((tsk->state & TASK_STOPPED) != 0)
#endif

#ifndef task_is_traced
#define task_is_traced(tsk) ((tsk->state & TASK_TRACED) != 0)
#endif

static int umount_wake_function(wait_queue_t* wait, unsigned mode, int sync,
                                void* key)
{
    struct task_struct* tracee = wait->private;

    if (!task_is_stopped(tracee))
    {
        __remove_wait_queue(&tracee->real_parent->signal->wait_chldexit, wait);
        kfree(wait);

        tracee->ptrace = UMOUNT_PTRACE_FLAGS;
        ptrace_command(tracee, PTRACE_SYSCALL, 0, 0);
    }

    return 1;
}

static void kavoas_grab(struct task_struct* task)
{
    if (!klflt_check_trusted(task) && !task->ptrace && !task->exit_state)
    {
        task->ptrace = UMOUNT_PTRACE_FLAGS;
#ifdef PTRACE_USES_CRED
#ifndef current_real_cred
#define current_real_cred() rcu_dereference_protected(current->real_cred,1)
#endif
        ptrace_collect(task, umountd, current_real_cred());
#else
        ptrace_collect(task, umountd);
#endif
    }
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 16)
#if defined(CONFIG_X86_64)
#define PT_REGS(tsk)                                                                \
    (struct pt_regs*)((unsigned long)tsk->thread.rsp0 - sizeof(struct pt_regs))
#else
#define PT_REGS(tsk)                                                                \
    (struct pt_regs*)((unsigned long)tsk->thread_info + THREAD_SIZE -               \
                      sizeof(struct pt_regs) - 8)
#endif
#else
#define PT_REGS(tsk) task_pt_regs(tsk)
#endif

#ifdef HAVE_KERNEL_SIGINFO
#define klflt_siginfo_t kernel_siginfo_t
#else
#define klflt_siginfo_t siginfo_t
#endif

static inline int klflt_dequeue_signal(klflt_siginfo_t *info)
{
    struct task_struct *tsk = current;
	unsigned long flags;
	int ret;

	spin_lock_irqsave(&tsk->sighand->siglock, flags);
	ret = dequeue_signal(tsk, &tsk->blocked, info);
	spin_unlock_irqrestore(&tsk->sighand->siglock, flags);

	return ret;
}

static int umount_wait(void* arg)
{
    allow_signal(SIGCHLD);
    allow_signal(SIGRTMAX - 3);
    allow_signal(SIGRTMAX - 2);
    allow_signal(SIGRTMAX - 1);
    allow_signal(SIGRTMAX);

    while (!kthread_should_stop())
    {
        while (signal_pending(current))
        {
            klflt_siginfo_t info;
            struct task_struct *tracee, *next;
            int signr = klflt_dequeue_signal(&info) & 0xFF;

            switch (signr)
            {
                case SIGRTMAX - 1:
                case SIGRTMAX - 2:
                case SIGRTMAX - 3:
                case SIGRTMAX:
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 24)
                    next = find_task_by_pid(info.si_value.sival_int);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 25)
                    next = find_task_by_pid_type_ns(
                        PIDTYPE_PID, info.si_value.sival_int, &init_pid_ns);
#else
                    next = pid_task(find_vpid(info.si_value.sival_int), PIDTYPE_PID);
#endif
                    if (next && next->mm && !IS_ERR(next) &&
                        next->state == TASK_UNINTERRUPTIBLE)
                    {
                        if (signr == SIGRTMAX)
                            kavoas_grab(next);
                        wake_up_process(next);
                    }
                    break;
                case SIGCHLD:
                    for_each_ptraced(tracee, next)
                    {
                        if (!tracee->ptrace)
                            continue;

                        if (tracee->exit_state)
                        {
                            ptrace_release(tracee);
                            send_sig(SIGCHLD, tracee->real_parent, 0);
                            wake_up_parent(tracee->real_parent, tracee);
                        }
                        else if (task_is_traced(tracee))
                        {
                            int snum   = tracee->exit_code;
                            int signal = (snum & 0x7f);
                            int call   = (signal == SIGTRAP);
                            int skip = ((snum == SIGTRAP) || (snum == SIGSTOP) ||
                                        !valid_signal(snum));

                            if (call)
                                check_umount_call(tracee, PT_REGS(tracee));

                            ptrace_command(tracee, PTRACE_SYSCALL, 0,
                                           skip ? 0 : snum);
                            if (signal == SIGSTOP)
                                ptrace_release(tracee);
                        }
                        else if (task_is_stopped(tracee))
                        {
                            wait_queue_t* wait_continue =
                                kmalloc(sizeof(wait_queue_t), GFP_KERNEL);

                            init_waitqueue_func_entry(wait_continue,
                                                      umount_wake_function);
                            wait_continue->private = tracee;

                            tracee->ptrace = 0;
                            send_sig(SIGCHLD, tracee->real_parent, 0);
                            wake_up_parent(tracee->real_parent, tracee);

                            add_wait_queue(
                                &tracee->real_parent->signal->wait_chldexit,
                                wait_continue);
                        }
                    }
                    break;
            }
        }

        set_current_state(TASK_INTERRUPTIBLE);
        schedule();
    }

    return 0;
}

static int klflt_exec_traced(struct task_struct* tsk)
{
    pr_debug("%s: starting tracing task\n", __func__);

    if (umountd)
    {
        klflt_siginfo_t info = {.si_signo = SIGRTMAX, .si_int = current->pid};
        set_current_state(TASK_UNINTERRUPTIBLE);
        send_sig_info(SIGRTMAX, &info, umountd);
        schedule_timeout(HZ);
    }

    return 0;
}

#else

// ---- nohook ----

static int klflt_exec_traced(struct task_struct* tsk)
{
    pr_debug("%s: No tracers configured\n", __func__);

    return 0;
}

#endif

static struct klflt_binary_fmt_ops binary_fmt_ops = {
    .exec_trace = klflt_exec_traced,
};

static int klflt_start_umountd(void)
{
    int rc = 0;
#ifdef UMOUNT_PTRACE_FLAGS
    umountd = kthread_run(umount_wait, NULL, "umountd");
    if (IS_ERR(umountd))
    {
        rc = PTR_ERR(umountd);
        printk(KERN_ERR "klflt: init umount thread failed, err=%d", rc);

    }
#endif
    return rc;
}

static void klflt_stop_umountd(void)
{
#ifdef UMOUNT_PTRACE_FLAGS
    if (umountd)
        kthread_stop(umountd);
    umountd = NULL;
#endif
}

int klflt_binary_tracer_init(struct klflt_trace_ops* ops) {
    int rc;

    pr_debug("%s", __func__);

    if (atomic_read(&umount_bin_active))
    {
        printk("%s: Already running\n", __func__);
        return -EALREADY;
    }

    trace_ops.get = ops->get;
    trace_ops.put = ops->put;

    rc = klflt_binfmt_handler_init(&binary_fmt_ops);
    if (rc < 0) {
        pr_err("%s: failed to register binfmt handler\n", __func__);
        goto exit;
    }

    rc = klflt_start_umountd();
    if (rc < 0)
        goto exit_umountd;

    atomic_xchg(&umount_bin_active, 1);

    goto exit;

exit_umountd:
    klflt_binfmt_handler_destroy();
exit:
    return rc;
}

void klflt_binary_tracer_destroy(void) {
    pr_debug("%s", __func__);

    if (atomic_read(&umount_bin_active))
    {
        atomic_xchg(&umount_bin_active, 0);
        klflt_stop_umountd();
        klflt_binfmt_handler_destroy();
    }
}