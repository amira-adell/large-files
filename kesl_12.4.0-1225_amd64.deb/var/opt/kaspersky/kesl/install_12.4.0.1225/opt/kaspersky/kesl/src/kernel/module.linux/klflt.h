#ifndef __KLFLT_H
#define __KLFLT_H

#include "kavmon.h"
#include "product_config.h"
#include "osdef.h"
#include <linux/fs.h>
#include <linux/mount.h>
#include <linux/kdev_t.h>
#include <linux/kref.h>
#include <linux/namei.h>
#include <linux/proc_fs.h>
#include <linux/types.h>
#include <linux/time.h>
#include <linux/version.h>

#ifndef __rcu
#   define __rcu
#endif // __rcu

#ifndef pr_err
#define pr_err(fmt, arg...) \
	printk(KERN_ERR fmt, ##arg)
#endif // pr_err

#ifndef pr_warning
#define pr_warning(fmt, arg...) \
	printk(KERN_WARNING fmt, ##arg)
#endif // pr_warning

#ifndef PROCCREATE_EXISTS
static inline struct proc_dir_entry *proc_create(const char *name, mode_t mode,
        struct proc_dir_entry *parent, const struct file_operations *fops)
{
    struct proc_dir_entry *res = create_proc_entry(name, mode, parent);
    if (res)
        res->proc_fops = fops;
    return res;
}
#endif

typedef struct
{
    int cache_enable;
    int cache_size;
    int32_t version;
    uint32_t max_fname_len;
    int8_t deny_too_long_fname;
} klflt_module_config_t;

struct klflt_connection;
struct klflt_group;
struct klflt_event;
struct klflt_mark;
struct klflt_iter_info;
struct klflt_request_metadata;
struct klflt_protocol_data;

struct klflt_ops {
    int (*handle_event)(struct klflt_group *group,
                        struct inode* inode,
                        u32 mask, const void* data, int data_type,
                        const unsigned char *file_name, u32 coockie,
                        struct klflt_iter_info* iter_info);
    void (*free_group_priv)(struct klflt_group* group);
    void (*freeing_mark)(struct klflt_mark *mark, struct klflt_group *group);
    void (*free_event)(struct klflt_event *event);
    void (*free_mark)(struct klflt_mark *mark);
};

struct klflt_event {
    struct list_head list;
    struct inode *inode;
    u32 mask;
};

#if(LINUX_VERSION_CODE < KERNEL_VERSION(3, 18, 0))
#define klflt_timespec timespec
#else
#define klflt_timespec timespec64
#endif

static inline int klflt_timespec_equal(const struct klflt_timespec *a,
				   const struct klflt_timespec *b)
{
	return (a->tv_sec == b->tv_sec) && (a->tv_nsec == b->tv_nsec);
}


struct klflt_file_info
{
    dev_t dev;
    unsigned long ino;
    unsigned long p_ino;
    loff_t size;
    unsigned int n_links;
    struct klflt_timespec m_time;
    struct klflt_timespec c_time;
};

struct klflt_binary_fmt_ops
{
    int (*exec_trace)(struct task_struct* tsk);
};

struct klflt_trace_ops
{
    int (*put)(const char* mntfile);
    int (*get)(const char* mntfile);
};

struct klflt_mounts_ops
{
    int (*add_mount)(struct vfsmount* mnt);
    int (*remove_mount)(struct vfsmount* mnt);
    void (*cifs_calls_replace)(struct dentry* d_root);
    void (*cifs_calls_restore)(void);
};

struct klflt_interceptor_ops
{
    int (*start)(void);
    int (*stop)(void);
};

typedef struct klflt_file_info klflt_file_info_t;

struct klflt_watchdog_ops
{
    void (*invoke)(void);
};

#define timespec_t struct klflt_timespec
#define kdev_t_to_nr(dev) new_encode_dev(dev)

// file.c
static __inline__ int klflt_file_info_equal(
    const struct klflt_file_info* file1, const struct klflt_file_info* file2)
{
    return (file1->dev == file2->dev && file1->ino == file2->ino);
}
int get_exec_info(struct task_struct __rcu *task, struct klflt_file_info* file);
void klflt_fill_file_info(struct dentry* dentry, struct klflt_file_info* info);

// klflt_binary.c
int klflt_binfmt_handler_init(struct klflt_binary_fmt_ops* ops);
void klflt_binfmt_handler_destroy(void);

//klflt_cache.c
int klflt_cache_init(void);
void klflt_cache_destroy(void);
int klflt_cache_start(int size);
void klflt_cache_stop(void);
void klflt_cache_add(const struct klflt_file_info* file);
void klflt_cache_del(dev_t dev, unsigned long ino);
const struct klflt_file_info* klflt_cached(dev_t dev, unsigned long ino);
void klflt_cache_clear(void);

// klflt_check.c
int klflt_check_before_open(struct inode* inode, struct file* file);
int klflt_check_after_close(struct inode* inode, struct file* file);
void klflt_check_unlink(struct inode* dir, struct dentry* dentry);
void klflt_check_rename(struct inode* old_dir, struct dentry* old_dentry,
    struct inode* new_dir, struct dentry* new_dentry);
int klflt_check_trusted(struct task_struct *tsk);
int klflt_check_init(void);
void klflt_check_destroy(void);

// klflt_connection.c
int connection_is_data_ready(const struct klflt_connection* conn);
int connection_init(struct klflt_connection* conn);
void connection_destroy(struct klflt_connection* conn);
int connection_get_answer(struct klflt_connection* conn,
                                 struct klflt_protocol_data* response);

//klflt_excludes.c
int klflt_excluded_init(void);
void klflt_excluded_destroy(void);
int klflt_is_mnt_excluded(struct vfsmount* vfs);
int klflt_cmd_add_excl(char const* mntfile);
int klflt_cmd_rst_excl(char const* mntpath);

// klflt_intercept.c
int klflt_intercept_init(struct klflt_interceptor_ops* interceptor_ops);
void klflt_intercept_destroy(void);

// klflt_interface.c
int klflt_interface_v2_init(struct klflt_interceptor_ops* interceptor_ops);
void klflt_interface_v2_destroy(void);

// klflt_mounts.c
int klflt_cmd_put_path(char const* mntfile);
int klflt_cmd_get_path(char const* mntfile);
int klflt_mounts_handler_init(struct klflt_mounts_ops* ops);
void klflt_mounts_handler_destroy(void);

// klflt_queue.c
int klflt_queue_init(void);
void klflt_queue_destroy(void);
int klflt_queue_get_id(void);
void check_req_queue_add(struct klflt_request_metadata* reqd);
struct klflt_request_metadata* check_req_queue_get(void);
int check_req_queue_put(struct klflt_request_metadata* reqd);
int check_req_queue_empty(void);
void klflt_queue_set_answer(u_short queue_id, int answer);
void klflt_queue_wakeup(u_short queue_id);
void klflt_queue_clear(void);

// klflt_rfs.c
int klflt_rfs_init(struct klflt_mounts_ops* ops);
void klflt_rfs_destroy(void);

// klflt_smb.c
int klflt_smb_init(struct klflt_mounts_ops* ops);
void klflt_smb_destroy(void);

// klflt_trace.c
int klflt_binary_tracer_init(struct klflt_trace_ops* ops);
void klflt_binary_tracer_destroy(void);
int klflt_cmd_rs_trace(char const* wildcard);
int klflt_cmd_de_trace(char const* wildcard);
int klflt_cmd_in_trace(char const* wildcard);

// klflt_trusted.c
int klflt_trusted_init(void);
void klflt_trusted_destroy(void);
int klflt_register_trusted_file(const struct klflt_file_info* file);
int klflt_register_trusted_process(pid_t pid, const struct klflt_file_info* file);
int klflt_is_file_trusted(const struct klflt_file_info* file);
int klflt_is_process_trusted(pid_t pid, const struct klflt_file_info* file, int strong);
void klflt_trusted_unregister_proc(const pid_t pid);
void klflt_trusted_unregister_file(const struct klflt_file_info* finfo);

// klflt_version.c
int klflt_version_init(void);
void klflt_version_destroy(void);

// klflt_watchdog.c
int klflt_watchdog_init(struct klflt_watchdog_ops* ops);
int klflt_watchdog_destroy(void);

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 19, 0))
#ifndef f_dentry
#define f_dentry f_path.dentry
#endif
#endif


#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 25))
#define GET_NAMEIDATA_PATH(nameidata_struct) (nameidata_struct)
#elif(LINUX_VERSION_CODE < KERNEL_VERSION(3, 19, 0))
#define GET_NAMEIDATA_PATH(nameidata_struct) ((&nameidata_struct)->path)
#define path_release(path_struct) path_put(path_struct)
#else
#define GET_NAMEIDATA_PATH(path) (path)
#define path_release(path_struct) path_put(path_struct)
#endif


#if(LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 20))
struct path {
	struct vfsmount *mnt;
	struct dentry *dentry;
};

static inline void path_put(struct path *path)
{
	dput(path->dentry);
	mntput(path->mnt);
}

#endif

#if(LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 28))
static inline int kern_path(const char *name, unsigned int flags, struct path *path)
{
	struct nameidata nd;
	int res = path_lookup(name, flags, &nd);
	if (!res)
    {
        path->mnt = GET_NAMEIDATA_PATH(nd).mnt;
        path->dentry = GET_NAMEIDATA_PATH(nd).dentry;
    }
	return res;
}
#endif


#if !(LINUX_VERSION_CODE < KERNEL_VERSION(4,13,0))
#define wait_queue_t wait_queue_entry_t
#endif

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 9, 0))
#define f_vfsmnt f_path.mnt
#endif

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 14, 0)) ||                             \
    (defined(CONFIG_UIDGID_STRICT_TYPE_CHECKS) && CONFIG_UIDGID_STRICT_TYPE_CHECKS)
#define get_current_euid() from_kuid_munged(&init_user_ns, current_euid())
#define get_current_egid() from_kgid_munged(&init_user_ns, current_egid())
#else
#define i_uid_read(inode) ((inode)->i_uid)
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 29))
#define get_current_euid() current_euid()
#define get_current_egid() current_egid()
#else
#define get_current_euid() current->euid
#define get_current_egid() current->egid
#endif
#endif

#ifndef i_uid_read
#ifdef HAVE_LINUXUIDGID
#define i_uid_read(inode) (__kuid_val(inode->i_uid))
#else
#define i_uid_read(inode) ((inode)->i_uid)
#endif
#endif

#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif


#ifdef DEBUG
#define klflt_assert_mutex_locked(x) BUG_ON(!mutex_is_locked(x))
#else
#define klflt_assert_mutext_locked(x) {}
#endif

#define UNUSED(x) (void)(x)
#define MOUNTS_FILENAME "/proc/mounts"

#define KLFLT_MNT_SKIP 0x20000000

#endif
