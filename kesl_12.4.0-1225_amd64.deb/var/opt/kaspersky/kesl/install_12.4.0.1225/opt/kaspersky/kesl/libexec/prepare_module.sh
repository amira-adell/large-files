#!/bin/sh -e

readonly THIS_PATH="$(readlink -e "$(dirname "$0")")"
readonly THIS_DIRECTORY="${THIS_PATH}/"
readonly THIS_SCRIPT_INSTALL_DIRECTORY='/opt/kaspersky/kesl/libexec/'

readonly SRC_DIRECTORY='/opt/kaspersky/kesl/src/'
readonly KERNEL_MODULE_BUILDS_DIRECTORY='/var/opt/kaspersky/kesl/private/module/'

readonly PACKAGE_VERSION_WC_DIRECTORY="${THIS_DIRECTORY%%${THIS_SCRIPT_INSTALL_DIRECTORY}}"
readonly WC_SRC_DIRECTORY="${PACKAGE_VERSION_WC_DIRECTORY}${SRC_DIRECTORY}"
readonly MODULE_SRC="${WC_SRC_DIRECTORY}kernel"
readonly LINUX_KERNEL="$(uname -r)"
readonly LINUX_KERNEL_SRC_PATH="/lib/modules/${LINUX_KERNEL}/build"
readonly MODULE_INSTALL_PATH="/lib/modules/${LINUX_KERNEL}/misc"
readonly WC_MODULE_CACHE_BUILD_PATH="${PACKAGE_VERSION_WC_DIRECTORY}${KERNEL_MODULE_BUILDS_DIRECTORY}${LINUX_KERNEL}"

Clean()
{
    make distclean || true
    rm -rf bin || true
}

Build()
{
    if [ ! -x 'configure' ]; then
        echo "ERROR: could not find kernel module sources" 1>&2
        exit 255
    fi

    export PATH
    ./configure --with-kernelsrc="${LINUX_KERNEL_SRC_PATH}"
    make
}

CopyBinFiles()
{
    local srcPath="${1:?}"
    local dstPath="${2:?}"

    mkdir -p "${dstPath}"

    cp -rf -t "${dstPath}" "${srcPath}/."
}

SaveToCache()
{
    CopyBinFiles "bin" "${WC_MODULE_CACHE_BUILD_PATH}"
}

Install()
{
    CopyBinFiles "${WC_MODULE_CACHE_BUILD_PATH}" "${MODULE_INSTALL_PATH}"
    /sbin/depmod -a
}

Main()
{
    local cmd="$1"

    Clean
    Build
    SaveToCache
    Clean

    if [ "${cmd}" = '--build-only' ]; then
        return 0
    fi

    Install
}

cd "${MODULE_SRC}"
Main "$@"
