/*
 * RedirFS: Redirecting File System
 * Written by Frantisek Hrbata <frantisek.hrbata@redirfs.org>
 *
 * Copyright 2008 - 2010 Frantisek Hrbata
 * All rights reserved.
 *
 * This file is part of RedirFS.
 *
 * RedirFS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * RedirFS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with RedirFS. If not, see <http://www.gnu.org/licenses/>.
 *
 * 2010-08-20 Changes made by Vasiliy Novikov:
 *   - "MODULE_INFO(supported, "external");" line added.
 */

#include "rfs.h"
#include "../product_config.h"
#include "linux/seq_file.h"
#include "linux/proc_fs.h"

#ifndef PROCCREATE_EXISTS
static inline struct proc_dir_entry *proc_create(const char *name, mode_t mode,
        struct proc_dir_entry *parent, const struct file_operations *fops)
{
    struct proc_dir_entry *res = create_proc_entry(name, mode, parent);
    if (res)
        res->proc_fops = fops;
    return res;
}
#endif

struct rfs_info* rfs_info_none;

static int redirfs_proc_version_print(struct seq_file* m, void* v)
{
    seq_printf(m, "%s", LFS_PRODUCT_VERSION);
    return 0;
}


static int redirfs_version_open(struct inode* inode, struct file* file)
{
    return single_open(file, redirfs_proc_version_print, NULL);
}

static const struct file_operations redirfs_version_fops = {
    .owner                                        = THIS_MODULE,
    .open                                         = redirfs_version_open,
    .read                                         = seq_read,
    .llseek                                       = seq_lseek,
    .release                                      = single_release,
};

int rfs_precall_flts(struct rfs_chain* rchain, struct rfs_context* rcont,
                     struct redirfs_args* rargs)
{
    enum redirfs_rv (*rop)(redirfs_context, struct redirfs_args*);
    enum redirfs_rv rv;

    if (!rchain)
        return 0;

    rargs->type.call = REDIRFS_PRECALL;

    rcont->idx = rcont->idx_start;

    for (; rcont->idx < rchain->rflts_nr; rcont->idx++)
    {
        rop = rchain->rflts[rcont->idx]->cbs[rargs->type.id].pre_cb;
        if (!rop)
            continue;

        rv = rop(rcont, rargs);
        if (rv == REDIRFS_STOP)
            return -1;
    }

    rcont->idx--;

    return 0;
}

void rfs_postcall_flts(struct rfs_chain* rchain, struct rfs_context* rcont,
                       struct redirfs_args* rargs)
{
    enum redirfs_rv (*rop)(redirfs_context, struct redirfs_args*);

    if (!rchain)
        return;

    rargs->type.call = REDIRFS_POSTCALL;

    for (; rcont->idx >= rcont->idx_start; rcont->idx--)
    {
        rop = rchain->rflts[rcont->idx]->cbs[rargs->type.id].post_cb;
        if (rop)
            rop(rcont, rargs);
    }

    rcont->idx++;
}

static int __init rfs_init(void)
{
    int rv;

    rfs_info_none = rfs_info_alloc(NULL, NULL);
    if (IS_ERR(rfs_info_none))
        return PTR_ERR(rfs_info_none);

    rv = rfs_dentry_cache_create();
    if (rv)
        goto err_dentry_cache;

    rv = rfs_inode_cache_create();
    if (rv)
        goto err_inode_cache;

    rv = rfs_file_cache_create();
    if (rv)
        goto err_file_cache;

    if (!proc_create(REDIRFS_VERSION_NAME, 0, NULL, &redirfs_version_fops))
    {
        printk(KERN_INFO "klflt: Warning! Failed to create %s\n",
               REDIRFS_VERSION_NAME);
        goto err_proc_create;
    }

    printk(KERN_INFO "Redirecting File System Framework Version " REDIRFS_VERSION
                     " <www.redirfs.org>\n");

    return 0;

    remove_proc_entry(REDIRFS_VERSION_NAME, NULL);
err_proc_create:
    rfs_file_cache_destory();
err_file_cache:
    rfs_inode_cache_destroy();
err_inode_cache:
    rfs_dentry_cache_destory();
err_dentry_cache:
    rfs_info_put(rfs_info_none);
    return rv;
}

module_init(rfs_init);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Frantisek Hrbata <frantisek.hrbata@redirfs.org>");
MODULE_VERSION(LFS_PRODUCT_VERSION);
MODULE_DESCRIPTION("Redirecting File System Framework Version " REDIRFS_VERSION
                   " <www.redirfs.org>");
MODULE_INFO(supported, "external");
