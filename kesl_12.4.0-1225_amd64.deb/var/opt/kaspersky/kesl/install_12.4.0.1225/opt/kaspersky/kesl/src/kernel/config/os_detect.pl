#!/usr/bin/perl -w

sub os_determ()
{
    my $distrib = "unknown";
    my $os=`uname`;
    
    if ( $os =~ /linux/i ) 
    {
    	my ($linux, $version);

		if ( defined(glob("/etc/*release")) )
		{
	    	$linux = glob("/etc/*release");
	    	$distrib =`head -1 $linux`;
		}
		
		if ( $distrib =~ /(\d\.\d)/ )
		{
		    $version=$1;
		}
		elsif (defined(glob("/etc/debian*"))) 
		{
			$linux = glob("/etc/debian*");
			$distrib = "Debian" ; 
			$version = `head -1 /etc/debian_version`; 
			$distrib="Debian $version";
		}
		else
		{
			if (defined(glob("/etc/slackware*"))) 
			{
				$linux = glob("/etc/slackware*");
				$distrib = "Slackware" ; 
				$version = `head -1 /etc/slackware-version`;
				
				if ( $version =~ /(\d\.\d)/ )
				{
					$version=$1;
				}
				
				$distrib = "$distrib $version";
	    	}				    
		}
	}
    elsif ( $os =~ /sunos/i )
    {
		$distrib=`uname -prs`;
	}
    elsif ($os =~ /[hp-ux,bsd]/i )
    {
		$distrib=`uname -rs`;
	}
    else 
    {
        print "$os: unknown operation system";
	}

	chomp $distrib;
	return $distrib;
}


$system = os_determ();
print "$system";

exit 0;

