/*
 * CIFS interceptor. It works correct only if cifs compiled as a module.
 */
#include "klflt.h"
#include "klflt_smb.h"
#include "redirfs/rfs.h"

#include <asm/cacheflush.h>
#include <linux/pagemap.h>


#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27))
#define ptep_modify_prot_start ptep_get_and_clear
#define ptep_modify_prot_commit set_pte_at
#endif

#if defined(__CONFIG_CIFS_MODULE)

#define WRITE_ENABLE(addr, error) change_writeable((unsigned long)(addr), 1, (error))
#define WRITE_DISABLE(addr, error)                                                  \
    change_writeable((unsigned long)(addr), 0, (error))

#define CIFS_DBGPRN(fmt, ...) pr_debug(fmt, ##__VA_ARGS__)

typedef void (*pfunc_t)(void);

struct call_restore_item
{
    pfunc_t* loc; /* location of the call that is replaced */
    pfunc_t old;  /* old value of the replaced function pointer */
};

#define CR_ARR_SIZE 16
static struct call_restore_item calls_restore_array[CR_ARR_SIZE];
static int calls_restore_count = 0;
static DEFINE_MUTEX(calls_restore_mutex);
static struct module* cifs_module = NULL;


static int change_writeable(unsigned long addr, int write, int* error)
{
    pgd_t* pgdp;
    pud_t pud, *pudp;
    pmd_t pmd, *pmdp;
    pte_t pte, *ptep;
    spinlock_t* ptl;
    int protset          = 0;
    struct mm_struct* mm = current->active_mm;
#ifdef P4D_MASK
    p4d_t* p4dp;
#endif

    down_write(&mm->mmap_sem);

    flush_cache_mm(mm);
    pgdp = pgd_offset(mm, addr);
    if (pgd_none(*pgdp) || pgd_bad(*pgdp))
    {
        *error = -ENOMEM;
        goto exit;
    }
#ifdef P4D_MASK
    p4dp = p4d_offset(pgdp, addr);
    if (p4d_present(*p4dp) == 0)
    {
        *error = -ENOMEM;
        goto exit;
    }
    pudp = pud_offset(p4dp, addr);
#else
    pudp = pud_offset(pgdp, addr);
#endif

    pud = *pudp;
    if (pud_none(*pudp) || pud_bad(*pudp))
    {
        *error = -ENOMEM;
        goto exit;
    }
    pmdp = pmd_offset(pudp, addr);
    pmd = *pmdp;
    if (pmd_none(*pmdp) || pmd_bad(*pmdp))
    {
        *error = -ENOMEM;
        goto exit;
    }

    ptl  = pte_lockptr(mm, pmdp);
    ptep = pte_offset_map(pmdp, addr);

/* god bless spin locking. actually this spinlock (without try) permanently blocks
 * the execution on kernels before 2.6.25. but on the other hand we use mmap_sem
 * and moreover cifs on this kernels isn't write protected. So this code will be
 * robustly working. However any approach to apply clr/set write protection to
 * other regions i.e. syscalls table will require more deep analysis */
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 24)
    spin_lock(ptl);
#endif
    pte = *ptep;

    protset = !pte_write(pte);
    if (protset ^ !write)
    {
        pte_t ptent = ptep_modify_prot_start(mm, addr, ptep);
        ptent       = pte_mkdirty(ptent);
        ptent = protset ? pte_mkwrite(ptent) : pte_wrprotect(ptent);
        ptep_modify_prot_commit(mm, addr, ptep, ptent);
    }

#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 24)
    spin_unlock(ptl);
#endif
    pte_unmap(ptep);
    *error = 0;

exit:
    up_write(&mm->mmap_sem);

    return protset;
}


static void call_replace_nolock(pfunc_t* loc, pfunc_t new_call)
{
    if (calls_restore_count >= CR_ARR_SIZE)
    {
        printk(
            KERN_ERR
            "klflt: increase calls_restore_array size to properly intercept CIFS\n");
        return;
    }
    calls_restore_array[calls_restore_count].loc = loc;
    calls_restore_array[calls_restore_count].old = *loc;
    *loc                                         = new_call;
    ++calls_restore_count;
}

typedef int (*fop_open_t)(struct inode* inode, struct file* file);
static volatile fop_open_t cifs_open = NULL;
static int smbcheck_open(struct inode* inode, struct file* file)
{
    int ret, res;
    fop_open_t lf_open = cifs_open;

    if (!lf_open)
        return -ERESTARTSYS;

    if (klflt_is_mnt_excluded(file->f_vfsmnt))
    {
        pr_debug("smbcheck exclude: %s\n", file->f_dentry->d_name.name);
        res = 0;
    }
    else
    {
        res = klflt_check_before_open(inode, file);
    }

    if ((res == -ENOENT) && (file->f_flags & O_CREAT))
        res = 0;

    //dump_syscall(SC_OPEN, 0, file->f_dentry, res);

#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 6, 0)
    if ((file->f_flags & O_EXCL) && (file->f_dentry->d_fsdata == (void *)-1UL)) {
        file->f_dentry->d_fsdata = NULL;
        file->f_flags &= ~O_EXCL;
    }
#endif

    if (0 == res)
        ret = lf_open(inode, file);
    else
        ret = res;

    return ret;
}

typedef int (*fop_release_t)(struct inode* inode, struct file* file);
static volatile fop_release_t cifs_close = NULL;
static int smbcheck_release(struct inode* inode, struct file* file)
{
    int ret, res;
    fop_release_t lf_close = cifs_close;

    if (!lf_close)
        return -ERESTARTSYS;

    ret = lf_close(inode, file);

    if (klflt_is_mnt_excluded(file->f_vfsmnt))
    {
        pr_debug("smbcheck release exclude: %s\n", file->f_dentry->d_name.name);
        res = 0;
    }
    else
    {
        res = klflt_check_after_close(inode, file);
    }

    return ret;
}

#if !defined(IOP_RENAME_HAS_5ARGS)
typedef int (*iop_rename_t)(struct inode* i_src, struct dentry* d_src,
                            struct inode* i_tgt, struct dentry* d_tgt);
static volatile iop_rename_t cifs_rename = NULL;
static int smbcheck_rename(struct inode* i_src, struct dentry* d_src,
                           struct inode* i_tgt, struct dentry* d_tgt)
#else
typedef int (*iop_rename_t)(struct inode* i_src, struct dentry* d_src,
                            struct inode* i_tgt, struct dentry* d_tgt, unsigned int flags);
static volatile iop_rename_t cifs_rename = NULL;
static int smbcheck_rename(struct inode* i_src, struct dentry* d_src,
                           struct inode* i_tgt, struct dentry* d_tgt, unsigned int flags)
#endif
{
    int res;
    iop_rename_t lf_rename = cifs_rename;

    if (!lf_rename)
        return -ERESTARTSYS;

    pr_debug("smbcheck_rename: src:%s tgt:%s\n", d_src->d_name.name,
                d_tgt->d_name.name);

#if !defined(IOP_RENAME_HAS_5ARGS)
    klflt_check_rename(i_src, d_src, i_tgt, d_tgt);
    res = lf_rename(i_src, d_src, i_tgt, d_tgt);
#else
    klflt_check_rename(i_src, d_src, i_tgt, d_tgt);
    res = lf_rename(i_src, d_src, i_tgt, d_tgt, flags);
#endif
    return res;
}

typedef int (*iop_unlink_t)(struct inode*, struct dentry*);
static volatile iop_unlink_t cifs_unlink = NULL;
static int smbcheck_unlink(struct inode* inode, struct dentry* direntry)
{
    int res;
    iop_unlink_t lf_unlink = cifs_unlink;

    if (!lf_unlink)
        return -ERESTARTSYS;

    CIFS_DBGPRN("smbcheck_unlink: direntry:%s\n", direntry->d_name.name);
    klflt_check_unlink(inode, direntry);

    res = lf_unlink(inode, direntry);

    return res;
}

static void replace_file_ops_nolock(struct inode* fi)
{
    int protected_iop, protected_fop, error = 0;

    int fop_open = fi->i_fop->open && smbcheck_open != fi->i_fop->open;
    int fop_release = fi->i_fop->release && smbcheck_release != fi->i_fop->release;
    int iop_rename = fi->i_op->rename && smbcheck_rename != fi->i_op->rename;
    int iop_unlink = fi->i_op->unlink && smbcheck_unlink != fi->i_op->unlink;

    if (fop_open || fop_release || iop_rename || iop_unlink)
    {
        protected_iop = WRITE_ENABLE(fi->i_op, &error);
        if (error)
        {
            printk(KERN_ERR "klflt: failed to replace cifs file inode operations\n");
            return;
        }
        protected_fop = WRITE_ENABLE(fi->i_fop, &error);
        if (error)
        {
            printk(KERN_ERR "klflt: failed to replace cifs file file operations\n");
            if (protected_iop)
                WRITE_DISABLE(fi->i_op, &error);
            return;
        }

        if (fop_open)
        {
            CIFS_DBGPRN("replace cifs_open(%p) with %p\n",
                (pfunc_t*)&fi->i_fop->open, (pfunc_t)smbcheck_open);

            if (cifs_open && cifs_open != fi->i_fop->open)
                printk(KERN_ERR "klflt: different cifs_open functions\n");
            cifs_open = fi->i_fop->open;
            call_replace_nolock((pfunc_t*)&fi->i_fop->open, (pfunc_t)smbcheck_open);
        }
        if (fop_release)
        {
            CIFS_DBGPRN("replace cifs_close(%p) with %p\n",
                (pfunc_t*)&fi->i_fop->release, (pfunc_t)smbcheck_release);
            if (cifs_close && cifs_close != fi->i_fop->release)
                printk(KERN_ERR "klflt: different cifs_close functions\n");
            cifs_close = fi->i_fop->release;
            call_replace_nolock((pfunc_t*)&fi->i_fop->release,
                (pfunc_t)smbcheck_release);
        }
        if (iop_rename)
        {
            CIFS_DBGPRN("replace cifs_rename(%p) with %p\n",
                (pfunc_t*)&fi->i_op->rename, (pfunc_t)smbcheck_rename);
            if (cifs_rename && cifs_rename != fi->i_op->rename)
                printk(KERN_ERR "klflt: different cifs_rename functions\n");
            cifs_rename = fi->i_op->rename;
            call_replace_nolock((pfunc_t*)&fi->i_op->rename, (pfunc_t)smbcheck_rename);
        }
        if (iop_unlink)
        {
            CIFS_DBGPRN("replace cifs_unlink(%p) with %p\n",
                (pfunc_t*)&fi->i_op->unlink, (pfunc_t)smbcheck_unlink);
            if (cifs_unlink && cifs_unlink != fi->i_op->unlink)
                printk(KERN_ERR "klflt: different cifs_unlink functions\n");
            cifs_unlink = fi->i_op->unlink;
            call_replace_nolock((pfunc_t*)&fi->i_op->unlink, (pfunc_t)smbcheck_unlink);
        }

        if (protected_fop)
            WRITE_DISABLE(fi->i_fop, &error);
        if (protected_iop)
            WRITE_DISABLE(fi->i_op, &error);
    }
}

static struct rfs_dcache_entry* interceptor_dcache_entry_alloc(
    struct dentry* dentry, struct list_head* list)
{
    struct rfs_dcache_entry* entry;

    entry = kzalloc(sizeof(struct rfs_dcache_entry), GFP_KERNEL);
    if (!entry)
        return ERR_PTR(-ENOMEM);

    INIT_LIST_HEAD(&entry->list);
    entry->dentry = dget(dentry);
    list_add_tail(&entry->list, list);

    return entry;
}

static void interceptor_dcache_entry_free(struct rfs_dcache_entry* entry)
{
    if (!entry)
        return;

    list_del_init(&entry->list);
    dput(entry->dentry);
    kfree(entry);
}

static void interceptor_dcache_entry_free_list(struct list_head* head)
{
    struct rfs_dcache_entry* entry;
    struct rfs_dcache_entry* tmp;

    list_for_each_entry_safe(entry, tmp, head, list)
    {
        interceptor_dcache_entry_free(entry);
    }
}

static int interceptor_dcache_get_subs(
    struct dentry* dir, struct list_head* sibs,
    struct dentry* last)
{
    LIST_HEAD(pool);
    int pool_size = 32;
    int pool_small;
    struct rfs_dcache_entry* sib;
    struct dentry* dentry;
    int i;

    CIFS_DBGPRN("interceptor_dcache_get_subs %s\n", dir->d_name.name);

again:
    pool_small = 0;

    for (i = 0; i < pool_size; i++)
    {
        sib = interceptor_dcache_entry_alloc(NULL, &pool);
        if (IS_ERR(sib))
        {
            interceptor_dcache_entry_free_list(&pool);
            return PTR_ERR(sib);
        }
    }

    DCACHE_LOCK(dir);

    rfs_for_each_d_child(dentry, &dir->d_subdirs)
    {
        if (last && (dentry == last))
            break;

        if (list_empty(&pool))
        {
            pool_small = 1;
            break;
        }

        CIFS_DBGPRN("interceptor_dcache_get_subs (%s): %s\n",
            dir->d_name.name, dentry->d_name.name);
        DENTRY_NESTED(dentry);
        sib         = list_entry(pool.next, struct rfs_dcache_entry, list);
        sib->dentry = dget_dlock(dentry);
        DENTRY_UNLOCK(dentry);
        list_move(&sib->list, sibs);
    }

    DCACHE_UNLOCK(dir);

    interceptor_dcache_entry_free_list(&pool);

    if (pool_small)
    {
        interceptor_dcache_entry_free_list(sibs);
        pool_size *= 2;
        goto again;
    }

    return 0;
}

static int __dir_walk_replace_file_ops_nolock(struct dentry* dir, int recursive)
{
    struct rfs_dcache_entry* entry;
    struct rfs_dcache_entry* tmp;
    LIST_HEAD(subs);

    int rv = interceptor_dcache_get_subs(dir, &subs, NULL);
    if (rv < 0) {
        CIFS_DBGPRN("Can't read subfolders for dentry %p\n", dir);
        return rv;
    }

    list_for_each_entry_safe(entry, tmp, &subs, list)
    {
        CIFS_DBGPRN("__dir_walk_replace_file_ops_nolock (%s): %s\n",
            dir->d_name.name, entry->dentry->d_name.name);

        if (entry->dentry->d_inode)
        {
            if (S_IFREG == (entry->dentry->d_inode->i_mode & S_IFMT))
            {
                DENTRY_NESTED(entry->dentry);
                replace_file_ops_nolock(entry->dentry->d_inode);
                DENTRY_UNLOCK(entry->dentry);
                rv = 1;
                goto exit;
            }
            else if (recursive && S_IFDIR == (entry->dentry->d_inode->i_mode & S_IFMT))
            {
                rv = __dir_walk_replace_file_ops_nolock(entry->dentry, 1);
                if (rv) {
                    goto exit;
                }
            }
        }
    }


exit:
    interceptor_dcache_entry_free_list(&subs);

    return rv;
}

static void dir_walk_replace_file_ops_recursive_nolock(struct dentry* dir)
{

    __dir_walk_replace_file_ops_nolock(dir, 1);

}
static void dir_walk_replace_file_ops(struct dentry* dir)
{
    rfs_mutex_lock(&calls_restore_mutex);

    __dir_walk_replace_file_ops_nolock(dir, 0);

    rfs_mutex_unlock(&calls_restore_mutex);
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 6, 0)
typedef struct dentry* (*iop_lookup_t)(struct inode* parent_dir_inode,
                                       struct dentry* direntry,
                                       struct nameidata* nd);
static volatile iop_lookup_t cifs_lookup = NULL;
static struct dentry* smbcheck_lookup(struct inode* parent_dir_inode,
                                      struct dentry* direntry, struct nameidata* nd)
#else
typedef int (*iop_atomic_open_t)(struct inode* dir, struct dentry* direntry,
                                 struct file* file, unsigned int flags, umode_t mode,
                                 int* opened);
static volatile iop_atomic_open_t cifs_atomic_open = NULL;

#if 0
static const iop_atomic_open_t smbcheck_atomic_open = NULL;
#else
// smb_atomic_open returns 0 if file is created, 1 if file was found (still needs cifs_open to open it)
// or an error otherwise
static int smbcheck_atomic_open(struct inode *inode, struct dentry *direntry, struct file *file,
					unsigned int flags, umode_t mode, int *opened)
{
    int res;
    iop_atomic_open_t lf_atomic_open = cifs_atomic_open;

    if(!lf_atomic_open) return -ERESTARTSYS;

    res = lf_atomic_open(inode, direntry, file, flags, mode, opened);

    return res;
}
#endif

typedef struct dentry* (*iop_lookup_t)(struct inode* parent_dir_inode,
                                       struct dentry* direntry, unsigned int flags);
static volatile iop_lookup_t cifs_lookup = NULL;

static struct dentry* smbcheck_lookup(struct inode* parent_dir_inode,
                                      struct dentry* direntry, unsigned int flags)
#endif
{
    struct dentry* res;
    iop_lookup_t lf_lookup = cifs_lookup;

    if (!lf_lookup)
        return ERR_PTR(-ERESTARTSYS);

#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 6, 0)
    res = lf_lookup(parent_dir_inode, direntry, nd);
#else
    res = lf_lookup(parent_dir_inode, direntry, flags);
    if (0 == res && !direntry->d_inode && (flags & LOOKUP_EXCL))
        direntry->d_fsdata = (void*)-1UL;
#endif

    if (0 == res && direntry->d_inode)
    {
        CIFS_DBGPRN("smbcheck_lookup: i_mode:%o iop:%p fop:%p\n",
                    direntry->d_inode->i_mode, direntry->d_inode->i_op,
                    direntry->d_inode->i_fop);
        if (S_IFREG == (direntry->d_inode->i_mode & S_IFMT))
        {
            rfs_mutex_lock(&calls_restore_mutex);
            replace_file_ops_nolock(direntry->d_inode);
            rfs_mutex_unlock(&calls_restore_mutex);
        }
    }

    return res;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 7, 0)
typedef int (*fop_iterate_shared_t)(struct file* file, struct dir_context* ctx);
static volatile fop_iterate_shared_t cifs_iterate_shared = NULL;
static int smbcheck_iterate_shared(struct file* file, struct dir_context* ctx)
{
    int res;
    fop_iterate_shared_t lf_iterate = cifs_iterate_shared;

    if (!lf_iterate)
        return -ERESTARTSYS;

    res = lf_iterate(file, ctx);

    dir_walk_replace_file_ops(file->f_dentry);

    return res;
}
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 11, 0)
typedef int (*fop_readdir_t)(struct file* file, struct dir_context* ctx);
static volatile fop_readdir_t cifs_readdir = NULL;
#define LF_READDIR() lf_readdir(file, ctx)
static int smbcheck_readdir(struct file* file, struct dir_context* ctx)
#else
typedef int (*fop_readdir_t)(struct file* file, void* direntry, filldir_t filldir);
static volatile fop_readdir_t cifs_readdir = NULL;
#define LF_READDIR() lf_readdir(file, direntry, filldir)
static int smbcheck_readdir(struct file* file, void* direntry, filldir_t filldir)
#endif
{
    int res;
    fop_readdir_t lf_readdir = cifs_readdir;

    if (!lf_readdir)
        return -ERESTARTSYS;

    res = LF_READDIR();

#if defined(CONFIG_X86_32 )
    if (klflt_check_trusted(current))
        return res;
#endif

    dir_walk_replace_file_ops(file->f_dentry);

    return res;
}

static void replace_dir_ops_nolock(struct inode* di)
{
    int protected_iop = 0;
    int protected_fop = 0;
    int error = 0;

    int iop_lookup = iop_lookup = di->i_op->lookup &&
        smbcheck_lookup != di->i_op->lookup;
    int iop_rename = di->i_op->rename &&
        smbcheck_rename != di->i_op->rename;
    int iop_unlink = di->i_op->unlink &&
        smbcheck_unlink != di->i_op->unlink;

    int iop_atomic_open = false;
    int ifop_readdir = false;
    int ifop_iterate = false;
    int ifop_iterate_shared = false;

#if !(LINUX_VERSION_CODE < KERNEL_VERSION(3, 6, 0))
    iop_atomic_open = di->i_op->atomic_open &&
        smbcheck_atomic_open != di->i_op->atomic_open;
#endif
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 11, 0)
    ifop_readdir = di->i_fop->readdir &&
        smbcheck_readdir != di->i_fop->readdir;
#else
    ifop_iterate = di->i_fop->iterate &&
        smbcheck_readdir != di->i_fop->iterate;
#if !(LINUX_VERSION_CODE < KERNEL_VERSION(4, 7, 0))
    ifop_iterate_shared = di->i_fop->iterate_shared &&
        smbcheck_iterate_shared != di->i_fop->iterate_shared)
#endif
#endif

    if (iop_atomic_open || iop_lookup || iop_rename || iop_unlink ||
        ifop_readdir || ifop_iterate || ifop_iterate_shared)
    {
        protected_iop = WRITE_ENABLE(di->i_op, &error);
        if (error)
        {
            printk(KERN_ERR "klflt: failed to replace cifs dir inode operations\n");
            return;
        }

        protected_fop = WRITE_ENABLE(di->i_fop, &error);
        if (error)
        {
            printk(KERN_ERR "klflt: failed to replace cifs dir file operations\n");
            if (protected_iop)
                WRITE_DISABLE(di->i_op, &error);
            return;
        }
    }


#if !(LINUX_VERSION_CODE < KERNEL_VERSION(3, 6, 0))
    if (iop_atomic_open)
    {
        CIFS_DBGPRN("replace dir iop cifs_atomic_open\n");
        if (cifs_atomic_open && cifs_atomic_open != di->i_op->atomic_open)
            printk(KERN_ERR "klflt: different cifs_atomic_open functions\n");
        cifs_atomic_open = di->i_op->atomic_open;
        call_replace_nolock((pfunc_t*)&di->i_op->atomic_open,
                            (pfunc_t)smbcheck_atomic_open);
    }
#endif
    if (iop_lookup)
    {
        CIFS_DBGPRN("replace dir iop cifs_lookup\n");
        if (cifs_lookup && cifs_lookup != di->i_op->lookup)
            printk(KERN_ERR "klflt: different cifs_lookup functions\n");
        cifs_lookup = di->i_op->lookup;
        call_replace_nolock((pfunc_t*)&di->i_op->lookup, (pfunc_t)smbcheck_lookup);
    }
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 11, 0)
    if (ifop_readdir)
    {
        CIFS_DBGPRN("replace dir fop cifs_readdir\n");
        if (cifs_readdir && cifs_readdir != di->i_fop->readdir)
            printk(KERN_ERR "klflt: different cifs_readdir functions\n");
        cifs_readdir = di->i_fop->readdir;
        call_replace_nolock((pfunc_t*)&di->i_fop->readdir,
                            (pfunc_t)smbcheck_readdir);
    }
#else
    if (ifop_iterate)
    {
        CIFS_DBGPRN("replace dir fop cifs_iterate\n");
        if (cifs_readdir && cifs_readdir != di->i_fop->iterate)
            printk(KERN_ERR "klflt: different cifs_iterate functions\n");
        cifs_readdir = di->i_fop->iterate;
        call_replace_nolock((pfunc_t*)&di->i_fop->iterate,
                            (pfunc_t)smbcheck_readdir);
    }
#if !(LINUX_VERSION_CODE < KERNEL_VERSION(4, 7, 0))
    if (ifop_iterate_shared)
    {
        CIFS_DBGPRN("replace dir fop cifs_iterate_shared\n");
        if (cifs_iterate_shared &&
                cifs_iterate_shared != di->i_fop->iterate_shared)
            printk(KERN_ERR "klflt: different cifs_iterate functions\n");
        cifs_iterate_shared = di->i_fop->iterate_shared;
        call_replace_nolock((pfunc_t*)&di->i_fop->iterate_shared,
                            (pfunc_t)smbcheck_iterate_shared);
    }

#endif /* 4.7.1 */
#endif
    if (iop_rename)
    {
        CIFS_DBGPRN("replace dir iop cifs_rename\n");
        if (cifs_rename && cifs_rename != di->i_op->rename)
            printk(KERN_ERR "klflt: different cifs_rename functions\n");
        cifs_rename = di->i_op->rename;
        call_replace_nolock((pfunc_t*)&di->i_op->rename, (pfunc_t)smbcheck_rename);
    }
    if (iop_unlink)
    {
        CIFS_DBGPRN("replace dir iop cifs_unlink\n");
        if (cifs_unlink && cifs_unlink != di->i_op->unlink)
            printk(KERN_ERR "klflt: different cifs_unlink functions\n");
        cifs_unlink = di->i_op->unlink;
        call_replace_nolock((pfunc_t*)&di->i_op->unlink, (pfunc_t)smbcheck_unlink);
    }

    if (protected_fop)
        WRITE_DISABLE(di->i_fop, &error);
    if (protected_iop)
        WRITE_DISABLE(di->i_op, &error);
}

void cifs_calls_replace(struct dentry* d_root)
{
    struct dentry* de = dget(d_root);
    struct inode* di;

    if (!de || IS_ERR(de))
       return;

    di = igrab(d_root->d_inode);

    if (!di || IS_ERR(di))
    {
       dput(de);
       return;
    }

    rfs_mutex_lock(&calls_restore_mutex);

    if (!cifs_module)
    {
        cifs_module = di->i_sb->s_type->owner;
        if (!(cifs_module && try_module_get(cifs_module)))
        {
            printk(KERN_ERR "klflt: can't get cifs module\n");
            cifs_module = NULL;
            iput(di);
            dput(de);
            return;
        }
    }


    replace_dir_ops_nolock(di);

    dir_walk_replace_file_ops_recursive_nolock(d_root);

    rfs_mutex_unlock(&calls_restore_mutex);

    iput(di);
    dput(de);
}

void cifs_calls_restore(void)
{
    int i;

    rfs_mutex_lock(&calls_restore_mutex);
    for (i = 0; i < calls_restore_count; ++i)
    {
        int protected, error = 0;

    CIFS_DBGPRN("Restoring %p -> %p\n", calls_restore_array[i].loc,
        calls_restore_array[i].old);

    protected
        = WRITE_ENABLE(calls_restore_array[i].loc, &error);
        if (error)
            continue;
        *calls_restore_array[i].loc = calls_restore_array[i].old;
        if (protected)
            WRITE_DISABLE(calls_restore_array[i].loc, &error);
    }
    calls_restore_count = 0;
    if (cifs_module)
    {
        module_put(cifs_module);
        cifs_module = NULL;
    }
    cifs_open    = NULL;
    cifs_close   = NULL;
    cifs_lookup  = NULL;
    cifs_rename  = NULL;
    cifs_unlink  = NULL;
    cifs_readdir = NULL;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 6, 0)
    cifs_atomic_open = NULL;
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,7,0)
    cifs_iterate_shared = NULL;
#endif
    rfs_mutex_unlock(&calls_restore_mutex);
}

#else /* CIFS is not compiled as a module so below are empty stubs */
#ifdef __CONFIG_CIFS_KERNEL
#warning                                                                            \
    "Mounted samba shares can not be checked since CIFS is built into the kernel."
#endif
void cifs_calls_replace(struct dentry* d_root)
{
}
void cifs_calls_restore(void)
{
}

#endif

int klflt_smb_init(struct klflt_mounts_ops* ops)
{
    pr_debug("%s:", __func__);

    ops->cifs_calls_replace = cifs_calls_replace;
    ops->cifs_calls_restore = cifs_calls_restore;

    return 0;
}

void klflt_smb_destroy(void)
{
    pr_debug("%s\n", __func__);
    cifs_calls_restore();
}