#ifndef __KLFLT_INTERFACE_V2_PROTOCOL_H
#define __KLFLT_INTERFACE_V2_PROTOCOL_H

#include <linux/list.h>
#include <linux/types.h>
#include <linux/time.h>
#include <linux/wait.h>

#pragma pack(1)

enum KlRequestType
{
    CHECK_FILE       = 1, // both MONITOR and SAMBA
    CHECK_FILE_RES   = 2, // both MONITOR and SAMBA
    NOTIFY_FILE      = 3, // both MONITOR and SAMBA
    MONITOR_SHUTDOWN = 4, // only MONITOR
    SAMBA_CONNECT    = 5, // only SAMBA
    CHECK_SIGN       = 6
};

enum KlFileNotifyType
{
    FILE_UNLINK_OPER,
    FILE_RENAME_OPER,
    FILE_NAME_TOO_LONG
};

enum KlFileAccessType
{
    FILE_ACCESS_ACCEPT,
    FILE_ACCESS_DENY,
    FILE_ACCESS_NO_CHECK
};

#define FS_PROTOCOL_VERSION 3

enum KlFileOpType
{
    FILE_OPEN_OPER,
    FILE_CLOSE_OPER,
    FILE_EXEC_OPER
};

struct klflt_protocol_header
{
    u_int8_t    request;                 // common_request_types
    u_int8_t    version;                 // MONITOR/SAMBA_INTERFACE_VERSION
    u_int32_t   data_size;
};

struct klflt_response
{
    struct klflt_protocol_header header;
    u_int8_t result;
    u_int16_t queue_id;
};

typedef struct klflt_response klflt_response_t;

typedef struct klflt_interface_v2_event_metadata klflt_v2_event_t;

struct klflt_protocol_data
{
    struct klflt_protocol_header header;
    char data[0];
};

struct klflt_packed_buffer
{
    char* data;
    size_t length;
};

struct klflt_check_event
{
    struct klflt_protocol_header header;
    u_int32_t                    uid;       // effective user ID
    u_int32_t                    gid;       // effective group ID
    u_int32_t                    pid;       // process ID
    int32_t                      flags;     // flags like O_RDONLY etc
    u_int8_t                     file_op_type; // enum file_oper_type
    u_int16_t                    queue_id;  // used only in MONITOR, but probably will be used in SAMBA
                                            // in the future
    // size of dev_t and ino_t is platform specific
    u_int64_t                    dev;
    u_int64_t                    ino;
    int64_t                      mtime;
    int64_t                      size;
    u_int32_t                    owner_uid;
    u_int32_t                    file_mode;  // st_mode from struct stat
    int64_t                      f_type;     // file system type, it's for Linux
    u_int8_t                     fstypelen;  // it is zero on Linux
    char                         strings[0]; // fstypename,filename
};

struct klflt_notify_event
{
    struct klflt_protocol_header header;
    u_int8_t file_type; // enum file_notify_type
    u_int64_t dev;
    u_int64_t ino;
    char name[0]; // filename
};

#pragma pack()

struct klflt_request_metadata
{
    // common fields for all (CHECK_SIGN and CHECK_FILE) requests
    struct list_head list;
    struct kref refcnt;
    u_int32_t euid; // effective user ID
    u_int32_t egid; // effective group ID
    u_int16_t queue_id; // used only in MONITOR, but probably will be used in SAMBA
                        // in the future
    u_int8_t request;
    // additional fields only for CHECK_FILE requests
    u_int8_t file_op_type; // enum file_oper_type
    u_int32_t pid; // process ID
    int32_t flags; // flags like O_RDONLY etc
    struct vfsmount* vfsmnt; // file root
    struct dentry* parent; // file parent dentry
    char const* name; // file name
    dev_t dev;
    ino_t ino;
    time_t mtime;
    int64_t size;
    u_int32_t owner_uid;
    u_int32_t file_mode;
    int64_t f_type; // file system type
};

struct klflt_proto_buffer
{
    char* data;
    char* start;
    u_int32_t length;
    u_int32_t capacity;
};

struct klflt_proto_buffer_entry
{
    char* begin;
    char* end;
};

struct klflt_connection
{
    struct klflt_proto_buffer send_buff;
    struct klflt_proto_buffer recv_buff;
    struct semaphore send_buff_mtx;
    struct semaphore recv_buff_mtx;
    wait_queue_head_t request_waitq;
};

static inline void klflt_fill_event_header(
    struct klflt_protocol_header* header, u_int8_t ver,
    u_int32_t data_size, u_int8_t request)
{
    memset(header, 0, sizeof(*header));
    header->request   = request;
    header->version   = ver;
    header->data_size = data_size;
}

static inline struct klflt_check_event* klflt_pack_check_event(
    u_int8_t ver, uid_t euid, gid_t egid, pid_t pid, u_short queue_id,
    const char* filename, enum KlFileOpType file_op_type, int flags, dev_t dev,
    ino_t ino, time_t mtime, int64_t size, uid_t owner_uid, u_int32_t file_mode,
    int64_t f_type, const char* fstypename)
{
    size_t fstypelen = 0;
    size_t strsize;
    size_t fnamelen = strlen(filename);
    struct klflt_check_event* event;

    if (fstypename)
    {
        fstypelen = strlen(fstypename);
        strsize   = fstypelen + 1 + fnamelen + 1;
    }
    else
    {
        strsize = fnamelen + 1;
    }

    event = kmalloc(sizeof(*event) + strsize, GFP_KERNEL);
    if (!event)
        return NULL;
    klflt_fill_event_header(&event->header, ver,
        sizeof(*event) - sizeof(struct klflt_protocol_header) + strsize,
        CHECK_FILE);
    event->pid          = pid;
    event->uid          = euid;
    event->gid          = egid;
    event->flags        = flags;
    event->queue_id     = queue_id;
    event->file_op_type = file_op_type;
    event->dev          = dev;
    event->ino          = ino;
    event->mtime        = mtime;
    event->size         = size;
    event->owner_uid    = owner_uid;
    event->file_mode    = file_mode;
    event->f_type       = f_type;
    event->fstypelen = fstypelen;
    if (fstypename)
    {
        memcpy((char*)event->strings, fstypename, fstypelen + 1);
        memcpy((char*)event->strings + fstypelen + 1, filename, fnamelen + 1);
    }
    else
        memcpy((char*)event->strings, filename, fnamelen + 1);

    return event;
}

static inline void dump_proto_struct(const char *name,
    struct klflt_proto_buffer* buf)
{
    pr_debug("%s: data:%p, start:%p, len:%d, cap:%d", name,
        buf->data, buf->start, buf->length, buf->capacity);
}

static inline void dump_response(const struct klflt_response* response)
{
    pr_debug("%s: req:%d, ver: %d, queue_id=%d, response=%d\n", __func__,
        response->header.request, response->header.version,
        response->queue_id, response->result);
}

static inline void dump_packet(
    const char* name,
    const struct klflt_proto_buffer_entry* el)
{
    char *c;
    printk("%s: ", name);
    for (c = el->begin; c < el->end; ++c)
        printk("%#x ", *c);
    printk("\n");
}

static inline int klflt_fill_check_event(
    struct klflt_packed_buffer* buf, int32_t ver, uid_t uid,
    gid_t gid, pid_t pid, u_short queue_id,
    const char* filename,
    enum KlFileOpType file_op_type, int flags,
    dev_t dev, ino_t ino, time_t mtime, int64_t size,
    uid_t owner_uid, u_int32_t file_mode,
    int64_t f_type, const char* fstypename)
{
    struct klflt_check_event* packet = klflt_pack_check_event(
        (u_int8_t)ver, uid, gid, pid, queue_id, filename, file_op_type, flags, dev,
        ino, mtime, size, owner_uid, file_mode, f_type, fstypename);

    if (!packet)
    {
        pr_err("%s: Failed to form a packet\n", __func__);
        return 0;
    }

    buf->data   = (char*)packet;
    buf->length = packet->header.data_size + sizeof(packet->header);

    pr_debug("%s: filename=%s, packet length=%ld\n", __func__, filename, buf->length);

    return buf->length;
}

static inline int klflt_fill_notify_event(
    struct klflt_packed_buffer* buf, int32_t ver, u_int8_t file_notify_type,
    dev_t dev, ino_t ino, char* filename)
{
    struct klflt_notify_event* event;
    size_t fnamelen = strlen(filename);

    event = kmalloc(sizeof(*event) + fnamelen + 1, GFP_KERNEL);
    if (!event)
    {
        pr_err("%s: Failed to allocate klflt_notify_event\n", __func__);
        return 0;
    }

    klflt_fill_event_header(&event->header, ver,
        sizeof(*event) - sizeof(struct klflt_protocol_header) + fnamelen + 1,
        NOTIFY_FILE);

    event->file_type = file_notify_type;
    event->dev = dev;
    event->ino = ino;
    memcpy((char*)event->name, filename, fnamelen + 1);

    buf->data   = (char*)event;
    buf->length = event->header.data_size + sizeof(event->header);

    pr_debug("%s: filename=%s, packet length=%ld\n", __func__, filename, buf->length);

    return buf->length;
}

static inline int klflt_proto_buffer_get_free_size(struct klflt_proto_buffer* buf)
{
    if (buf->length && buf->start != buf->data)
    {
        memmove(buf->data, buf->start, buf->length);
        buf->start = buf->data;
    }
    return buf->capacity - buf->length;
}

static inline int klflt_proto_buffer_check_size(
    struct klflt_proto_buffer* buf, u_int32_t need_bytes)
{
    size_t capacity;
    char* tmp;

    if (buf->start + buf->length + need_bytes <= buf->data + buf->capacity)
        return 1;

    if (!buf->length && need_bytes <= buf->capacity)
    {
        buf->start = buf->data;
        return 1;
    }

    if (buf->length + need_bytes <= buf->capacity)
    {
        memmove(buf->data, buf->start, buf->length);
        buf->start = buf->data;
        return 1;
    }

    capacity = buf->capacity;
    if (!capacity)
        capacity = 512;

    do {
        capacity *= 2;
    }
    while (need_bytes > (capacity - buf->length));

    tmp = kmalloc(capacity, GFP_KERNEL);
    if (!tmp)
        return 0;

    if (buf->data) {
        memcpy(tmp, buf->start, buf->length);
        kfree(buf->data);
    }
    buf->data = tmp;
    buf->start = buf->data;
    buf->capacity = capacity;

    return 1;
}

static inline int klflt_proto_buffer_adjust_size(
    struct klflt_proto_buffer* buf, u_int32_t need_bytes)
{
    size_t capacity;
    char* tmp;

    if (klflt_proto_buffer_check_size(buf, need_bytes))
        return 1;

    capacity = buf->capacity;
    if (!capacity)
        capacity = 512;
    do
    {
        capacity *= 2;
    } while (need_bytes > (capacity - buf->length));

    tmp = kmalloc(capacity, GFP_KERNEL);
    if (!tmp)
        return 0;

    if (buf->data)
    {
        memcpy(tmp, buf->start, buf->length);
        kfree(buf->data);
    }
    buf->data = tmp;
    buf->start = buf->data;
    buf->capacity = capacity;

    return 1;
}

static inline u_int32_t klflt_proto_buffer_get_length(
    struct klflt_proto_buffer* buf)
{
    u_int32_t* ptr = (u_int32_t*)buf->start;
    return ntohl(*ptr);
}

static inline int klflt_is_proto_packet_ready(struct klflt_proto_buffer* buf)
{
    u_int32_t len;

    if (buf->length < sizeof(u_int32_t))
        return 0;

    len = klflt_proto_buffer_get_length(buf) + sizeof(u_int32_t);
    if (buf->length < len)
        return 0;
    return len;
}

static inline int klflt_proto_get_next_packet(
    struct klflt_proto_buffer* buf,
    struct klflt_proto_buffer_entry* el)
{
    u_int32_t len = klflt_is_proto_packet_ready(buf);
    if (!len)
        return 0;

    el->begin = buf->start + sizeof(u_int32_t);
    el->end = buf->start + len;
    buf->start += len;
    buf->length -= len;

    return len;
}

static inline void klflt_packed_buffer_destroy(struct klflt_packed_buffer* buf)
{
    kfree(buf->data);
    buf->data = NULL;
    buf->length = 0;
}

#endif // __KLFLT_INTERFACE_V2_PROTOCOL_H