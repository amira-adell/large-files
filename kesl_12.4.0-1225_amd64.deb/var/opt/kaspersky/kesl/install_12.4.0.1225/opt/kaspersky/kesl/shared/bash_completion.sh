
__kesl_options_present ()
{
    local opts=("$@")
    for opt in "${opts[@]}"; do
        if [[ "$COMP_LINE " =~ " $opt " ]]; then
            return 0;
        fi
    done
    return 1
}

__kesl_add_uniq_options ()
{
    for opt in "$@"; do
        if [[ " ${opts[@]} " =~ " $opt " ]]; then
            continue
        fi
        if [[ "$cur" = "" || "${opt#"$cur"}" != "$opt" ]]; then
            if [[ ! "$COMP_LINE " =~ " $opt " || $cur = $opt  ]]; then
                if [[ $COMP_CWORD -eq 1 || ! "$opt" =~ ^-[A-Z]$ ]]; then
                    opts+=( "$opt" )
                fi
            fi
        fi
    done
    return 0
}

_kesl_control ()
{
    local cur prev first
    COMPREPLY=()
    cur=${COMP_WORDS[$COMP_CWORD]}
    first=${COMP_WORDS[1]}

    local -a opts=()
    if [[ $COMP_CWORD -le 2 ]]; then
        opts+=( --help )
    fi

    if [[ $COMP_CWORD -gt 1 ]];then
        prev=${COMP_WORDS[$((COMP_CWORD-1))]}

        if [[ $prev =~ (--(create-task|add-certificate|(remove|query)-kataedr-(server|client)-certificate|access-duration)) ]]; then
            return 0
        fi

        if [[ $prev = "--set-app-settings" ]]; then
            COMPREPLY=($( compgen -W "$( kesl-control --get-app-settings|sed -e 's/=.*/=/' )" -- $cur ))
            return 0
        fi

        if [[ $prev = "--allow-hosts" ]]; then
            COMPREPLY=($( compgen -W "$( kesl-control --get-blocked-hosts|grep -E 'Host *:'|sed -e 's/.*Host *: *//' )" -- $cur ))
            return 0
        fi

        if [[ $prev = "--get-prevention-state" ]]; then
            COMPREPLY=($( compgen -W "--edro --kata" -- $cur ))
            return 0
        fi

        if [[ $prev =~ (--((start|stop|suspend|resume|delete)-task|get-task-state|(get|set)-(settings|schedule))) ]]; then
            COMPREPLY=($( compgen -W "$( kesl-control --get-task-list|grep '^Name: '|sed -e 's/^Name: //' )" -- $cur ))
            return 0
        fi

        if [[ $prev =~ (--(file|add-(active|reserve)-key|load-mdr-blob|scan-file|add-(kataedr|katandr|sandbox|kuma)-(server|client)-certificate|path|excludes|scope|hint)) ]];then
            return 0
        fi

        if [[ $prev = "--server-type" ]]; then
            COMPREPLY=($( compgen -W "response telemetry" $cur ))
            return 0
        fi

        if [[ $prev =~ (--(add|del)-zone) ]]; then
            COMPREPLY=($( compgen -W "Public Local Trusted" $cur ))
            return 0
        fi

        if [[ $first = "-N" && $prev = "--query" ]]; then
            COMPREPLY=($( compgen -W "auto kl user" $cur ))
            return 0
        fi

        if [[ $prev =~ (--(grant|revoke)-role) ]]; then
            COMPREPLY=($( compgen -W "admin user audit" $cur ))
            return 0
        fi

        if [[ $prev =~ (--remove-(active|reserve)-key) ]]; then
            COMPREPLY=($( compgen -W "--mdr --edr-optimum --kuma --edr-kata" -- $cur ))
            return 0
        fi

        if __kesl_options_present --grant-role || __kesl_options_present --revoke-role ; then
            COMPREPLY=($( compgen -u $cur ))
            return 0
        fi

        if __kesl_options_present --add-rule ; then
            if [[ $prev = "--action" ]]; then
                COMPREPLY=($(compgen -W "allow block" $cur))
                return 0
            fi
            if [[ $prev = "--protocol" ]]; then
                COMPREPLY=($(compgen -W "any tcp udp icmp icmpv6 igmp gre" $cur))
                return 0
            fi
            if [[ $prev = "--direction" ]]; then
                COMPREPLY=($(compgen -W "in out inout inpacket outpacket inoutpacket" $cur))
                return 0
            fi
            if [[ $prev = "--remote" ]]; then
                COMPREPLY=($(compgen -W "any trusted local public" $cur))
                return 0
            fi
            if [[ $prev = "--local" ]]; then
                COMPREPLY=($(compgen -W "any" $cur))
                return 0
            fi
            if [[ $prev =~ (--(name|at)) ]]; then
                return 0
            fi
        fi

        if __kesl_options_present --del-rule --move-rule ; then
            if __kesl_options_present --index ; then
                return 0
            fi
            if [[ $prev = "--name" ]]; then
                local IFS=$'\n'
                local WORD_LIST=($( kesl-control --get-settings Firewall_Management|grep '^Name='|sed -e 's/^Name=//' ))
                local CANDIDATES=($(compgen -W "${WORD_LIST[*]}" -- "$cur"))
                if [[ ${#CANDIDATES[*]} -eq 0 ]]; then
                    COMPREPLY=()
                else
                    COMPREPLY=($(printf '%q\n' "${CANDIDATES[@]}"))
                fi
                return 0
            fi
            if [[ $prev = "--at" ]]; then
                return 0
            fi
            __kesl_add_uniq_options --name --index
            __kesl_options_present --move-rule && __kesl_add_uniq_options --at
        fi

        if __kesl_options_present --add-zone --del-zone ; then
            if __kesl_options_present --address --index ; then
                return 0
            fi
            __kesl_add_uniq_options --address
            __kesl_options_present --del-zone && __kesl_add_uniq_options --index
        fi

        if __kesl_options_present --create-task ; then
            if [[ $prev = "--type" ]]; then
                COMPREPLY=($(compgen -W "ODS Update Rollback" $cur))
                return 0
            fi
        fi

        if __kesl_options_present --set-settings ; then
            opts+=( --add-path --del-path --add-exclusion --del-exclusion )
        fi

        if __kesl_options_present --scan-file ; then
            if [[ $prev = "--action" ]]; then
                COMPREPLY=($(compgen -W "DisinfectDeleteIfNotPossible DisinfectInformIfNotPossible Inform" $cur))
                return 0
            fi
        fi

        if __kesl_options_present --scan-ioc ; then
            if [[ " --process --arp-entry --ports --system " =~ " $prev " ]]; then
                COMPREPLY=($(compgen -W "on off" $cur))
                return 0
            fi
            if [[ $prev = "--drives" ]]; then
                COMPREPLY=($(compgen -W "all system critical custom" $cur))
                return 0
            fi
            if [[ $prev = "--action" ]]; then
                COMPREPLY=($(compgen -W "QuarantineFile ScanCriticalAreas IsolateHost Skip" $cur))
                return 0
            fi
        fi

        if __kesl_options_present --trusted-devices ; then
            if [[ $prev = "--delete" ]]; then
                local IFS=$'\n'
                local WORD_LIST=($( kesl-control --trusted-devices --list|grep '^DeviceId='|sed -e 's/^DeviceId=//' ))
                local CANDIDATES=($(compgen -W "${WORD_LIST[*]}" -- "$cur"))
                if [[ ${#CANDIDATES[*]} -eq 0 ]]; then
                    COMPREPLY=()
                else
                    COMPREPLY=($(printf '%q\n' "${CANDIDATES[@]}"))
                fi
                return 0
            fi
            if [[ $prev = "--add" ]]; then
                local IFS=$'\n'
                local WORD_LIST=($( kesl-control --get-device-list|awk '/^ID:/{print $2}' ))
                WORD_LIST+=("--file")
                local CANDIDATES=($(compgen -W "${WORD_LIST[*]}" -- "$cur"))
                if [[ ${#CANDIDATES[*]} -eq 0 ]]; then
                    COMPREPLY=()
                else
                    COMPREPLY=($(printf '%q\n' "${CANDIDATES[@]}"))
                fi
                return 0
            fi
        fi

        if __kesl_options_present --add-bypass-endpoints --remove-bypass-endpoints ; then
            if [[ $prev = "--direction" ]]; then
                COMPREPLY=($(compgen -W "in out" $cur))
                return 0
            fi
            if [[ $prev =~ (--(remote-ip|dst-port)) ]]; then
                return 0
            fi
        fi

    fi

    local -a options_in_command_line=()
    for (( i=1; i<${#COMP_WORDS[*]}; i++ )); do
        if [[ $i != $COMP_CWORD ]]; then
            opt=${COMP_WORDS[$i]}
            if [[ ${opt:0:1} == "-" ]]; then
                options_in_command_line+=( "$opt" )
            fi
        fi
    done
    while IFS= read -r valid_combination; do
        read -a valid_combination_options <<< "$valid_combination"
        first_argument_is_optional=0
        if [[ "${valid_combination_options[0]}" =~ ^\[(-[A-Z])\]$ ]]; then
            first_argument_is_optional=1
            valid_combination_options[0]="${BASH_REMATCH[1]}"
        else
            if [[ "$first" != "${valid_combination_options[0]}" ]]; then
                continue
            fi
        fi

        if [[ $COMP_CWORD -eq 1 ]]; then
            __kesl_add_uniq_options "${valid_combination_options[0]}"
            if [[ $first_argument_is_optional -eq 1 ]]; then
                __kesl_add_uniq_options "${valid_combination_options[1]}"
            fi
        elif [[ $COMP_CWORD -eq 2 && "${COMP_WORDS[1]}" = "${valid_combination_options[0]}" ]]; then
            __kesl_add_uniq_options "${valid_combination_options[1]}"
        else
            local all_command_line_options_present=1
            for opt in "${options_in_command_line[@]}"; do
                if [[ ! " ${valid_combination_options[@]} " =~ " $opt " ]]; then
                    all_command_line_options_present=0
                    break
                fi
            done
            if [[ $all_command_line_options_present -eq 1 ]]; then
                __kesl_add_uniq_options "${valid_combination_options[@]:1}"
            fi
        fi
    done << EOF
[-A] --get-app-list --json
[-A] --get-categories --json
[-A] --set-categories --file
-B --mass-remove --query
-B --query -n --json
-B --restore --file
-Q --mass-remove --query
-Q --query -n --json
-Q --restore --file
[-Q] --put --md5 --sha256 --save-original-file
[-D] --get-device-list --json
[-D] --trusted-devices --file --merge
[-D] --trusted-devices --file --add
[-D] --trusted-devices --file --replace
[-D] --trusted-devices --add
[-D] --trusted-devices --delete
[-D] --trusted-devices --list
[-D] --request-temporary-device-access --device-id --access-duration --path
[-D] --upload-temporary-device-access-key --path
-E --query -n --db --file --json --reverse
[-F] --add-rule --name --action --protocol --direction --remote --local --at
[-F] --del-rule
[-F] --move-rule
[-F] --add-zone
[-F] --del-zone
-F --query
[-H] --get-blocked-hosts
[-H] --allow-hosts
[-N] --list-certificates
[-N] --remove-certificate
[-N] --add-certificate
[-L] --add-active-key
[-L] --add-reserve-key
[-L] --remove-active-key
[-L] --remove-reserve-key
-L --query --json
[-L] --load-mdr-blob
[-L] --remove-mdr-blob
-N --query
-N --clear-web-auto-excluded
[-J] --export-metrics
[-T] --create-task --type --file
[-S] --app-info --json
[-S] --omsinfo --file
[-T] --delete-task
[-T] --export-settings --file --file --json
[-T] --get-app-settings --json
[-C] --get-container-settings --json
[-N] --get-net-settings --json
[-N] --add-bypass-endpoints --direction --remote-ip --dst-port
[-N] --list-bypass-endpoints
[-N] --remove-bypass-endpoints --direction --remote-ip --dst-port
[-T] --get-task-list --json
[-T] --get-task-state --json
[-T] --get-settings --file --json
[-T] --import-settings --file --json
[-T] --update-application
[-T] --set-settings --file --add-path --del-path --add-exclusion --del-exclusion --set-to-default --json
[-T] --set-app-settings --file --json
[-C] --set-container-settings --file --json
[-N] --set-net-settings --file --json
[-S] --get-statistic --files --processes --mountpoints
[-T] --start-task -W --progress
[-T] --stop-task -W
[-T] --suspend-task
[-T] --resume-task
-W --query
[-T] --get-schedule --file --json
[-T] --set-schedule  --file
[-T] --scan-container
[-T] --scan-file --action
[-T] --scan-ioc --path --process --hint --arp-entry --ports --system --drives --excludes --scope --action
[-U] --get-user-list
[-U] --grant-role
[-U] --revoke-role
[-R] --add-kataedr-server-certificate --server-type
[-R] --remove-kataedr-server-certificate --server-type
[-R] --query-kataedr-server-certificate --server-type
[-R] --add-kataedr-client-certificate --server-type
[-R] --remove-kataedr-client-certificate --server-type
[-R] --query-kataedr-client-certificate --server-type
[-R] --add-katandr-server-certificate
[-R] --remove-katandr-server-certificate
[-R] --query-katandr-server-certificate
[-R] --add-katandr-client-certificate
[-R] --remove-katandr-client-certificate
[-R] --query-katandr-client-certificate
[-X] --add-sandbox-client-certificate
[-X] --remove-sandbox-client-certificate
[-X] --query-sandbox-client-certificate
[-X] --add-sandbox-server-certificate
[-X] --remove-sandbox-server-certificate
[-X] --query-sandbox-server-certificate
[-X] --sandbox
[-M] --add-kuma-client-certificate
[-M] --remove-kuma-client-certificate
[-M] --query-kuma-client-certificate
[-M] --add-kuma-server-certificate
[-M] --remove-kuma-server-certificate
[-M] --query-kuma-server-certificate
[-R] --isolation-stat
[-R] --isolation-off
[-V] --svm-info
[-V] --viis-info
[-V] --ksvla-info
[-T] --get-prevention-state
EOF

    COMPREPLY=($(compgen -W "${opts[*]}" -- $cur))

    return 0
}

complete -F _kesl_control -o default kesl-control

