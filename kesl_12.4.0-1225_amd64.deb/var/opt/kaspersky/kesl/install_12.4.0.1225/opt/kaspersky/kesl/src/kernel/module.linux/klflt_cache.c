
/*
 * This source file is a part of a Kaspersky Antivirus Monitor.
 * Copyright (C) Kaspersky Lab, 1997-2010
 * See License.txt for details
 *
 */

#include "klflt.h"

#include <linux/list.h>
#include <linux/spinlock_types.h>
#include <linux/slab.h>

struct cache_entry
{
    struct list_head lru_list;
    unsigned int lru_index;
    struct klflt_file_info file;
};

static rwlock_t cache_lock;

static struct cache_entry** hash_tbl;
static struct cache_entry* cache_entries;
static int hash_tbl_sz_mask = 0;
static int max_cache_files = -1;
static LIST_HEAD(lru_list);
#define HASH_SCALE 4
#define HASH_FIND_DEPTH 5

static void* insistent_alloc(size_t size, int max_retries)
{
    int retry = 0;

    do
    {
        void* ptr = kmalloc(size, GFP_KERNEL);
        if (ptr)
            return ptr;
    } while (!max_retries || (retry++ < max_retries));

    return NULL;
}

static void klflt_cache_stop_nolock(void)
{
    if (max_cache_files == -1)
        return;

    max_cache_files = -1;
    kfree(cache_entries);
    cache_entries = NULL;
    kfree(hash_tbl);
    hash_tbl         = NULL;
    hash_tbl_sz_mask = 0;
}

static int hash_func(const struct klflt_file_info* file)
{
    int tmp = file->dev + file->ino;
    tmp ^= tmp << 7;
    tmp ^= tmp >> 5;
    return (tmp & hash_tbl_sz_mask);
}

/* Requirement: cache_lock locked */
static void move_to_lru_list_tail(struct cache_entry* cent)
{
    cent->lru_index =
        list_entry(lru_list.prev, struct cache_entry, lru_list)->lru_index + 1;
    list_del(&cent->lru_list);
    list_add_tail(&cent->lru_list, &lru_list);
}

/* Requirement: cache_lock locked */
static int hash_find_index_to_replace(const struct klflt_file_info* file)
{
    int hind = hash_func(file), i = 0, min_lru_hind, hind_val;
    unsigned int head_lrui, min_lrui = 0;

    if (!hash_tbl[hind])
        goto l_empty;
    if (klflt_file_info_equal(&hash_tbl[hind]->file, file))
        goto l_value_exist;

    head_lrui    = list_entry(lru_list.next, struct cache_entry, lru_list)->lru_index;
    min_lru_hind = hind;
    min_lrui     = hash_tbl[hind]->lru_index - head_lrui;

    for (++i; i < HASH_FIND_DEPTH; ++i)
    {
        int lrui;
        ++hind;
        hind &= hash_tbl_sz_mask;
        if (!hash_tbl[hind])
            goto l_empty;
        if (klflt_file_info_equal(&hash_tbl[hind]->file, file))
            goto l_value_exist;
        lrui = hash_tbl[hind]->lru_index;
        lrui -= head_lrui;
        if (lrui < min_lrui)
        {
            min_lrui     = lrui;
            min_lru_hind = hind;
        }
    }

    return min_lru_hind;

l_empty:
    for (++i, hind_val = hind; i < HASH_FIND_DEPTH; ++i)
    {
        ++hind_val;
        hind_val &= hash_tbl_sz_mask;
        if (hash_tbl[hind_val] && klflt_file_info_equal(&hash_tbl[hind_val]->file, file))
        {
            /* move the value closer to its hash index */
            hash_tbl[hind]     = hash_tbl[hind_val];
            hash_tbl[hind_val] = NULL;
            return -1;
        }
    }

    return hind;

l_value_exist:
    move_to_lru_list_tail(hash_tbl[hind]);

    return -1;
}
/* Requirement: cache_lock locked */
static int hash_find_index(const struct klflt_file_info* file)
{
    int hind, iend;

    for (hind = hash_func(file), iend = hind + HASH_FIND_DEPTH; hind < iend; ++hind)
    {
        int hind_m = hind & hash_tbl_sz_mask;
        if (hash_tbl[hind_m] && klflt_file_info_equal(&hash_tbl[hind_m]->file, file))
            return hind_m;
    }

    return -1;
}

void klflt_cache_add(const struct klflt_file_info* file)
{
    int hind;
    struct cache_entry* cent;

    write_lock(&cache_lock);

    if (max_cache_files <= 0)
    {
        write_unlock(&cache_lock);
        return;
    }

    hind = hash_find_index_to_replace(file);
    if (-1 == hind)
    {
        write_unlock(&cache_lock);
        return;
    } /* value is already in cache */

    if (hash_tbl[hind])
        cent = hash_tbl[hind];
    else
    {
        cent = list_entry(lru_list.next, struct cache_entry, lru_list);
        if (cent->lru_index !=
            list_entry(lru_list.next->next, struct cache_entry, lru_list)->lru_index)
        {
            /* the cache entry can be in hash table */
            int cent_hind = hash_find_index(&cent->file);
            if (-1 != cent_hind)
                hash_tbl[cent_hind] = NULL;
        }
        hash_tbl[hind] = cent;
    }

    cent->file = *file;
    move_to_lru_list_tail(cent);

    write_unlock(&cache_lock);
}

void klflt_cache_del(dev_t dev, unsigned long ino)
{
    struct klflt_file_info file;
    int hind;

    write_lock(&cache_lock);

    if (max_cache_files <= 0)
    {
        write_unlock(&cache_lock);
        return;
    }

    file.dev = dev;
    file.ino = ino;
    hind = hash_find_index(&file);
    if (-1 == hind)
    {
        write_unlock(&cache_lock);
        return;
    }

    hash_tbl[hind]->lru_index =
        list_entry(lru_list.next, struct cache_entry, lru_list)->lru_index;
    list_del(&hash_tbl[hind]->lru_list);
    list_add(&hash_tbl[hind]->lru_list, &lru_list);
    hash_tbl[hind] = NULL;

    write_unlock(&cache_lock);
}

const struct klflt_file_info* klflt_cached(dev_t dev, unsigned long ino)
{
    struct klflt_file_info file;
    int hind;
    struct cache_entry* cent;

    write_lock(&cache_lock);

    if (max_cache_files <= 0)
    {
        write_unlock(&cache_lock);
        return NULL;
    }

    file.dev = dev;
    file.ino = ino;
    hind = hash_find_index(&file);
    if (-1 == hind)
    {
        write_unlock(&cache_lock);
        return NULL;
    }

    cent = hash_tbl[hind];
    move_to_lru_list_tail(cent);

    write_unlock(&cache_lock);

    return &cent->file;
}

void klflt_cache_clear(void)
{
    int i;

    write_lock(&cache_lock);

    if (max_cache_files <= 0)
    {
        write_unlock(&cache_lock);
        return;
    }

    for (i = 0; i < hash_tbl_sz_mask + 1; ++i)
    {
        if (hash_tbl[i])
        {
            hash_tbl[i]->lru_index = 0;
            hash_tbl[i]            = NULL;
        }
    }

    write_unlock(&cache_lock);
}

int klflt_cache_start(int size)
{
    int i, sz2                          = size;
    int hash_tbl_sz                     = 0;
    struct cache_entry** l_hash_tbl     = NULL;
    struct cache_entry* l_cache_entries = NULL;

    pr_debug("%s: cache size = %d\n", __func__, size);

    // round max_cache_files to power of 2
    if ((sz2 - 1) & sz2)
    {
        while (1)
        {
            int tmp = (sz2 - 1) & sz2;
            if (!tmp)
                break;
            sz2 = tmp;
        }
        sz2 <<= 1;
    }

    hash_tbl_sz = sz2 * HASH_SCALE;
    l_hash_tbl = (struct cache_entry**)insistent_alloc(
        sizeof(struct cache_entry*) * hash_tbl_sz, 256);
    if (!l_hash_tbl)
    {
        pr_err("klflt: files cache memory allocation error, cache disabled.\n");
        return -1;
    }
    memset(l_hash_tbl, 0, sizeof(struct cache_entry*) * hash_tbl_sz);

    l_cache_entries =
        (struct cache_entry*)insistent_alloc(sizeof(struct cache_entry) * sz2, 256);
    if (!l_cache_entries)
    {
        pr_err("klflt: files cache entries allocation error, cache disabled.\n");
        kfree(l_hash_tbl);
        return -1;
    }
    memset(l_cache_entries, 0, sizeof(struct cache_entry) * sz2);

    write_lock(&cache_lock);

    if (max_cache_files != -1)
        klflt_cache_stop_nolock();

    hash_tbl      = l_hash_tbl;
    cache_entries = l_cache_entries;

    /* place all free etries to lru list */
    INIT_LIST_HEAD(&lru_list);
    for (i = 0; i < sz2; ++i)
        list_add(&cache_entries[i].lru_list, &lru_list);

    max_cache_files  = sz2;
    hash_tbl_sz_mask = hash_tbl_sz - 1;

    write_unlock(&cache_lock);

    return 0;
}

void klflt_cache_stop(void)
{
    pr_debug("%s\n", __func__);

    write_lock(&cache_lock);
    klflt_cache_stop_nolock();
    write_unlock(&cache_lock);
}

int klflt_cache_init(void)
{
    pr_debug("%s\n", __func__);

    rwlock_init(&cache_lock);

    return 0;
}

void klflt_cache_destroy(void)
{
    pr_debug("%s\n", __func__);

    klflt_cache_stop();
}
