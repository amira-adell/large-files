
/*
 * This source file is a part of a Kaspersky Antivirus Monitor.
 * Copyright (C) Kaspersky Lab, 1997-2010
 * See License.txt for details
 *
 */


#include "module.h"
static int domatch(const char* text, const char* p);


int __fnmatch(const char* text, const char* p)
{
    if (p[0] == '*' && p[1] == '\0')
        return 1;
    return domatch(text, p);
}

int domatch(const char* text, const char* p)
{
    int last;
    int matched;
    int reverse;

    for (; *p; text++, p++)
    {
        if (*text == '\0' && *p != '*')
            return 0;
        switch (*p)
        {
            case '\\':
                p++;
            default:
                if (*text != *p)
                    return 0;
                continue;
            case '?':
                continue;
            case '*':
                while (*++p == '*')
                    continue;
                if (*p == '\0')
                    return 1;
                while (*text)
                    if ((matched = domatch(text++, p)) != 0)
                        return matched;
                return 0;
            case '[':
                reverse = p[1] == '^' ? 1 : 0;
                if (reverse)
                    p++;
                matched = 0;
                if (p[1] == ']' || p[1] == '-')
                    if (*++p == *text)
                        matched = 1;
                for (last = *p; *++p && *p != ']'; last = *p)
                    /* This next line requires a good C compiler. */
                    if (*p == '-' && p[1] != ']' ? *text <= *++p && *text >= last
                                                 : *text == *p)
                        matched = 1;
                if (matched == reverse)
                    return 0;
                continue;
        }
    }

    return *text == '\0';
}
