#ifndef __KLFLT_MOUNT_H__
#define __KLFLT_MOUNT_H__

#include <linux/kernel.h>
#include <linux/mount.h>
#include <linux/seq_file.h>
#include <linux/poll.h>

#ifndef __percpu
#   define __percpu
#endif // __percpu

#if defined(RHEL_RELEASE_CODE)
#if (RHEL_RELEASE_CODE>=RHEL_RELEASE_VERSION(7,4))
#define RHEL74_BACKPORT
#endif
#endif

struct mnt_namespace
{
    atomic_t count;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 8, 0)
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 19, 0)
    struct ns_common ns;
#else
    unsigned int proc_inum;
#endif
#endif
    struct mount* root;
    struct list_head list;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 8, 0)
    struct user_namespace* user_ns;
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 9, 0)) || defined(RHEL74_BACKPORT)
    struct ucounts* ucounts;
#endif
    u64 seq; /* Sequence number to prevent loops */
#endif
    wait_queue_head_t poll;
    int event;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 9, 0)
    unsigned int mounts;
    unsigned int pending_mounts;
#endif
};

struct mnt_pcp
{
    int mnt_count;
    int mnt_writers;
};

struct mountpoint
{
    struct list_head m_hash;
    struct dentry* m_dentry;
    int m_count;
};

struct mount
{
    struct list_head mnt_hash;
    struct mount* mnt_parent;
    struct dentry* mnt_mountpoint;
    struct vfsmount mnt;
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 18, 0)) || defined(RHEL74_BACKPORT)
    union {
        struct callback_head mnt_rcu;
        struct llist_node mnt_llist;
    };
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3, 13, 0)
    struct rcu_head mnt_rcu;
#endif
#ifdef CONFIG_SMP
    struct mnt_pcp __percpu* mnt_pcp;
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 6, 0)
    atomic_t mnt_longterm; /* how many of the refs are longterm */
#endif
#else
    int mnt_count;
    int mnt_writers;
#endif
    struct list_head mnt_mounts;   /* list of children, anchored here */
    struct list_head mnt_child;    /* and going through their mnt_child */
    struct list_head mnt_instance; /* mount instance on sb->s_mounts */
    const char* mnt_devname;       /* Name of device e.g. /dev/dsk/hda1 */
    struct list_head mnt_list;
    struct list_head mnt_expire;     /* link in fs-specific expiry list */
    struct list_head mnt_share;      /* circular list of shared mounts */
    struct list_head mnt_slave_list; /* list of slave mounts */
    struct list_head mnt_slave;      /* slave list entry */
    struct mount* mnt_master;        /* slave is on master->mnt_slave_list */
    struct mnt_namespace* mnt_ns;    /* containing namespace */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 10, 0)
    struct mountpoint* mnt_mp; /* where is it mounted */
#endif
#ifdef CONFIG_FSNOTIFY
    struct hlist_head mnt_fsnotify_marks;
    __u32 mnt_fsnotify_mask;
#endif
    int mnt_id;          /* mount identifier */
    int mnt_group_id;    /* peer group identifier */
    int mnt_expiry_mark; /* true if marked for expiry */
    int mnt_pinned;
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 13, 0)
    int mnt_ghosts;
#else
    struct path mnt_ex_mountpoint;
#endif
};

struct proc_mounts
{
    struct seq_file m;
    struct mnt_namespace* ns;
    struct path root;
    int (*show)(struct seq_file*, struct vfsmount*);
};

#define proc_mounts(p) (container_of((p), struct proc_mounts, m))

extern const struct seq_operations mounts_op;

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 23))
#define GET_VFSMNT(p) (p)
#define vfsmount_t struct vfsmount
#define real_mount(p) (p)
#define base_mount(p) (p)
#elif(LINUX_VERSION_CODE < KERNEL_VERSION(3, 3, 0))
#define GET_VFSMNT(p) (list_entry(p, struct vfsmount, mnt_list))
#define vfsmount_t struct vfsmount
#define real_mount(p) (p)
#define base_mount(p) (p)
#else
#define GET_VFSMNT(p) (&list_entry(p, struct mount, mnt_list)->mnt)
#define vfsmount_t struct mount
#define base_mount(p) (&p->mnt)
static inline struct mount* real_mount(struct vfsmount* mnt)
{
    return container_of(mnt, struct mount, mnt);
}

#endif

#endif /* __KLFLT_MOUNT_H__ */