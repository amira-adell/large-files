#define uint32_t u_int32_t
#include "../oas/small/device.h"
#include "../oas/small/protocol.h"
#include <sys/ioctl.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <poll.h>

monitor_config_ioctl config = {.cache_size = 4096};

int cn = 0;
int br = 0;
void breaker(int s)
{
    br = s;
}

static char* SCHECK[] = {"OPEN  ", "CLOSE ", "EXEC  "};
static char* SALERT[] = {"UNLINK", "RENAME", "LONG  "};
static char* SREQST[] = {"-----", "CHECK", "REPLY", "ALERT",
                         "CLOSE", "SAMBA", "ASIGN"};

ssize_t scanit(char* in_buf, char* outbuf, int* len)
{
    int qid            = -1;
    int ret            = FILE_ACCESS_NO_CHECK;
    ProtocolHeader* ph = (ProtocolHeader*)(in_buf + sizeof(int));

    *len += (ntohl(*(int*)in_buf) + sizeof(int));

    printf("PACKET %s version %u datasize %u/%u\n", SREQST[ph->request], ph->version,
           ph->data_size, *len);

    switch (ph->request)
    {
        case CHECK_FILE:
        {
            CheckFileData* it = (CheckFileData*)(in_buf + sizeof(int));
            printf("%s %s [%hu]\n", SCHECK[it->file_type], it->name, it->queue_id);
            printf("checkit: uid: %u gid: %u\n", it->uid, it->gid);
            printf("checkit: pid: %u flags: %08X\n", it->pid, it->flags);
            printf("checkit: dev: %llu ino: %llu\n", it->dev, it->ino);

            qid = it->queue_id;
            ret = strcmp(it->name, "/bin/date") ? FILE_ACCESS_ACCEPT
                                                : FILE_ACCESS_DENY;
        }
        break;
        case NOTIFY_FILE:
        {
            NotifyFileData* it = (NotifyFileData*)(in_buf + sizeof(int));
            printf("%s %s\n", SALERT[it->file_type], it->name);
            printf("alertit: dev: %llu ino: %llu\n", it->dev, it->ino);
        }
        break;
    }

    printf("\n");

    if (qid >= 0)
    {
        CheckFileResultData* it = (CheckFileResultData*)(outbuf + sizeof(int));

        *(int*)outbuf = htonl(sizeof(CheckFileResultData));

        it->header.request   = CHECK_FILE_RES;
        it->header.version   = 1;
        it->header.data_size = sizeof(CheckFileResultData) - sizeof(ProtocolHeader);

        it->result   = ret;
        it->queue_id = qid;

        return sizeof(CheckFileResultData) + sizeof(int);
    }

    return 0;
}

int main(int argc, char* argv[])
{
    int ret, fd = open("./kavmonitor", O_RDWR);

    if (-1 == fd)
    {
        perror("monitor");
        return -1;
    }

    signal(SIGINT, breaker);
    signal(SIGQUIT, breaker);
    signal(SIGTERM, breaker);

    ret = ioctl(fd, MONITOR_CONFIG_CMD, &config);
    ret = ioctl(fd, MONITOR_PING_CMD);

    while (!br)
    {
        char bufget[0x1000];
        char bufput[0x1000];
        struct pollfd thepoll = {.fd = fd, .events = POLLIN};
        int rc      = poll(&thepoll, 1, 1000);
        ssize_t get = (rc > 0) ? read(fd, &bufget, 0x1000) : 0;
        ssize_t put = 0;
        int offget  = 0;
        int offput  = 0;

        if (get < 0)
            fprintf(stderr, "poll error: %i", errno);

        while (offget < get)
            offput += scanit(bufget + offget, bufput + offput, &offget);

        put = write(fd, &bufput, offput);
    }

    close(fd);

    return 0;
}
