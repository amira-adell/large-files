
/*  
 * This source file is a part of a Kaspersky Antivirus Monitor.
 * Copyright (C) Kaspersky Lab, 1997-2010
 * See License.txt for details
 *
 */

#ifndef KERNEL__MODULE_LINUX__KAVUMOUNT_H
#define KERNEL__MODULE_LINUX__KAVUMOUNT_H

#ifndef KAVUMOUNT_PATH
#define KAVUMOUNT_PATH  "/usr/local/bin/kavumount"
#endif

#endif // KERNEL__MODULE_LINUX__KAVUMOUNT_H
