
/*
 * This source file is a part of a Kaspersky Antivirus Monitor.
 * Copyright (C) Kaspersky Lab, 1997-2010
 * See License.txt for details
 *
 */

#include "klflt.h"
#include "files.h"

#include <linux/module.h>
#include <linux/init.h>
#include <linux/seq_file.h>

struct vfsmount* orig_rootmnt = NULL;
struct dentry* orig_root      = NULL;

#ifdef LINUX_KERNEL26
MODULE_INFO(supported, "external");

extern int use_binfmt;
module_param(use_binfmt, int, S_IRUGO);
MODULE_PARM_DESC(use_binfmt, "Enables hook on exec system call.");
#endif

klflt_module_config_t klflt_module_config;

static struct klflt_interceptor_ops intercept_ops = {
    .start = NULL,
    .stop  = NULL
};

static int __init klflt_init_module(void)
{
    int rv = 0;

    pr_debug("%s\n", __func__);

    rv = get_current_fs_root(&orig_rootmnt, &orig_root);
    if (rv < 0)
    {
        pr_err("%s: Failed to configre root FS: %d\n", __func__, rv);
        goto exit;
    }

    rv = klflt_queue_init();
    if (rv < 0)
    {
        pr_err("%s: Failed to configure klflt queue: %d\n", __func__, rv);
        goto error_queue;
    }

    rv = klflt_trusted_init();
    if (rv < 0)
    {
        pr_err("%s: Failed to initialize trusted processes list: %d\n", __func__, rv);
        goto error_trusted;
    }

    rv = klflt_cache_init();
    if (rv < 0)
    {
        pr_err("%s: Failed to initialize cache subsystem: %d\n", __func__, rv);
        goto error_cache;
    }

    rv = klflt_intercept_init(&intercept_ops);
    if (rv < 0)
    {
        pr_err("%s: Failed to initialize interceptor. err=%d\n", __func__, rv);
        goto error_intercept;
    }

    rv = klflt_interface_v2_init(&intercept_ops);
    if (rv < 0)
    {
        pr_err("%s: Failed to initialize monitor device: %d\n", __func__, rv);
        goto error_interface;
    }

    goto exit;

error_interface:
    klflt_intercept_destroy();
error_intercept:
    klflt_cache_destroy();
error_cache:
    klflt_trusted_destroy();
error_trusted:
    klflt_queue_destroy();
error_queue:
    dput(orig_root);
    mntput(orig_rootmnt);
exit:
    return rv;
}

static void __exit klflt_cleanup_module(void)
{
    pr_debug("%s\n", __func__);

    klflt_interface_v2_destroy();
    klflt_intercept_destroy();
    klflt_cache_destroy();
    klflt_trusted_destroy();
    klflt_queue_destroy();
    dput(orig_root);
    mntput(orig_rootmnt);
}


/* Module section */
MODULE_AUTHOR("Kaspersky Lab");
MODULE_DESCRIPTION("Kaspersky Anti-Virus Monitor Module for Linux.");

MODULE_VERSION(LFS_PRODUCT_VERSION);
MODULE_LICENSE("GPL");

module_init(klflt_init_module);
module_exit(klflt_cleanup_module);
