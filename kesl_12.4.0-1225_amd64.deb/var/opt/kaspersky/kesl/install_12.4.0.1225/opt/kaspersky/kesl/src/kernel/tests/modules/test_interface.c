#include <klflt.h>
#include <files.h>

#include <linux/module.h>
#include <linux/init.h>
#include <linux/seq_file.h>
#include <linux/namei.h>
#include <linux/list.h>

struct vfsmount* orig_rootmnt = NULL;
struct dentry* orig_root      = NULL;
klflt_module_config_t klflt_module_config;

#ifdef LINUX_KERNEL26
MODULE_INFO(supported, "external");

extern int use_binfmt;
module_param(use_binfmt, int, S_IRUGO);
MODULE_PARM_DESC(use_binfmt, "Enables hook on exec system call.");
static char *protectedPath = "/tmp";
module_param(protectedPath, charp, 0000);
MODULE_PARM_DESC(protectedPath, "Protected mountpoint");
#endif

static struct klflt_mounts_ops mount_ops = {
    .add_mount = NULL,
    .remove_mount = NULL
};

static struct vfsmount* protectedVfs = NULL;

static int klflt_start_intercept(void)
{
    int rv;

    struct path mntpath;

    rv = klflt_check_init();
    if (rv < 0)
    {
        pr_err("klflt: failed to initialize check module. err=%d\n", rv);
        goto exit;
    }

    rv = klflt_rfs_init(&mount_ops);
    if (rv < 0)
    {
        pr_err("klflt: failed to initialize RFS system. err=%d\n", rv);
        goto error_rfs;
    }

    rv = kern_path(protectedPath, LOOKUP_FOLLOW, &mntpath);
    if (rv < 0 || mntpath.mnt == NULL)
    {
        pr_err("klflt: failed to mark path %s. err=%d\n", protectedPath, rv);
        goto bad_kern_path;
    }

    protectedVfs = mntget(mntpath.mnt);
    if (IS_ERR(protectedVfs))
    {
        rv = PTR_ERR(protectedVfs);
        pr_err("klflt: failed to grab mnt of path %s. err=%d\n", protectedPath, rv);
        path_release(&mntpath);
        protectedVfs = NULL;
        goto bad_kern_path;
    }

    rv = mount_ops.add_mount(protectedVfs);
    mntput(protectedVfs);
    path_release(&mntpath);
    if (rv < 0)
    {
        pr_err("klflt: failed to register path %s with redirfs. err=%d\n", protectedPath, rv);
        goto bad_kern_path;
    }

    pr_debug("%s initialized\n", __func__);
    goto exit;

bad_kern_path:
    klflt_rfs_destroy();
error_rfs:
    klflt_check_destroy();
exit:
    return rv;
}

static int klflt_stop_intercept(void)
{
    int rv;

    rv = mount_ops.remove_mount(protectedVfs);
    if (rv < 0)
    {
        pr_err("Failed to unregister folder %s from redirfs. err=%d\n", protectedPath, rv);
    }
    protectedVfs = NULL;

    klflt_rfs_destroy();
    klflt_check_destroy();

    return rv;
}

static struct klflt_interceptor_ops intercept_ops = {
    .start = klflt_start_intercept,
    .stop  = klflt_stop_intercept
};

static int __init klflt_test_init(void)
{
    int rv = 0;

    pr_debug("klflt_init_module\n");

    rv = get_current_fs_root(&orig_rootmnt, &orig_root);
    if (rv < 0)
    {
        pr_err("%s: Failed to configre root FS: %d\n", __func__, rv);
        goto exit;
    }

    rv = klflt_trusted_init();
    if (rv < 0)
    {
        pr_err("%s: Failed to initialize trusted processes list: %d\n", __func__, rv);
        goto error_trusted;
    }

    rv = klflt_interface_v2_init(&intercept_ops);
    if (rv < 0)
    {
        pr_err("%s: Failed to initialize monitor device: %d\n", __func__, rv);
        goto error_interface;
    }

    goto exit;

error_interface:
    klflt_trusted_destroy();
error_trusted:
    dput(orig_root);
    mntput(orig_rootmnt);
exit:
    return rv;
}

static void __exit klflt_test_exit(void)
{
    pr_debug("%s\n", __func__);
    klflt_interface_v2_destroy();
    klflt_trusted_destroy();
    dput(orig_root);
    mntput(orig_rootmnt);
}

/*
 * Module information
 */


MODULE_AUTHOR("Kaspersky Lab");
MODULE_DESCRIPTION("Kaspersky Anti-Malware Monitor Module Test for Linux.");
MODULE_LICENSE("GPL");

module_init(klflt_test_init);
module_exit(klflt_test_exit);