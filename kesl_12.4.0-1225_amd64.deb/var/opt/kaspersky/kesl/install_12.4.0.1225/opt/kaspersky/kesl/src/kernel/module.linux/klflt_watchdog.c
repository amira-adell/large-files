#include "klflt.h"
#include "klflt_protocol.h"
#include "product_config.h"

#include <linux/delay.h>
#include <linux/fs.h>
#include <linux/kthread.h>
#include <linux/module.h>
#include <linux/proc_fs.h>
#include <linux/sched.h>
#include <linux/seq_file.h>

#define MONITOR_WATCHDOG_PERIOD 20000
#define MONITOR_WATCHDOG_DELTA 100
#ifndef MONITOR_WATCHDOG_FILENAME
#error "It must be defined in product_config.h"
#endif //MONITOR_WATCHDOG_FILENAME
#ifndef MONITOR_WATCHDOG_NAME
#error "It must be defined in monitor_watchdog_filename.h"
#endif //MONITOR_WATCHDOG_NAME

static atomic_t watchdog_started = ATOMIC_INIT(0);
static DEFINE_MUTEX(watchdog_mutex);

struct klflt_watchdog_ops watchdog_ops;
struct task_struct* watchdog = NULL;

int klflt_queue_add(
    u_short queue_id, int block, struct klflt_request_metadata* reqd,
    enum KlFileAccessType* answer, unsigned long int timeout);

static int watchdog_proc_print(struct seq_file* m, void* v)
{
    seq_printf(m, "klflt watchdog file\n");

    return 0;
}

static int watchdog_open(struct inode* inode, struct file* file)
{
    return single_open(file, watchdog_proc_print, NULL);
}

static const struct file_operations watchdog_proc_fops = {
    .owner   = THIS_MODULE,
    .open    = watchdog_open,
    .read    = seq_read,
    .llseek  = seq_lseek,
    .release = single_release,
};

static int klflt_watchdog_hearbeat(void)
{
    struct klflt_request_metadata* reqd;
    int result                   = 0;
    u_short queue_id             = klflt_queue_get_id();
    enum KlFileAccessType answer = FILE_ACCESS_ACCEPT;

    pr_debug("%s\n", __func__);

    if (!atomic_read(&watchdog_started))
    {
        pr_warning("%s: watchdog not running\n", __func__);
        result = 0;
        goto exit;
    }

    reqd = (struct klflt_request_metadata*)kmalloc(sizeof(*reqd), GFP_KERNEL);
    if (!reqd) {
        pr_err("%s: failed to allocate memory for request metadata\n", __func__);
        result = -ENOMEM;
        goto exit;
    }

    INIT_LIST_HEAD(&reqd->list);
    kref_init(&reqd->refcnt);

    reqd->request = CHECK_FILE;
    reqd->euid   = 0;
    reqd->egid   = 0;
    reqd->vfsmnt = NULL;
    reqd->parent = NULL;
    reqd->name   = kstrdup(MONITOR_WATCHDOG_FILENAME, GFP_KERNEL);
    reqd->file_op_type = FILE_OPEN_OPER;

    result = klflt_queue_add(queue_id, 0, reqd, &answer, MONITOR_WATCHDOG_PERIOD);
    check_req_queue_put(reqd);
exit:
    return result;
}

static int klflt_watchdog_thread(void* unused)
{
    int proc_created = 1;
    int timeout;
    pr_debug("%s started\n", __func__);

    atomic_xchg(&watchdog_started, 1);

    if (!proc_create(MONITOR_WATCHDOG_NAME, 0, NULL, &watchdog_proc_fops))
    {
        pr_warning("klflt: Warning! Failed to create %s\n", MONITOR_WATCHDOG_NAME);
        proc_created = 0;
    }

    while (!kthread_should_stop())
    {

        if (klflt_watchdog_hearbeat() < 1)
        {
            pr_debug("watchdog activated\n");
            watchdog_ops.invoke();
            break;
        }

        timeout = 0;
        while (timeout < MONITOR_WATCHDOG_PERIOD && !kthread_should_stop())
        {
            msleep(MONITOR_WATCHDOG_DELTA);
            timeout += MONITOR_WATCHDOG_DELTA;
        }
    }

    if (proc_created)
        remove_proc_entry(MONITOR_WATCHDOG_NAME, NULL);

    atomic_xchg(&watchdog_started, 0);

    pr_debug("%s finished\n", __func__);

    return 0;
}

int klflt_watchdog_init(struct klflt_watchdog_ops* ops)
{
    int rv;

    pr_debug("%s\n", __func__);

    mutex_lock(&watchdog_mutex);
    if (atomic_read(&watchdog_started))
    {
        pr_err("klflt: watchdog already running\n");
        return 1;
    }

    watchdog_ops.invoke = ops->invoke;
    watchdog = kthread_run(klflt_watchdog_thread, NULL, "kav_watchdog");
    if (IS_ERR(watchdog))
    {
        rv = PTR_ERR(watchdog);
        pr_err("klflt: init watchdog thread failed, err=%d\n", rv);
        return 1;
    }
    mutex_unlock(&watchdog_mutex);
    return 0;
}

int klflt_watchdog_destroy(void)
{
    pr_debug("%s\n", __func__);

    mutex_lock(&watchdog_mutex);
    if (atomic_read(&watchdog_started))
    {
        kthread_stop(watchdog);
    }
    mutex_unlock(&watchdog_mutex);

    return 1;
}