#include "klflt.h"
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/seq_file.h>
#include <linux/proc_fs.h>

static int kav4fs_proc_version_print(struct seq_file* m, void* v)
{
    seq_printf(m, "%s", LFS_PRODUCT_VERSION);
    return 0;
}

static int kav4fs_version_open(struct inode* inode, struct file* file)
{
    return single_open(file, kav4fs_proc_version_print, NULL);
}

static const struct file_operations kav4fs_version_fops = {
    .owner    = THIS_MODULE,
    .open     = kav4fs_version_open,
    .read     = seq_read,
    .llseek   = seq_lseek,
    .release  = single_release,
};

int klflt_version_init(void)
{
    pr_debug("klflt_version_init\n");

    if (!proc_create(KAV4FS_VERSION_NAME, 0, NULL, &kav4fs_version_fops))
    {
        printk(KERN_INFO "klflt: Warning! Failed to create %s\n",
               KAV4FS_VERSION_NAME);
        return -1;
    }

    return 0;
}

void klflt_version_destroy(void)
{
    pr_debug("klflt_version_destroy\n");

    remove_proc_entry(KAV4FS_VERSION_NAME, NULL);
}