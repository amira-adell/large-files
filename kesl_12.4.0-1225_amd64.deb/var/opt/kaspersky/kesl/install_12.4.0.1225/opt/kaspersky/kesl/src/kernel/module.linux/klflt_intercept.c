#include "klflt.h"

#include <linux/completion.h>
#include <linux/kthread.h>
#include <linux/list.h>
#include <linux/namei.h>
#include <linux/wait.h>
#include <linux/errno.h>

#define INTERCEPT_START_TIMEOUT 20000
#define INTERCEPT_STOP_TIMEOUT 20000
static atomic_t intercept_started = ATOMIC_INIT(0);
static atomic_t intercept_aborted = ATOMIC_INIT(0);
static DECLARE_WAIT_QUEUE_HEAD(intercept_waitq);
static DECLARE_WAIT_QUEUE_HEAD(intercept_start_waitq);
static DEFINE_MUTEX(intercept_mutex);
static struct task_struct *intercept_thrd = NULL;
static DECLARE_COMPLETION(intercept_done);

static void (* destroyers[6]) ();
static int destroyers_count = 0;

static int klflt_intercept_stop(void);

static struct klflt_mounts_ops mount_ops = {
    .add_mount = NULL,
    .remove_mount = NULL
};

static void klflt_intercept_abort(void)
{
    pr_debug("%s\n", __func__);

    atomic_xchg(&intercept_aborted, 1);
    wake_up(&intercept_waitq);
}

static struct klflt_watchdog_ops watchdog_ops = {
    .invoke = klflt_intercept_abort,
};

extern klflt_module_config_t klflt_module_config;

static int klflt_intercept_init_subsystems()
{
    int rv = 0;

    pr_debug("%s\n", __func__);

    destroyers_count = 0;
    rv = klflt_rfs_init(&mount_ops);
    if (rv < 0)
    {
        pr_err("klflt: failed to initialize RFS system. err=%d\n", rv);
        return rv;
    }
    destroyers[destroyers_count++] = klflt_rfs_destroy;

    rv = klflt_smb_init(&mount_ops);
    if (rv < 0)
    {
        pr_err("klflt: failed to initialize smb subsystem\n");
        return rv;
    }
    destroyers[destroyers_count++] = klflt_smb_destroy;

    rv = klflt_mounts_handler_init(&mount_ops);
    if (rv < 0)
    {
        pr_err("klflt: failed to initialize mounts monitoring subsystem\n");
        return rv;
    }
    destroyers[destroyers_count++] = klflt_mounts_handler_destroy;

    rv = klflt_cache_start(klflt_module_config.cache_size);
    if (rv < 0)
    {
        pr_err("klflt: failed to initialize cache\n");
        return rv;
    }
    destroyers[destroyers_count++] = klflt_cache_stop;

    rv = klflt_check_init();
    if (rv < 0)
    {
        pr_err("klflt: failed to initialize check module. err=%d\n", rv);
        return rv;
    }
    destroyers[destroyers_count++] = klflt_check_destroy;

    rv = klflt_watchdog_init(&watchdog_ops);
    if (rv < 0)
    {
        pr_err("klflt: failed to initialize klflt watchdog. err=%d\n", rv);
        return rv;
    }
    destroyers[destroyers_count++] = klflt_watchdog_destroy;

    BUG_ON(destroyers_count > sizeof(destroyers) / sizeof(destroyers[0]));

    return rv;
}

static void klflt_intercept_destroy_subsystems()
{
    pr_debug("%s\n", __func__);

    while (destroyers_count)
    {
        pr_debug("%s %d\n", __func__, destroyers_count);
        destroyers[--destroyers_count]();
    }
}

static int klflt_intercept_thread_shutdown(void)
{
    klflt_intercept_abort();

    int rv = wait_for_completion_interruptible_timeout(&intercept_done, msecs_to_jiffies(INTERCEPT_STOP_TIMEOUT));
    if (rv == 0)
    {
        pr_warning("%s: Intercept stop timeout expired", __func__);
        rv = -ETIMEDOUT;
    }
    else if (rv > 0)
    {
        rv = 0;
    }
    else
    {
        pr_warning("%s: Intercept stop was signaled", __func__);
    }

    return rv;
}

static void klflt_intercept_thread(void* unused)
{
    int rv = 0;
    pr_debug("%s started\n", __func__);

    atomic_xchg(&intercept_aborted, 0);

    rv = klflt_intercept_init_subsystems();
    if (rv < 0)
    {
        goto error;
    }

    atomic_xchg(&intercept_started, 1);
    wake_up(&intercept_start_waitq);

    while (true)
    {
        wait_event_interruptible(intercept_waitq, atomic_read(&intercept_aborted));
        if (atomic_read(&intercept_aborted))
        {
            pr_debug("klflt: file interceptor stop initiated\n");
            break;
        }
    }

error:
    klflt_intercept_destroy_subsystems();

    atomic_xchg(&intercept_started, 0);

    pr_debug("%s finished\n", __func__);
    complete_and_exit(&intercept_done, rv);
}

static int klflt_intercept_start(void)
{
    int rv = 0;

    pr_debug("%s\n", __func__);

    mutex_lock(&intercept_mutex);
    if (atomic_read(&intercept_started))
    {
        pr_err("%s: already started\n", __func__);
        rv = -EALREADY;
        goto exit;
    }

    init_completion(&intercept_done);
    intercept_thrd = kthread_run(klflt_intercept_thread, NULL, "klflt_intercept");
    if (IS_ERR(intercept_thrd))
    {
        complete(&intercept_done);
        rv = PTR_ERR(intercept_thrd);
        pr_err("klflt: filed to start klflt_intercept thread, err=%d\n", rv);
        goto exit;
    }

    if (!wait_event_interruptible_timeout(intercept_start_waitq,
            atomic_read(&intercept_started),
            msecs_to_jiffies(INTERCEPT_START_TIMEOUT)))
    {
        pr_err("%s: Intercept start timeout expired", __func__);
        klflt_intercept_thread_shutdown();
        rv = -ETIMEDOUT;
    }

exit:
    mutex_unlock(&intercept_mutex);
    return rv;
}

int klflt_intercept_stop(void)
{
    int rv = 0;

    pr_debug("%s\n", __func__);

    mutex_lock(&intercept_mutex);
    if (!atomic_read(&intercept_started)) {
        pr_err("%s: already stopped\n", __func__);
        goto exit;
    }

    rv = klflt_intercept_thread_shutdown();
    if (rv)
    {
        pr_err("klflt: failed to stop klflt_intercept thread, err=%d\n", rv);
    }

exit:
    mutex_unlock(&intercept_mutex);
    return rv;
}

static struct klflt_interceptor_ops intercept = {
    .start = klflt_intercept_start,
    .stop  = klflt_intercept_stop
};

int klflt_intercept_init(struct klflt_interceptor_ops* interceptor_ops)
{
    pr_debug("%s\n", __func__);

    *interceptor_ops = intercept;

    return 0;
}

void klflt_intercept_destroy(void)
{
    pr_debug("%s\n", __func__);

    klflt_intercept_stop();
}