#include "klflt.h"
#include "klflt_protocol.h"

#include <linux/module.h>
#include <linux/slab.h>
#include <linux/types.h>

#define init_protocol_buffer_size 1024
atomic_t klflt_connection_initialized = ATOMIC_INIT(0);

static int get_proto_buffer_length(struct klflt_proto_buffer* buf)
{
    u_int32_t* ptr;
    u_int32_t len;

    if (buf->length < sizeof(u_int32_t))
        return 0;

    ptr = (u_int32_t*)buf->start;
    len = ntohl(*ptr);
    if (buf->length < len)
        return 0;
    return len;
}

int connection_init(struct klflt_connection* conn)
{
    int res = 0;
    pr_debug("%s: conn=%p\n", __func__, conn);

    if (atomic_read(&klflt_connection_initialized))
    {
        pr_err("%s: connection already initialized\n", __func__);
        return -EALREADY;
    }

    conn->send_buff.capacity = init_protocol_buffer_size;
    conn->send_buff.data = kmalloc(init_protocol_buffer_size, GFP_KERNEL);
    conn->send_buff.start = conn->send_buff.data;
    conn->send_buff.length = 0;
    if (!conn->send_buff.data) {
        res = -ENOMEM;
        goto exit;
    }

    conn->recv_buff.capacity = init_protocol_buffer_size;
    conn->recv_buff.data = kmalloc(init_protocol_buffer_size, GFP_KERNEL);
    conn->recv_buff.start = conn->recv_buff.data;
    conn->recv_buff.length = 0;
    if (!conn->recv_buff.data) {
        res = -ENOMEM;
        goto exit_recv;
    }

    sema_init(&conn->recv_buff_mtx, 1);
    sema_init(&conn->send_buff_mtx, 1);
    init_waitqueue_head(&conn->request_waitq);

    atomic_xchg(&klflt_connection_initialized, 1);
    goto exit;

exit_recv:
    kfree(conn->send_buff.data);
exit:
    return res;
}

void connection_destroy(struct klflt_connection* conn)
{
    pr_debug("%s: conn=%p\n", __func__, conn);

    if (!atomic_read(&klflt_connection_initialized))
    {
        pr_err("%s: connection not initialized\n", __func__);
        return;
    }

    atomic_xchg(&klflt_connection_initialized, 0);

    kfree(conn->send_buff.data);
    kfree(conn->recv_buff.data);
    conn->send_buff.data = NULL;
    conn->send_buff.start = NULL;
    conn->send_buff.length = 0;
    conn->send_buff.capacity = 0;
    conn->recv_buff.data = NULL;
    conn->recv_buff.start = NULL;
    conn->recv_buff.length = 0;
    conn->recv_buff.capacity = 0;
}

int connection_is_data_ready(const struct klflt_connection* conn)
{
    if (conn->send_buff.length)
        return 1;
    return !check_req_queue_empty();
}

int connection_get_answer(struct klflt_connection* conn,
                                 struct klflt_protocol_data* response)
{
    u_int32_t len;
    char* begin;
    char* end;
    struct klflt_proto_buffer* buf;

    buf = &conn->recv_buff;
    len = get_proto_buffer_length(buf);
    if (!len)
        return 0;

    begin = buf->start + sizeof(u_int32_t);
    end = buf->start + len;
    buf->start += len;
    buf->length -= len;

    response = (struct klflt_protocol_data*) begin;

    return len;
}